# Lebenszufriedenheit (Cantril-Leiter) — Machbarkeitsprüfung Länder vs. US-Bundesstaaten

Erstellt: 2026-09-18 · Serie „If country XY were a US state"

**Kurzfassung:** Prüfung 1 = JA (Werte existieren, gleiches Instrument, gleiche Frageformulierung,
gleicher Erheber). Prüfung 2 = NEIN für eine gemeinsame Rangliste. Der reine Methodenversatz
beträgt **0,18 Leiterpunkte** und ist damit **größer als jeder einzelne der 50 Rangabstände
zwischen benachbarten Bundesstaaten** (größter Abstand 0,083). Eine gemeinsame Rangliste
Länder ↔ Bundesstaaten ist **nicht tragfähig**. Verwendbar bleibt die nationale Randbemerkung.

---

## Prüfung 1 — Bundesstaatenwerte aus demselben Instrument?

### (a) World Happiness Report je Bundesstaat — NEIN
Der World Happiness Report selbst publiziert **keine** Werte je US-Bundesstaat. Gerankt werden
ausschließlich Länder; der jüngste Stand ist WHR 2026 (Datenjahr 2025, veröffentlicht 2026-03-16).
US-Kapitel der Reihe behandeln den US-Rückgang auf Landesebene (Altersgruppen, soziale Bindungen),
nicht die 50 Bundesstaaten.
Belegart: **nicht geprüft** für jede einzelne WHR-Ausgabe 2012–2026 — geprüft wurde die
WHR-/Gallup-Publikationsseite und die Sekundärberichterstattung zu WHR 2025/2026; in keiner
Quelle taucht eine WHR-eigene Bundesstaaten-Rangliste auf.

### (b) Gallup-Sharecare Well-Being Index — existiert, ist aber NICHT die Cantril-Leiter
- Letzte Staaten-Rangliste unter Gallup-Beteiligung: **2017 State Well-Being Rankings**
  (Feldzeit 2017-01-02 bis 2017-12-30, n = 160.498 Erwachsene).
  Quelle: https://wellbeingindex.sharecare.com/wp-content/uploads/2018/02/Gallup-Sharecare-State-of-American-Well-Being_2017-State-Rankings_FINAL.pdf
  Belegart: **abgelesen** (Feldzeit + n aus der Publikation).
- Ab 2018 firmiert die Reihe als **Sharecare Community Well-Being Index** (ohne Gallup).
  Quelle: https://wellbeingindex.sharecare.com/wp-content/uploads/2020/08/Sharecare-CWBI_2018_State_Rankings_v5.pdf
- **Entscheidend:** Der publizierte Index ist ein **zusammengesetzter Index auf Skala 0–100**
  über fünf Domänen (Purpose, Social, Financial, Community, Physical) — **nicht** die rohe
  Cantril-Leiter 0–10. Die Cantril-Frage steckt nur als eine Zutat im Teil-„Life Evaluation Index",
  und der wird als Anteil „thriving/struggling/suffering" berichtet, nicht als Mittelwert.
  → **Für eine Cantril-Rangliste unbrauchbar.** Belegart: **abgelesen**
  (https://news.gallup.com/poll/106756/galluphealthways-wellbeing-index.aspx,
   https://news.gallup.com/poll/122453/understanding-gallup-uses-cantril-scale.aspx).

### (c) Andere Quelle mit Cantril-Leiter je Bundesstaat — JA, genau eine
**Blanchflower, D. G. & Bryson, A. (2024): „Wellbeing Rankings", Social Indicators Research
171:731–807** (zuerst NBER WP 30759, Dez. 2022).
PDF: https://bpb-us-e1.wpmucdn.com/sites.dartmouth.edu/dist/5/2216/files/2023/12/Blanchflower-and-Bryson-2023-Wellbeing-Rankings.pdf

- Datenquellen: **Gallup World Poll** (Länder) + **Gallup US Daily Tracker Poll** (Bundesstaaten).
- Zeitraum: **2008–2017 gepoolt**. n = 1.862.900 (World Poll) bzw. 3.530.270 (Daily Tracker);
  für Cantril speziell n = 1.598.360 (World Poll) und n = 2.575.022 (USDT).
- **Appendix Table 13** berichtet gewichtete Mittelwerte der Cantril-Leiter für **164 Länder,
  50 Bundesstaaten und DC in einer alphabetischen Tabelle**. Genau das ist die gesuchte Größe.
- Frageformulierung im Paper wörtlich, **identisch in beiden Erhebungen**:
  „Please imagine a ladder with steps numbered from zero at the bottom to ten at the top.
  Suppose we say that the top of the ladder represents the best possible life for you and the
  bottom of the ladder represents the worst possible life for you. If the top step is 10 and the
  bottom step is 0, on which step of the ladder do you feel you personally stand at the present time?"
- Belegart: **abgelesen** (Tabelle und Frageformulierung direkt aus dem PDF extrahiert).

**Falle in Table 13:** Die Tabelle mischt Länder und Bundesstaaten alphabetisch. Der US-Staat
Georgia steht als Zeile **„Georgia USA" (6,942)**, das Land Georgien als **„Georgia" (4,218)**.
Wer stumpf nach „Georgia" greift, zieht das Land. DC steht als **„DC" (7,153)**.

### (c2) BRFSS — führt eine Lebenszufriedenheitsfrage, aber NICHT die Cantril-Leiter
BRFSS fragt „In general, how satisfied are you with your life?" auf einer **4-stufigen** Skala
(very satisfied / satisfied / dissatisfied / very dissatisfied). Das ist eine andere Skala,
andere Frage, andere Verteilung — **nicht** die 11-stufige Cantril-Leiter.
Blanchflower & Bryson halten zusätzlich fest, dass die BRFSS-Variable **nur 2005–2010** erhoben
wurde und danach nicht mehr. Belegart: **abgelesen** (Paper-Text; BRFSS-Frageformulierung über
State-BRFSS-Auswertungen, z. B. https://www.in.gov/health/reports/brfss/2010/c22.02.htm).
County Health Rankings wurde **nicht geprüft** — nach obiger Lage aber ohne Chance auf eine
eigenständige Cantril-Erhebung, da es Sekundärindikatoren aggregiert.

**Ergebnis Prüfung 1: JA.** Cantril-Werte je Bundesstaat existieren, aus derselben
Frageformulierung und vom selben Erheber (Gallup), Zeitraum 2008–2017, publiziert in
Blanchflower & Bryson (2024), Appendix Table 13.

---

## Prüfung 2 — Instrumentenvergleichbarkeit

### (A) Der harte, direkt gemessene Versatz: 0,18 Leiterpunkte
Blanchflower & Bryson berichten für **dasselbe Land (USA), dieselbe Frage, denselben Zeitraum
(2008–2017), denselben Erheber**, aber **zwei verschiedene Erhebungsvehikel** folgende
gewichtete Mittelwerte:

| | Gallup World Poll | Gallup US Daily Tracker |
|---|---|---|
| Cantril | **7,08** (n = 12.175) | **6,90** (n = 2.575.022) |

Differenz **0,18 Leiterpunkte**; die Autoren halten fest, dass die Unterschiede zwischen beiden
US-Erhebungen in allen Fällen statistisch signifikant sind. Belegart: **abgelesen**.

Das ist exakt der Versatz, der beim Kreuzen der beiden Seiten anfällt: die Länderwerte kommen
aus dem World Poll, die Bundesstaatenwerte aus dem Daily Tracker.

### (B) Größenvergleich mit den Rangabständen — berechnet
Berechnet aus Appendix Table 13 (51 Bundesstaaten inkl. DC; 36 Länder der Serie):

| Kennzahl | Wert |
|---|---|
| Spannweite aller 51 Bundesstaaten | **0,520** Leiterpunkte (West Virginia 6,696 → Hawaii 7,216) |
| Standardabweichung der 51 Bundesstaaten | 0,100 |
| Median-Abstand zwischen benachbarten Bundesstaaten | **0,005** |
| Größter Abstand zwischen zwei benachbarten Bundesstaaten | **0,083** |
| Zahl der 50 Nachbar-Abstände, die kleiner sind als 0,18 | **50 von 50** |
| Maximale Zahl Bundesstaaten innerhalb eines 0,18 breiten Fensters | **36 von 51** |
| Spannweite der 36 Serienländer | 3,063 (Dänemark 7,638 → Indien 4,575) |
| Nachbar-Abstände zwischen Ländern unter 0,18 | 31 von 35 |

Belegart: **berechnet** (aus abgelesenen Table-13-Werten).

**Lesart:** Der reine Methodenversatz von 0,18 ist **35 % der gesamten Spannweite aller
51 Bundesstaaten** und schlägt **jeden einzelnen** Rangabstand zwischen benachbarten
Bundesstaaten. Ein Fenster von der Breite des Messfehlers enthält 36 der 51 Bundesstaaten.
Das ist dasselbe Kriterium wie bei den Dezilverhältnissen dieses Projekts (dort 16 %
Methodenversatz gegen die meisten Rangabstände) — hier fällt es noch deutlicher aus.

### (C) Kultureller Antwortstil zwischen Ländern — zusätzlich, nicht ersetzend
OECD-Arbeitspapier **Exton, C., Smith, C. & Vandendriessche, D. (2015): „Comparing Happiness
across the World: Does Culture Matter?", OECD Statistics Working Paper STD/DOC(2015)4**,
auf Basis mehrerer Gallup-World-Poll-Wellen:
https://www.oecd.org/content/dam/oecd/en/publications/reports/2015/11/comparing-happiness-across-the-world_g17a2713/5jrqppzd9bs2-en.pdf

- Länder-Fixed-Effects für Lebensbewertungen (nach Kontrolle von Sozio-Demografie) reichen von
  **+1,505 (Costa Rica) bis −1,928 (Togo)** = **3,43 Leiterpunkte Spannweite**. **abgelesen**
- Kultur erklärt nach Schätzung der Autoren **„some 20 %"** dieser länderspezifisch unerklärten
  Varianz; die Autoren bezeichnen diesen kombinierten Effekt aus „cultural impact" und
  „cultural bias" als klein gegenüber den objektiven Lebensumständen. Die 20 % sind ausdrücklich
  eine **Obergrenze** (enthält auch ausgelassene Variablen, nicht nur Antwortstil). **abgelesen**
- **Anerkannte Korrektur:** Es gibt keine im WHR angewandte. In der Literatur werden
  **Anchoring Vignettes** eingesetzt; Angelini, Cavapozzi, Corazzini & Paccagnella (2014),
  „Do Danes and Italians Rate Life Satisfaction in the Same Way?", Oxford Bulletin of Economics
  and Statistics 76(5):643–666, zeigen, dass die **länderübergreifende Rangfolge der
  Lebenszufriedenheit sich nach Vignetten-Korrektur signifikant ändert**.
  https://onlinelibrary.wiley.com/doi/abs/10.1111/obes.12039
  Belegart: **abgelesen** (Abstract/Verlagsseite). Effektgröße in Leiterpunkten:
  **nicht geprüft** — Volltext nicht zugänglich.

### (D) Weitere, nicht instrumentenbezogene Einschränkung
Die Bundesstaatenwerte sind **2008–2017**. Der übrige Serien-Datensatz liegt bei 2022–2024.
Es gibt **keine** neuere Quelle mit Cantril je Bundesstaat (Belegart: **nicht geprüft** für
unpublizierte Gallup-Sonderauswertungen; öffentlich publiziert existiert keine). Der
US-Landeswert ist zwischen 2017 und heute deutlich gefallen (WHR-Rang 24 in 2025, tiefster
Stand) — die Staatenwerte von 2008–2017 sind damit nicht nur methodisch, sondern auch
zeitlich nicht an die aktuellen Länderwerte anschlussfähig.

---

## Empfehlung

**Nicht rankbar gegen Bundesstaaten.** Konkret:

1. **Keine gemeinsame Rangliste** Länder ↔ Bundesstaaten für Lebenszufriedenheit. Der
   Methodenversatz (0,18) übertrifft jeden Nachbar-Abstand zwischen Bundesstaaten (max. 0,083)
   und deckt 36 der 51 Bundesstaaten in einem einzigen Fenster ab. Eine Aussage wie
   „Deutschland läge zwischen Kentucky und West Virginia" ist reines Messrauschen.
2. **Auch eine reine Bundesstaaten-Rangliste** trägt nicht: Spannweite 0,52, Median-Abstand
   0,005 — das ist innerhalb der Erhebungsunsicherheit nicht auflösbar.
3. **Verwendbar als nationale Randbemerkung:** Vergleiche auf Länderebene mit Abständen
   deutlich über 0,18 sind tragfähig — Beispiele aus WHR 2026 (Datenjahr 2025):
   Dänemark 7,539 · USA 6,816 · Indien 4,536, weil die Länderspannweite mit 3,06
   Leiterpunkten das 17-Fache des Versatzes beträgt. Die USA als **ein** Datenpunkt gegen
   die anderen Länder — nicht als 51 Datenpunkte.
4. Falls die Serie trotzdem etwas Subjektives je Bundesstaat braucht: sauber wäre nur ein
   Indikator, der für beide Seiten aus **einem** Erhebungsvehikel stammt. Ein solcher
   existiert nach dieser Prüfung nicht.

---

## Gelieferte Dateien

- `life_satisfaction_countries.csv` — 72 Zeilen:
  - `life_satisfaction_cantril` (36 Länder, WHR 2026, Datenjahr 2025) — **neuester Stand,
    Länderseite, nicht mit der Staatendatei paarbar**
  - `life_satisfaction_cantril_gallup_2008_2017` (36 Länder, Table 13) — **nur diese Reihe
    ist zeitlich mit der Staatendatei paarbar, und auch sie nur unter dem Vorbehalt oben**
- `life_satisfaction_us_states.csv` — 51 Zeilen (50 Staaten + District of Columbia),
  `life_satisfaction_cantril_gallup_2008_2017`

Beide Dateien sind trotz negativer Empfehlung geliefert, weil Prüfung 1 formal positiv ist.
**Sie sind nicht als gemeinsame Rangliste zu verwenden.**

## Namenskonvention
Die Länderdateien nutzen die 35er-Namensliste des Auftrags plus `USA`; darin heißt das
Vereinigte Königreich `Vereinigtes Koenigreich`. Der bestehende Serien-Datensatz
(`countries_health.csv` etc.) nutzt dafür `UK` und enthält bisher nur 17 Länder —
vor dem Join ist zu mappen. Belegart: **abgelesen** (Spaltenwerte beider Dateien).

## Lücken / nicht geprüft
- Vignetten-Effektgröße in Leiterpunkten (Angelini et al. 2014, Volltext nicht zugänglich).
- Alle WHR-Ausgaben 2012–2026 einzeln auf ein Bundesstaaten-Kapitel durchgesehen.
- County Health Rankings als eigenständige Cantril-Quelle.
- Unpublizierte Gallup-Sonderauswertungen nach 2017.
