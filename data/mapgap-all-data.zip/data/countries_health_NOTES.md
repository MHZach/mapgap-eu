# Länderwerte Gesundheit — Gegenstück zu `us_states_health.csv`

Datei: `countries_health.csv` (128 Zeilen). Erstellt: 2026-09-18.
13 Länder: Deutschland, Frankreich, Italien, Spanien, Schweiz, UK, Daenemark, Norwegen,
Schweden, Finnland, Polen, Russland, USA. Alle Werte per API aus den unten genannten
Primärquellen gezogen; **kein Wert aus dem Gedächtnis ergänzt, keine Schätzung, keine Interpolation.**

Ländernamen ohne Umlaute (`Daenemark`), damit der Join mit der US-Datei nicht an der
Kodierung scheitert.

## Quellen-/Jahres-Homogenität je Kennzahl (die Pflichtzeile)

| Kennzahl | Alle 13 aus derselben Quelle? | Alle 13 aus demselben Jahr? | Abweichung |
|---|---|---|---|
| `life_expectancy_at_birth` (+ `_male`, `_female`) | **ja** — OECD Health Statistics | **ja** — 2022 | keine |
| `infant_mortality` | **ja** — OECD Health Statistics | **ja** — 2023 | keine |
| `adult_obesity` | **ja** — WHO GHO (NCD-RisC) | **ja** — 2024 | keine |
| `health_insurance_coverage` | **ja** — OECD Health Statistics | **ja** — 2020 | keine |
| `maternal_mortality` | **ja** — World Bank / WHO-MMEIG | **ja** — 2022 | keine |
| `adult_obesity_self_reported` (Zusatz) | ja — OECD | **NEIN** | Jahresmix 2019–2025, je Land der neueste verfügbare Wert |
| `adult_obesity_measured` (Zusatz) | ja — OECD | **NEIN** | nur 5/13 Länder, Jahre 2017–2023 |
| `infant_mortality_min22weeks` (Zusatz) | ja — OECD | ja — 2023 | nur 9/13 Länder |
| `maternal_mortality_registered` (Zusatz) | ja — OECD | ja — 2022 | nur 10/13 Länder |

Die fünf **Kernkennzahlen** erfüllen die Vorgabe vollständig: eine Quelle, ein Jahr, 13/13.
Die vier Zusatzkennzahlen sind bewusst inhomogen und dienen nur der Kalibrierung /
Fallendokumentation — **nicht in die Grafik ohne Kennzeichnung.**

## Quellen (exakt)

1. **Lebenserwartung, 2022** — OECD Health Statistics, Dataflow
   `OECD.ELS.HD,DSD_HEALTH_STAT@DF_LE`, MEASURE=LFEXP, AGE=Y0, SEX=_T/M/F.
   https://sdmx.oecd.org/public/rest/data/OECD.ELS.HD,DSD_HEALTH_STAT@DF_LE,1.0/all?format=csvfilewithlabels
   — Belegart: abgelesen (SDMX-API).
2. **Säuglingssterblichkeit, 2023** — OECD Health Statistics, Dataflow
   `OECD.ELS.HD,DSD_HEALTH_STAT@DF_MIM`, MEASURE=INM, GESTATION_THRESHOLD=NONE.
   https://sdmx.oecd.org/public/rest/data/OECD.ELS.HD,DSD_HEALTH_STAT@DF_MIM,1.0/all?format=csvfilewithlabels
   — Belegart: abgelesen.
3. **Adipositas, 2024** — WHO Global Health Observatory, Indikator `NCD_BMI_30C`
   („Obesity among adults, BMI >= 30 kg/m2, crude estimate, %", Alter 18+, beide Geschlechter).
   https://ghoapi.azureedge.net/api/NCD_BMI_30C — Belegart: abgelesen (API), Werte auf
   eine Nachkommastelle gerundet (`berechnet` nur insoweit: Rundung).
4. **Adipositas selbstberichtet / gemessen** — OECD Health Statistics, Dataflow
   `OECD.ELS.HD,DSD_HEALTH_LVNG@DF_HEALTH_LVNG_BW`, MEASURE=SP_OBS, SEX=_T,
   METHODOLOGY=SR bzw. MSRD. https://sdmx.oecd.org/public/rest/data/OECD.ELS.HD,DSD_HEALTH_LVNG@DF_HEALTH_LVNG_BW,1.0/all?format=csvfilewithlabels
   — Belegart: abgelesen.
5. **Krankenversicherungsabdeckung, 2020** — OECD Health Statistics, Dataflow
   `OECD.ELS.HD,DSD_HEALTH_PROT@DF_HEALTH_PROT`, INSURANCE_TYPE=**TPRIBASI**
   („Public and primary voluntary health insurance"), UNIT_MEASURE=PT_POP.
   https://sdmx.oecd.org/public/rest/data/OECD.ELS.HD,DSD_HEALTH_PROT@DF_HEALTH_PROT,1.0/all?format=csvfilewithlabels
   — Belegart: abgelesen.
6. **Müttersterblichkeit, 2022** — World Bank World Development Indicators `SH.STA.MMRT`
   (Quelle der Reihe: WHO/UNICEF/UNFPA/World Bank/UNDESA Maternal Mortality Estimation
   Inter-Agency Group, MMEIG). https://api.worldbank.org/v2/country/DEU;FRA;ITA;ESP;CHE;GBR;DNK;NOR;SWE;FIN;POL;RUS;USA/indicator/SH.STA.MMRT?format=json&date=2022
   — Belegart: abgelesen (API), auf ganze Zahl gerundet.
7. **Müttersterblichkeit registriert, 2022** (Zusatz) — OECD, `DF_MIM`, MEASURE=MATM.
   — Belegart: abgelesen.

## Definitionsfallen

### 1. Adipositas — der zentrale Vergleichsbruch
Die US-Bundesstaaten-Werte in `us_states_health.csv` stammen aus **BRFSS und sind
Selbstauskunft** (Telefoninterview, Größe und Gewicht vom Befragten genannt). Befragte
unterschätzen Gewicht und überschätzen Größe systematisch; BRFSS liegt dadurch deutlich
unter gemessenen Werten.

Drei Spalten in der CSV, `messmethode` trennt sie:

| Metrik | `messmethode` | Abdeckung | Vergleichbar mit BRFSS-Staatenwerten? |
|---|---|---|---|
| `adult_obesity` (WHO 2024) | `modelliert_ncd_risc` | 13/13 | **nein** — anderes Verfahren |
| `adult_obesity_self_reported` (OECD) | `self_reported` | 13/13, aber Jahresmix | **ja, methodisch** — aber Jahresmix |
| `adult_obesity_measured` (OECD) | `measured` | 5/13 | nein |

**Kalibrierungsbeleg (abgelesen):** Der OECD-`self_reported`-Wert für die USA 2024 ist
**34.2** — exakt der Median der 50 BRFSS-Staatenwerte 2024 (34.2) und damit erkennbar
dieselbe Quelle. Der WHO-Wert für die USA 2024 ist **41.8**, der OECD-`measured`-Wert
(NHANES) 2023 **40.8**. Die Differenz zwischen Selbstauskunft und Messung beträgt in den
USA also rund **7 Prozentpunkte**. Eine Grafik, die WHO-Länderwerte gegen BRFSS-Staatenwerte
stellt, verzerrt in dieser Größenordnung — zu Lasten der Länder.

**Konsequenz für die Grafik:** Entweder `adult_obesity_self_reported` verwenden (methodisch
sauber, Jahresmix ausweisen) **oder** `adult_obesity` (WHO) verwenden und die USA-Referenz
ebenfalls auf den WHO-Wert 41.8 setzen statt auf BRFSS. **Nicht** WHO-Länder gegen
BRFSS-Staaten stellen. Ungeklärt bleibt: NCD-RisC pooled Erhebungen unterschiedlicher
Qualität je Land — der niedrige Frankreich-Wert (12.5) ist gegenüber dem gemessenen
OECD-Wert 2017 (15.6) auffällig; **nicht geprüft**, worauf die Differenz beruht.

Alle Adipositas-Werte sind Rohprävalenz („crude"), **nicht** altersstandardisiert — wie
die US-Staatenwerte.

### 2. Säuglingssterblichkeit — Registrierung an der Lebensfähigkeitsgrenze
OECD führt diese Falle als **eigene Dimension** (`GESTATION_THRESHOLD`). Die USA
registrieren extrem früh Geborene als Lebendgeburt; mehrere europäische Länder tun das
nicht oder erst ab 22 Wochen / 500 g. Derselbe US-Jahrgang 2023:

- ohne Schwelle (`NONE`): **5.6** je 1.000 — das ist die Fassung in `infant_mortality`
- mit Schwelle 22 Wochen / 500 g (`WK22`): **4.8** je 1.000

Also ein Unterschied von 0.8 Punkten allein durch die Registrierungsdefinition — mehr als
der Abstand zwischen Deutschland (3.2) und Frankreich (4.0).

`infant_mortality` enthält für alle 13 Länder die `NONE`-Fassung, weil die
NCHS-Bundesstaatenwerte ebenfalls ohne Schwelle gezählt werden. Die `WK22`-Fassung liegt
als `infant_mortality_min22weeks` bei (9/13 Länder: Frankreich, Spanien, Schweiz, Daenemark,
Norwegen, Schweden, Finnland, Polen, USA). Für Deutschland, Italien, UK und Russland
meldet OECD keine `WK22`-Fassung — **Lücke, nicht Null.**

Gegenprobe (abgelesen): OECD-USA 2023 = 5.6; NCHS-linked-file 2023 = 5.61. Dieselbe Basis.

### 3. Krankenversicherung — Richtung der Größe
Die US-Datei führt `uninsured_rate` (Anteil **ohne** Versicherung, ACS 2024, Median 7.3 %).
Diese Datei führt `health_insurance_coverage` (Anteil **mit** Grundabsicherung).
Umrechnung: `coverage = 100 − uninsured`. **Nicht** ungeprüft mischen:

- Das OECD-Universum ist die **gesamte Bevölkerung**, ACS B27010 die **zivile,
  nicht-anstaltsuntergebrachte** Bevölkerung. Nicht identisch.
- Die Jahre differieren (OECD 2020 vs. ACS 2024). Der OECD-US-Wert 2020 ist 90.3,
  2023 bereits 92.4 — die US-Abdeckung ist in dem Zeitraum gestiegen. Ein Vergleich
  gegen ACS 2024 (≈ 92.7 aus 100 − 7.3 Median, **berechnet**) benachteiligt die USA
  um rund 2 Punkte.
- 2020 ist gewählt, weil es das **letzte Jahr ist, in dem Russland vorliegt**. Ohne
  Russland wäre 2023 möglich (12/13).

`COVGCMED` (nur staatlich/pflichtversichert) wurde **nicht** verwendet: dort steht die
USA bei 38.1 statt 90.3, weil die private Grundversicherung fehlt. Das wäre kein
Abdeckungsvergleich, sondern ein Systemvergleich.

### 4. Müttersterblichkeit — modelliert vs. registriert, und ein Pool gegen einen Jahreswert
- `maternal_mortality` (13/13, 2022) ist eine **modellierte MMEIG-Schätzung**, keine
  Registerzahl. Für kleine Länder mit wenigen Fällen ist die Unsicherheitsspanne breit;
  die Spanne ist in der CSV **nicht** mitgeführt (World-Bank-Reihe liefert nur den Punktwert).
- `maternal_mortality_registered` (10/13, 2022) ist die OECD-Registerzahl. Sie weicht ab:
  USA 22.3 registriert gegen 20 modelliert, Polen 2.0 gegen 2, Finnland 8.9 gegen 8.
  Für Frankreich, UK und Russland liefert OECD 2022 keinen Wert — **Lücke.**
- Die US-Bundesstaatenwerte sind ein **5-Jahres-Pool 2018–2022** (US-Gesamtwert des Pools:
  23.2), die Länderwerte hier sind **Jahreswerte 2022**. Das ist keine saubere Achse.
  Der registrierte US-Jahreswert 2022 (22.3) liegt nahe am Pool (23.2) — die Verzerrung
  ist klein, aber sie ist da. In der Grafik ausweisen.
- NCHS unterdrückt in der US-Datei 11 Staaten (< 20 Todesfälle). Fehlend heißt „klein",
  nicht „niedrig". Diese Asymmetrie gibt es auf Länderseite nicht — die Länderwerte sind
  vollständig. Ein Ranking „Land X gegen die 39 publizierten Staaten" ist kein Ranking
  gegen die 50.

### 5. Lebenserwartung — hier ist der Vergleich sauber
OECD-USA 2022 = **77.5**, identisch mit dem NCHS-Nationalwert 2022, aus dem auch die
State Life Tables 2022 stammen. Gleiches Jahr, gleiches System. Die Kennzahl trägt den
Vergleich ohne Vorbehalt. Männer/Frauen liegen mit bei (`_male` / `_female`); die US-Datei
enthält nur „Total", die geschlechtsgetrennten Staatenwerte stehen in der NCHS-Quelle,
sind aber **nicht** in `us_states_health.csv` übernommen.

### 6. Russland — Datenqualitätsvorbehalt ab 2022
Betroffen sind `life_expectancy_at_birth` (2022), `maternal_mortality` (2022),
`infant_mortality` (2023), `adult_obesity` (2024).

- Russische Vitalstatistik wird seit 2022 **eingeschränkt publiziert**; militärische
  Verluste gehen nicht regulär in die zivilen Sterbetafeln ein. Die Lebenserwartung der
  Männer (67.6 für 2022) ist dadurch mit hoher Wahrscheinlichkeit **zu günstig**
  ausgewiesen — Richtung bekannt, Größenordnung **nicht geprüft**.
- Die besetzten/annektierten Gebiete werden in russischen Meldungen teils mitgeführt,
  in OECD/WHO-Reihen uneinheitlich. **Nicht geprüft**, wie die hier gezogenen Reihen das
  behandeln.
- `health_insurance_coverage` für Russland ist 2020 — **vor** dem Zeitraum, der Vorbehalt
  greift dort nicht, dafür ist der Wert vier Jahre älter als bei den anderen Kennzahlen.
- `adult_obesity` Russland 2024 (WHO, modelliert) beruht auf Erhebungen, deren jüngste
  Datenpunkte **nicht geprüft** sind; bei einem modellierten Wert für ein Land mit
  eingeschränkter Meldepraxis ist der Extrapolationsanteil unbekannt.

Empfehlung: Russland in der Grafik markieren, nicht stillschweigend gleichbehandeln.

## Lücken (gemeldet, nicht geschätzt)

| Metrik | fehlt für | Grund |
|---|---|---|
| `adult_obesity_measured` | Deutschland, Italien, Spanien, Schweiz, Daenemark, Norwegen, Schweden, Polen (8/13) | diese Länder erheben Größe/Gewicht national nicht gemessen; OECD führt keinen Wert |
| `infant_mortality_min22weeks` | Deutschland, Italien, UK, Russland (4/13) | OECD meldet für diese Länder keine schwellenbereinigte Fassung |
| `maternal_mortality_registered` | Frankreich, UK, Russland (3/13) | OECD hat für 2022 keinen Registerwert |
| Unsicherheitsintervalle zu `maternal_mortality` und `adult_obesity` | alle | in den gezogenen Reihen nicht enthalten; WHO GHO liefert `Low`/`High`, wurde **nicht** übernommen |

Für die fünf **Kernkennzahlen gibt es keine Lücke** — 13/13 durchgängig.

## Was nicht geprüft wurde

- Ob OECD für einzelne Länder gebrochene Reihen / Definitionswechsel im Zeitverlauf
  ausweist (`OBS_STATUS`-Flags wurden gezogen, aber nicht ausgewertet).
- Die Altersstruktur hinter den Adipositas-Werten je Land (OECD `AGE` ist durchgängig `_T`,
  die zugrundeliegenden Erhebungsaltersgrenzen können abweichen).
- Eurostat als vierte Quelle wurde nicht herangezogen, weil Russland, Schweiz-Teilreihen
  und die USA dort nicht durchgängig vorliegen — eine gemeinsame Quelle für alle 13 war
  die höhere Priorität.
