# Ergaenzung: 14 weitere Laender — `countries_health_add14.csv`

Erstellt 2026-09-18. **Der Bestand `countries_health.csv` wurde nicht angefasst.**
132 Datenzeilen (+ Kopfzeile). Spalten identisch zum Bestand.

Laender: Portugal, Niederlande, Belgien, Oesterreich, Ungarn, Irland, Tschechien,
Lettland, Litauen, Estland, Kroatien, Griechenland, Bosnien, Israel.

Alle Werte stammen aus denselben Rohabrufen wie der Bestand (OECD SDMX,
WHO GHO, World Bank API), gezogen am 2026-09-18.
**Kein Wert aus dem Gedaechtnis, keine Schaetzung, keine Interpolation.**
Belegart durchgaengig `abgelesen`; bei `adult_obesity` und `maternal_mortality`
ist die Rundung der einzige rechnerische Eingriff (wie im Bestand).

## Gegenprobe gegen den Bestand (Beleg, dass dieselbe Reihe gezogen wurde)

Vor der Extraktion wurde Deutschland aus denselben Rohdateien mitgezogen und
gegen die Bestandszeile verglichen. **Alle acht Kontrollwerte treffen exakt:**

| Kennzahl | Bestand DEU | Nachgezogen DEU |
|---|---|---|
| `life_expectancy_at_birth` | 80.7 | 80.7 |
| `life_expectancy_at_birth_male` | 78.3 | 78.3 |
| `life_expectancy_at_birth_female` | 83 | 83 |
| `infant_mortality` | 3.2 | 3.2 |
| `adult_obesity_self_reported` | 17.9 (2025) | 17.9 (2025) |
| `adult_obesity` (WHO) | 24.5 | 24.5 |
| `health_insurance_coverage` | 99.9 | 99.9 |
| `maternal_mortality` | 4 | 4 |

Damit ist belegt, dass Filter (MEASURE, AGE, SEX, METHODOLOGY, INSURANCE_TYPE,
GESTATION_THRESHOLD, UNIT_MEASURE) identisch gesetzt sind. Die Zeilen sind
zusammenfuegbar.

## Abdeckung je Kennzahl (von 14)

| Kennzahl | Quelle | Jahr | Abdeckung | fehlt |
|---|---|---|---|---|
| `life_expectancy_at_birth` (+`_male`,`_female`) | OECD `DF_LE` | 2022, einheitlich | **13/14** | Bosnien |
| `infant_mortality` | OECD `DF_MIM`, THRESHOLD=NONE | 2023, einheitlich | **13/14** | Bosnien |
| `adult_obesity` | WHO GHO `NCD_BMI_30C` | 2024, einheitlich | **14/14** | — |
| `health_insurance_coverage` | OECD `DF_HEALTH_PROT`, TPRIBASI | 2020, einheitlich | **12/14** | Kroatien, Bosnien |
| `maternal_mortality` | World Bank `SH.STA.MMRT` (MMEIG) | 2022, einheitlich | **14/14** | — |
| `adult_obesity_self_reported` (Zusatz) | OECD `DF_..._BW`, METHODOLOGY=SR | **Jahresmix 2019–2025** | 13/14 | Bosnien |
| `adult_obesity_measured` (Zusatz) | OECD, METHODOLOGY=MSRD | **Jahresmix 2010–2024** | 8/14 | Niederlande, Oesterreich, Litauen, Kroatien, Griechenland, Bosnien |
| `infant_mortality_min22weeks` (Zusatz) | OECD, THRESHOLD=WK22 | 2023, einheitlich | 6/14 | Portugal, Niederlande, Belgien, Irland, Litauen, Kroatien, Griechenland, Bosnien |
| `maternal_mortality_registered` (Zusatz) | OECD, MEASURE=MATM | 2022, einheitlich | 13/14 | Bosnien |

**Kein Jahrgang wurde ersetzt.** Wo ein Land im geforderten Jahr fehlt, steht keine
Zeile — es wurde kein Nachbarjahr eingesetzt. Einzige Ausnahme ist die Kennzahl
`adult_obesity_self_reported`, die schon im Bestand als Jahresmix gefuehrt wird
(je Land der neueste verfuegbare Wert); das Erhebungsjahr steht in der Spalte `year`.

## Erhebungsjahr `adult_obesity_self_reported` je Land (Pflichtangabe)

| Land | Wert | Jahr | Land | Wert | Jahr |
|---|---|---|---|---|---|
| Portugal | 15.9 | 2022 | Litauen | 20.3 | 2022 |
| Niederlande | 15.2 | **2024** | Estland | 19.9 | **2024** |
| Belgien | 17.0 | 2023 | Kroatien | 22.6 | **2019** |
| Oesterreich | 16.6 | **2019** | Griechenland | 12.2 | 2022 |
| Ungarn | 22.2 | 2022 | Israel | 19.9 | **2025** |
| Irland | 21.3 | **2024** | Lettland | 24.0 | **2025** |
| Tschechien | 19.3 | **2019** | Bosnien | — | LUECKE |

Spannweite der Erhebungsjahre: **2019–2025, sechs Jahre.** Der Bestand hat
denselben Mix (2019–2025). Wird eine Jahresregel angelegt (z. B. „nicht aelter
als 2022"), fallen **Oesterreich, Tschechien und Kroatien** heraus — dann sind es
10/14 statt 13/14. Fuer diese drei Laender fuehrt die OECD keinen juengeren
SR-Wert; Ersatz aus einem anderen Jahr waere Erfindung, nicht Ablesung.

## Bosnien — Abwesenheit im Rohabruf belegt, nicht angenommen

Bosnien und Herzegowina (ISO `BIH`) ist weder OECD- noch EU-Mitglied. Geprueft
wurde nicht per Annahme, sondern durch Auszaehlen der Dimension `REF_AREA` in den
vier heruntergeladenen OECD-Rohdateien:

| OECD-Dataflow | Zeilen im Rohabruf | REF_AREA-Codes | `BIH` enthalten? |
|---|---|---|---|
| `DSD_HEALTH_STAT@DF_LE` (Lebenserwartung) | 52.241 | 51 | **nein** |
| `DSD_HEALTH_STAT@DF_MIM` (Saeuglings-/Muettersterblichkeit) | 11.829 | 51 | **nein** |
| `DSD_HEALTH_LVNG@DF_HEALTH_LVNG_BW` (Koerpergewicht) | 6.970 | 50 | **nein** |
| `DSD_HEALTH_PROT@DF_HEALTH_PROT` (Versicherungsabdeckung) | 11.803 | 46 | **nein** |

`BIH` kommt in **keiner** der vier Reihen in **keinem** Jahr vor. Das ist ein
belegtes Fehlen der gesamten Laenderachse, nicht ein fehlender Jahrgang.

Ausgewichen wurde, wie beauftragt, auf die beiden Nicht-OECD-Quellen — dort ist
Bosnien gefuehrt:

- `adult_obesity` = **26.1 %** (WHO GHO `NCD_BMI_30C`, 2024, modelliert, abgelesen)
- `maternal_mortality` = **12** je 100.000 (World Bank `SH.STA.MMRT`, 2022,
  MMEIG-Modellschaetzung, abgelesen)

Damit hat Bosnien **2 von 11** Kennzahlen. Lebenserwartung, Saeuglingssterblichkeit
und Versicherungsabdeckung bleiben offen. **Beide vorhandenen Bosnien-Werte sind
modelliert, keiner ist eine Registerzahl** — Bosnien ist in einer Grafik damit
methodisch nicht auf einer Stufe mit den OECD-Laendern und sollte markiert werden.

## Kroatien — die zweite, weniger offensichtliche Luecke

Kroatien ist OECD-Beitrittskandidat und **im Coverage-Dataflow vorhanden** (41
Zeilen), fuehrt dort aber ausschliesslich `INSURANCE_TYPE=PHINSUPI` (private
Zusatz-/Primaerversicherung, 2002–2024). Die im Bestand verwendete Reihe
`TPRIBASI` („public and primary voluntary health insurance") existiert fuer
Kroatien **in keinem Jahr**. Deshalb keine Zeile.

Das ist ausdruecklich **keine niedrige Abdeckung**, sondern eine fehlende Reihe.
`PHINSUPI` als Ersatz einzusetzen waere ein Definitionsbruch: es misst etwas
anderes (Zusatzversicherung statt Grundabsicherung) und wuerde Kroatien in der
Grafik faelschlich ans untere Ende stellen.

## Definitionsfallen (zusaetzlich zu denen im Bestands-NOTES)

### 1. Zwei Beobachtungsstatus-Flags bei der Saeuglingssterblichkeit 2023
Die OECD markiert zwei der 13 Werte:

- **Irland 3.0** — `OBS_STATUS = P` (provisional / vorlaeufig)
- **Niederlande 3.6** — `OBS_STATUS = E` (estimated / geschaetzt)

Beide Werte sind uebernommen (sie stehen so in der Quelle), aber sie sind nicht
gleichwertig mit den elf unmarkierten. Der Bestand fuehrt die `OBS_STATUS`-Spalte
nicht mit — das NOTES des Bestands vermerkt das bereits als „nicht ausgewertet".
Hier ist es ausgewertet und wird gemeldet.

### 2. Drei registrierte Muettersterblichkeits-Werte sind exakt 0
`maternal_mortality_registered` 2022: **Estland 0, Litauen 0, Irland 0.**
Das ist eine echte Null im Register (kein gemeldeter Muttertod im Kalenderjahr),
nicht ein fehlender Wert. Bei Laendern dieser Groesse ist ein Jahreswert von 0
jedoch fast reines Zufallsrauschen — die MMEIG-Modellwerte derselben Laender
liegen bei 7, 9 und 7. **Eine Grafik, die die Registerreihe zeigt, behauptet fuer
drei Laender ein Nullrisiko, das nicht besteht.** Fuer den Vergleich die
modellierte Reihe `maternal_mortality` nehmen.

Gegenrichtung, gleiche Kennzahl: **Lettland 31.6 registriert gegen 29 modelliert**
— beide hoch, aber bei rund 17.000 Geburten im Jahr beruht der Registerwert auf
einer einstelligen Fallzahl. Auch hier kein belastbarer Jahreswert.

### 3. `adult_obesity_measured` ist hier noch inhomogener als im Bestand
Die acht vorhandenen Werte streuen ueber **2010 bis 2024** (Tschechien 2010,
Estland 2014, Portugal 2015, Israel 2015, Ungarn 2019, Irland 2019, Belgien 2023,
Lettland 2024). Ein 14 Jahre alter Wert neben einem zwei Jahre alten ist kein
Querschnitt. Nicht in eine Rangliste geben.

### 4. Der Selbstauskunft-/Messung-Abstand ist laenderspezifisch, nicht konstant
Wo beide Methoden vorliegen, klafft es unterschiedlich weit:
Portugal 15.9 (SR) gegen 28.7 (gemessen) = **12.8 Punkte**;
Ungarn 22.2 gegen 33.2 = 11.0; Tschechien 19.3 gegen 21.0 = 1.7;
Lettland 24.0 gegen 24.3 = 0.3; Irland 21.3 gegen 22.2 = 0.9.
Die im Bestands-NOTES fuer die USA genannte Faustzahl von rund 7 Punkten ist
**keine uebertragbare Korrektur.** Die Jahrespaare sind teils weit auseinander
(Portugal SR 2022 gegen MSRD 2015), der Abstand mischt also Methode und Zeit —
**nicht geprueft**, wie er sich aufteilt.

### 5. Ungarn bei der Versicherungsabdeckung
`health_insurance_coverage` Ungarn 2020 = **95.0** — der niedrigste Wert der 14
und unter allen 13 europaeischen Bestandslaendern ausser Polen (93.3). Der Wert
ist abgelesen, nicht geprueft ist, ob die ungarische Meldung dieselbe
Bevoelkerungsbasis verwendet wie die uebrigen.

## Nicht geprueft

- `OBS_STATUS`-Flags ausserhalb der Saeuglingssterblichkeit (gezogen, nur dort ausgewertet).
- Ob die OECD fuer einzelne der 14 Laender Reihenbrueche/Definitionswechsel im
  Zeitverlauf ausweist.
- Die Unsicherheitsintervalle zu `adult_obesity` (WHO liefert `Low`/`High`) und zu
  `maternal_mortality` (MMEIG-Spanne) — wie im Bestand nicht uebernommen.
- Ob Bosnien in Eurostat oder WHO-Europe-Reihen mit Lebenserwartung und
  Saeuglingssterblichkeit gefuehrt wird. Das waere eine **andere Quelle als der
  Bestand** und haette die Homogenitaet gebrochen; deshalb hier als Luecke
  gemeldet statt aus einer Fremdquelle gefuellt.
