# US-Bundesstaaten — Gesundheits-/Demografie-Vergleichsbasis

Datei: `us_states_health.csv` (243 Zeilen, je Zeile eine (metric, state)-Kombination).
Erstellt: 2026-09-18. Alle Werte stammen aus den unten genannten Primärquellen;
kein Wert aus dem Gedächtnis ergänzt, keine Schätzungen.

DC ist in der CSV als eigene Zeile (`District of Columbia`) enthalten, zählt aber
**nicht** zu den 50 Staaten. Alle Min/Max/Median unten sind **ohne DC** gerechnet.

## Vollständigkeit

| Kennzahl | Staaten mit Wert | DC |
|---|---|---|
| life_expectancy_at_birth | 50/50 | 76.6 |
| infant_mortality | 50/50 | 6.97 |
| adult_obesity | 50/50 (49× 2024, Tennessee 2023) | 25.5 |
| uninsured_rate | 50/50 | 4.5 |
| maternal_mortality | 39/50 | kein Wert (unterdrückt) |

## Min / Max / Median über die 50 Staaten

| Kennzahl | Einheit | Jahr | Min | Median | Max |
|---|---|---|---|---|---|
| Lebenserwartung bei Geburt | Jahre | 2022 | 72.2 (West Virginia) | 77.3 | 80.0 (Hawaii) |
| Säuglingssterblichkeit | je 1.000 Lebendgeburten | 2023 | 2.93 (New Hampshire) | 5.645 | 8.94 (Mississippi) |
| Erwachsenen-Adipositas | % | 2024 | 25.0 (Colorado) | 34.2 | 41.4 (West Virginia) |
| Ohne Krankenversicherung | % | 2024 | 2.8 (Massachusetts) | 7.3 | 16.7 (Texas) |
| Müttersterblichkeit | je 100.000 Lebendgeburten | 2018–2022 gepoolt | 10.5 (California) | 23.9 | 41.1 (Tennessee) |

Median Müttersterblichkeit ist der Median der **39 publizierten** Staaten, nicht der 50 —
und die 11 fehlenden sind systematisch kleine Staaten (siehe Lücken). Der Median ist
dadurch nach oben verzerrt; er ist **berechnet**, nicht abgelesen.

## Quellen (exakt)

1. **Lebenserwartung, 2022** — NCHS/NVSS, *National Vital Statistics Reports* Vol. 74 No. 12,
   „U.S. State Life Tables, 2022", Tabelle A (Gesamtbevölkerung, beide Geschlechter).
   https://www.cdc.gov/nchs/data/nvsr/nvsr74/nvsr74-12.pdf — Belegart: abgelesen (PDF-Tabelle geparst).
2. **Säuglingssterblichkeit, 2023** — NCHS/NVSS linked birth/infant death file,
   *NVSR* Vol. 74 No. 7, „Infant Mortality in the United States, 2023", Tabelle 5.
   https://www.cdc.gov/nchs/data/nvsr/nvsr74/nvsr74-07.pdf — Belegart: abgelesen.
3. **Adipositas, 2024** — CDC BRFSS über den Datensatz „Nutrition, Physical Activity, and Obesity —
   BRFSS" (data.cdc.gov, `hn4x-zwk7`), Frage Q036, Stratifikation „Total".
   https://data.cdc.gov/resource/hn4x-zwk7.json?yearstart=2024&questionid=Q036&stratificationid1=OVERALL
   — Belegart: abgelesen (API).
4. **Ohne Krankenversicherung, 2024** — U.S. Census Bureau, ACS 1-Year Estimates 2024,
   Detailtabelle B27010. https://www2.census.gov/programs-surveys/acs/summary_file/2024/table-based-SF/data/1YRData/acsdt1y2024-b27010.dat
   — Belegart: **berechnet** aus abgelesenen Zählwerten:
   `(B27010_E017 + E033 + E050 + E066) / B27010_E001`, auf eine Nachkommastelle gerundet.
5. **Müttersterblichkeit, 2018–2022** — NCHS/NVSS, „Maternal deaths and mortality rates:
   Each state, the District of Columbia, United States, 2018–2022".
   https://www.cdc.gov/nchs/maternal-mortality/mmr-2018-2022-state-data.pdf — Belegart: abgelesen.

## Definitionsfallen

1. **Adipositas ist selbstberichtet, nicht gemessen.** BRFSS berechnet den BMI aus
   telefonisch angegebener Größe und Gewicht. Das unterschätzt die Prävalenz systematisch
   gegenüber gemessenen Werten (NHANES misst; NHANES-Werte liegen deutlich höher und sind
   **nicht** je Bundesstaat verfügbar). Ein Ländervergleich mit gemessenen WHO-/OECD-Werten
   vergleicht damit zwei verschiedene Messverfahren — das muss in der Grafik stehen.
   Die Werte sind Rohprävalenz („crude"), **nicht** altersstandardisiert.
2. **Tennessee hat für 2024 keinen publizierten Adipositas-Wert.** Der Datensatz enthält
   die Zeile, aber ohne `data_value`. In der CSV steht deshalb der Wert 2023 (37.6), mit
   `year=2023` und entsprechendem Hinweis in `source_name`. Jahresmix in dieser Kennzahl.
3. **Jahresmix zwischen den Kennzahlen.** 2022 (Lebenserwartung), 2023 (Säuglingssterblichkeit),
   2024 (Adipositas, Versicherung), 2018–2022 (Müttersterblichkeit). Für Bundesstaaten gibt es
   für 2023/2024 **keine** publizierten Lebenserwartungs-Tabellen; NCHS hat für 2023 nur
   nationale Werte veröffentlicht.
4. **Müttersterblichkeit ist ein 5-Jahres-Pool, kein Jahreswert.** Rate je 100.000 Lebendgeburten
   über 2018–2022 zusammengefasst. Vergleiche mit dem nationalen Jahreswert (2023: 18.6) sind
   nicht zulässig; der gepoolte US-Wert 2018–2022 ist 23.2.
5. **Müttersterblichkeit — Unterdrückung ist kein Nullwert.** NCHS unterdrückt Raten bei
   weniger als 20 Todesfällen (Reliabilität + Vertraulichkeit). Fehlend heißt „klein", nicht
   „niedrig". Betroffen: Alaska, Delaware, Hawaii, Maine, Montana, New Hampshire, North Dakota,
   Rhode Island, South Dakota, Vermont, Wyoming — sowie DC. **Keine Interpolation, keine Schätzung.**
   NCHS selbst warnt, dass ein Teil der Streuung zwischen Staaten auf Unterschiede in der
   Erfassungsqualität (Schwangerschafts-Checkbox im Totenschein) zurückgeht, nicht auf Risiko.
6. **Unversicherten-Quote: Universum ist die zivile, nicht-anstaltsuntergebrachte Bevölkerung
   aller Altersgruppen** (B27010), nicht „unter 65". Verbreitete alternative Zahlen (z. B. KFF
   „nonelderly uninsured", Census SAHIE) beziehen sich auf 0–64 Jahre und liegen deshalb höher.
   Nicht mischen.
7. **Säuglingssterblichkeit stammt aus der linked-file-Fassung** (5.61 US-weit) und weicht
   minimal von der Mortality-File-Fassung (5.60) ab. Ab 2023 sind die Sätze gewichtet
   (1,2 % nicht verknüpfbare Sterbefälle). Für Staatenvergleiche unerheblich, für exakte
   Zitate relevant.
8. **Lebenserwartung: Gesamtbevölkerung.** Die Quelle enthält zusätzlich Werte je Geschlecht
   (Männer/Frauen); in der CSV steht nur „Total". Rankings in der Quelle basieren auf
   ungerundeten Werten — bei gleichen gerundeten Werten (z. B. 73.8 für Oklahoma, Tennessee,
   Alabama, Louisiana) ist die Reihenfolge aus der CSV **nicht** ableitbar.

## Lücken

- `maternal_mortality`: 11 Staaten + DC ohne Wert (siehe Punkt 5). 39/50 abgedeckt.
- `adult_obesity`: Tennessee nur mit Jahr 2023.
- Keine weiteren Lücken; Lebenserwartung, Säuglingssterblichkeit und Versicherungsquote
  sind für alle 50 Staaten + DC belegt.
