# wage_percentiles_us_states.csv — Notizen, Definitionsfallen, Lücken

Stand: 2026-09-18. Ergänzungsdatei zu `wage_distribution_us_states.csv` (deren Zeilen sind
unverändert geblieben — hier steht nur, was dort fehlte: die Perzentile und die daraus
gebildeten Dezilverhältnisse).

## 1. Was drin ist

51 Gebiete (50 Bundesstaaten + District of Columbia), je 9 Metriken = **459 Datenzeilen**.

| metric | Einheit | Belegart | Herkunftsspalte |
|---|---|---|---|
| `hourly_wage_pct10` / `_pct25` / `_pct75` / `_pct90` | USD je Stunde | abgelesen | `H_PCT10` / `H_PCT25` / `H_PCT75` / `H_PCT90` |
| `annual_wage_pct10` / `annual_wage_pct90` | USD | abgelesen | `A_PCT10` / `A_PCT90` |
| `wage_ratio_p90_p10` / `_p90_p50` / `_p50_p10` | Verhältnis | **berechnet** | aus `H_PCT90` / `H_MEDIAN` / `H_PCT10` derselben Zeile |

**Quelle (alle Zeilen):** U.S. Bureau of Labor Statistics, *Occupational Employment and Wage
Statistics (OEWS)*, Schätzstand **Mai 2025** (neuester verfügbarer Stand am 2026-09-18),
Datei `state_M2025_dl.xlsx` aus `oesm25st.zip`.
Filter: `OCC_CODE = 00-0000` ("All Occupations"), `O_GROUP = total`, `NAICS = 000000`
(cross-industry), `OWN_CODE = 1235` (alle Eigentumsformen), `AREA_TYPE = 2` (Bundesstaat).
- https://www.bls.gov/oes/special-requests/oesm25st.zip
- Datentyp-Codes geprüft, nicht geraten: https://download.bls.gov/pub/time.series/oe/oe.datatype
  (06 = Hourly 10th percentile, 07 = 25th, 08 = median, 09 = 75th, 10 = 90th; 11–15 = die
  annualen Entsprechungen). Die im Auftrag genannte Seite `hlpforma.htm#OE` führt die
  OEWS-Codes **nicht**; die maßgebliche Liste ist die `oe.datatype`-Datei.

**Konsistenz-Gegenprobe (berechnet):** Der `H_MEDIAN` dieser Datei wurde gegen den bereits in
`wage_distribution_us_states.csv` stehenden `median_hourly_wage_oews` gestellt — maximale
Abweichung **0,0000 über alle 51 Gebiete**. Die Perzentile stammen also nachweislich aus
derselben Erhebung wie der dort vorhandene Median; die Auflage "p50 aus derselben Erhebung"
ist erfüllt.

## 2. Lücken

**Keine.** Alle 51 Gebiete haben in allen 6 abgelesenen Feldern einen Wert; keine Zelle war
mit `*`, `**`, `#` oder `~` unterdrückt. Auf der Aggregationsebene "All Occupations × ganzer
Bundesstaat" ist OEWS-Unterdrückung auch nicht zu erwarten — sie greift bei dünn besetzten
Beruf-×-Gebiet-Zellen. Die Nullmeldung gilt ausschließlich für diese Ebene: wer später auf
Berufsebene heruntergeht, bekommt Unterdrückungen, und **unterdrückt heißt dann Lücke, nicht
null**.

## 3. PRÜFPUNKT: Vergleichbarkeit mit den OECD-Dezilverhältnissen (DEC_I)

### 3.1 Die vier Definitionsbrüche

Die Staaten-Werte hier und die Länder-Werte in `wage_distribution_countries.csv`
(`earnings_decile_ratio_d9_d1`, OECD `DSD_EARNINGS@DEC_I`) messen **nicht dasselbe**:

| | OEWS (Staaten) | OECD DEC_I (Länder) |
|---|---|---|
| Grundgesamtheit | Vollzeit **und Teilzeit** | nur **Vollzeit** |
| Zähleinheit | **Arbeitsverhältnisse** (Jobs); wer zwei Jobs hat, zählt zweimal | **Personen** |
| Gemessene Größe | Lohn**satz** (Jahreswert = Stundensatz × 2080 unterstellt) | tatsächlich bezogener **Bruttojahresverdienst** |
| Lohnbegriff | Grundlohn, Provisionen, Leistungsprämien, Trinkgeld — **ohne Überstunden-, ohne sonstige Bonus-, ohne Aktienvergütung** | Bruttoverdienst, üblicherweise **einschließlich** Überstunden und Boni |
| Ausgeschlossen | Selbständige, Inhaber/Gesellschafter nicht inkorporierter Firmen, Hausangestellte, mithelfende Familienangehörige | abhängig Beschäftigte (insoweit gleichgerichtet) |
| Referenzjahr hier | 2025 | 2024 |

(Grundgesamtheit, Zähleinheit, 2080-Regel, Lohnbegriff und Ausschlüsse: **abgelesen** aus der
OEWS-FAQ, https://www.bls.gov/oes/oes_ques.htm. Die OECD-Definition: **abgelesen** aus dem
`source_name`-Feld der bestehenden Länder-Datei.)

Die zwei größten Verzerrungen laufen **in entgegengesetzte Richtungen**:

1. **Teilzeit drin → Verhältnis zu hoch.** Teilzeitarbeit häuft sich in Niedriglohn-Berufen.
   Deren niedrige Stunden**sätze** drücken das p10 gegenüber einer Vollzeit-Grundgesamtheit.
   OEWS-D9/D1 fällt dadurch höher aus als eine OECD-konforme Rechnung. (**inferiert** —
   Richtung folgt logisch aus der Grundgesamtheit, die Größe ist aus dieser Datei nicht
   messbar.)
2. **Boni und Überstunden raus → Verhältnis zu niedrig.** Nicht-Leistungsboni und
   Aktienvergütung fallen fast ausschließlich am oberen Ende an. Ihr Fehlen kappt das p90.
   Gerade in den USA ist dieser Anteil groß. (**inferiert**, gleiche Einschränkung.)

Eine dritte, kleinere Verzerrung: die 2080-Stunden-Hochrechnung entfernt die
Stunden**menge** aus der Rechnung. Eine echte Jahresverdienst-Verteilung *aller*
Beschäftigten wäre deutlich gespreizter als OEWS. OEWS liegt also zwischen
"Vollzeit-Jahresverdienste" und "Jahresverdienste aller".

### 3.2 Wie stark der Bruch ist — gemessen, nicht vermutet

Der Schaden lässt sich **beziffern**, weil es dasselbe Land in beiden Messweisen gibt:

| Größe | Wert | Belegart |
|---|---|---|
| OEWS, USA gesamt, Mai 2025: `H_PCT90` 61,81 / `H_PCT10` 15,00 → p90/p10 | **4,121** | berechnet (Quelle: `national_M2025_dl.xlsx` aus https://www.bls.gov/oes/special-requests/oesm25nat.zip) |
| OECD DEC_I, USA, 2024, D9/D1 | **4,7903** | abgelesen (`wage_distribution_countries.csv`) |
| Methodenfaktor OECD ÷ OEWS | **1,162** | berechnet |

Dasselbe Land, praktisch dieselbe Zeit, **16 % Unterschied allein aus der Methode**. Der
Boni-Effekt überwiegt hier offensichtlich den Teilzeit-Effekt; die beiden Verzerrungen heben
sich also nicht auf.

Praktische Folge für ein gemeinsames Ranking: die 50 Staaten liegen zwischen 3,00 (Maine) und
4,60 (Texas), DC bei 4,92. Ungerechnet landen damit **alle 50 Staaten unter dem OECD-Wert
ihres eigenen Landes** — Texas erschiene "gleicher" als die USA, Maine (3,00) nur knapp über
Polen (3,52 OECD). Nach Korrektur mit 1,162 läge Maine bei ≈ 3,49, Texas bei ≈ 5,34, DC bei
≈ 5,72. Das verschiebt fast jeden Staat um mehrere Plätze durch das Länderfeld, dessen
OECD-Werte zwischen 2,21 (Schweden) und 4,79 (USA) liegen. Der Methodenfehler ist also **größer
als die Abstände, die das Ranking darstellen soll**.

### 3.3 Ein fünfter Bruch, der keine Rechenkorrektur kennt: die Ebene

Ein Land enthält seine **regionale** Lohnspreizung mit; ein Bundesstaat nicht. Deutschland
(2,89) misst auch den Abstand München–Mecklenburg; Vermont misst nur Vermont. Das ist nicht
Messfehler, sondern eine andere Grundgesamtheit — die Ebenen werden gekreuzt. Der saubere
Gegenpart zu einem US-Bundesstaat ist eine europäische Region (NUTS-2), nicht ein Staat; der
saubere Gegenpart zu Deutschland ist die USA insgesamt.

### 3.4 Empfehlung

- **Staaten gegen Staaten ranken: tragfähig.** Alle 51 Gebiete kommen aus derselben Datei,
  derselben Definition, demselben Jahr. Die Verzerrungen aus 3.1 wirken auf alle 51 gleich
  gerichtet und heben sich im *Vergleich untereinander* weitgehend heraus. Das Ranking
  Maine → Texas ist belastbar.
- **Eine gemeinsame Rangliste "Land-D9/D1 gegen Staaten-D9/D1": nicht tragfähig.**
  Nicht wegen allgemeiner Vorbehalte, sondern weil (a) der gemessene Methodenversatz von 16 %
  größer ist als die meisten Rangabstände im Länderfeld, und (b) der Ebenenbruch aus 3.3 durch
  keinen Faktor zu heilen ist. Eine solche Liste würde Rangfolgen erzeugen, die allein von der
  Erhebungsmethode stammen.
- **Wenn ein Bezug zwischen beiden Achsen gebraucht wird**, dann so: die Staatenwerte als
  eigene Skala zeigen und **nur den US-Gesamtwert** (OEWS 4,12 bzw. OECD 4,79) als Anker
  danebenstellen — Aussage: "innerhalb der USA reicht die Spreizung von Maine bis Texas um den
  Faktor 1,5; die USA als Ganzes liegen im Ländervergleich an der Spitze". Das ist gedeckt.
- **Eine Umskalierung der Staaten mit 1,162 ist möglich**, muss dann aber als **Annahme**
  gekennzeichnet werden: der Faktor ist national gemessen, seine Konstanz über die Staaten ist
  **nicht geprüft** und in Staaten mit hohem Finanz-/Tech-Anteil (Boni, Aktien) vermutlich
  größer als in Maine. Für eine Rangliste taugt er deshalb nicht.

## 4. Weitere Definitionsfallen

- **`annual_wage_pct10` / `_pct90` sind keine Jahreseinkommen.** Sie sind der jeweilige
  Stundensatz × 2080 (abgelesen, OEWS-FAQ). Für eine Einkommens-Aussage nicht verwendbar; sie
  stehen hier, weil sie ohne Mehraufwand mitkamen.
- **Die Verhältniszahlen wurden aus den STUNDEN-Perzentilen gebildet**, nicht aus den annualen.
  Begründung: die Stundenwerte sind die primär erhobene Größe, die annualen sind daraus
  abgeleitet. Sachlich ändert das kaum etwas, sollte aber bekannt sein, wenn jemand
  nachrechnet und minimal abweichende Werte erhält.
- **DC ist kein Bundesstaat.** Es ist eine reine Innenstadt-Arbeitsmarktregion ohne Umland und
  liegt bei 4,92 deutlich über jedem Staat. In Staaten-Statistiken (Min/Median/Max) gehört es
  **nicht** hinein; in der CSV steht es als eigene Zeile, damit jeder selbst entscheiden kann.
- **Perzentil-Schätzung:** seit Mai 2022 verwendet OEWS gemeldete Lohnsätze statt der früheren
  12 Lohnintervalle mit offener oberer Klasse (abgelesen, OEWS-FAQ). Die Perzentile für Mai
  2025 sind daher nicht mehr intervall-modelliert. Ob es darüber hinaus noch eine
  Top-Kodierung gibt, ist **nicht geprüft**; für "All Occupations" mit einem p90 um 48–62 USD/h
  wäre sie ohnehin nicht bindend.
- **Kein Ranking gegen `wage_distribution_countries.csv` ohne Lesen von Abschnitt 3.**
