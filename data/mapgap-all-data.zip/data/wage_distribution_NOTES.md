# Lohnverteilung — Median statt Durchschnitt

Stand: 2026-09-18. Dateien: `wage_distribution_countries.csv` (119 Zeilen + Kopf),
`wage_distribution_us_states.csv` (255 Zeilen + Kopf).

Leitfrage: Wird der US-Durchschnittslohn durch Spitzenverdiener hochgezogen — und wie
sieht der Vergleich mit dem Median aus?

---

## 0. Der Vorbefund war ein Artefakt der Quellenmischung

Der Ausgangspunkt („Median = rund 65 % des Durchschnitts, New York 51 %, Mississippi 73 %")
entsteht, weil ein QCEW-Durchschnitt (Arbeitsverhältnisse, 2025) gegen einen
ACS-B20002-Median (Personen mit Erwerbseinkommen, inkl. Teilzeit und Teiljahr, 2024)
gerechnet wurde. Zwei Erhebungen, zwei Grundgesamtheiten, zwei Jahre.

Aus **einer** Quelle gerechnet (BLS OEWS Mai 2025, Median und Mittelwert derselben
Erhebung, dieselben Arbeitsverhältnisse, dasselbe Jahr):

| Median/Durchschnitt | gemischt (QCEW ÷ ACS) | rein OEWS |
|---|---|---|
| New York | 0,512 | 0,724 |
| Mississippi | 0,735 | 0,790 |
| Median der 51 Gebiete | 0,648 | 0,782 |

*berechnet*, Quellen siehe CSV-Zeilen `median_to_mean_wage_ratio_oews`.

Rund zwei Drittel des scheinbaren „Spitzenverdiener-Effekts" in New York waren also
Definitionsunterschied, nicht Verteilung. Die reale Schiefe bleibt — sie ist nur etwa
halb so groß wie der Vorbefund nahelegte.

---

## 1. Was in den Dateien steht

### `wage_distribution_countries.csv`
| metric | Quelle | Jahr | abgedeckt |
|---|---|---|---|
| `earnings_decile_ratio_d9_d1` / `_d9_d5` / `_d5_d1` | OECD DEC_I, Vollzeitbeschäftigte | 2024 | 12 von 13 (Russland fehlt) |
| `median_to_mean_earnings_ratio` | *berechnet* aus OECD MIN2AVE | 2024 | 6 (DE, FR, ES, UK, PL, US) |
| `average_annual_wage_ppp_2024` | OECD AV_AN_WAGE, USD KKP | 2024 | 12 (Russland fehlt) |
| `median_annual_earnings_ppp_impliziert` | *inferiert*, Produkt der beiden Zeilen darüber | 2024 | 6 |
| `median_gross_annual_earnings` | Eurostat SES 2022 / ONS ASHE / BLS OEWS | 2022 bzw. 2025 | 12 (Russland fehlt) — **drei Quellen, nicht mischen** |
| `median_gross_hourly_earnings` (+ `_pps`) | Eurostat SES 2022 / ONS ASHE / BLS OEWS | 2022 bzw. 2025 | 12 bzw. 10 |
| `mean_gross_annual_earnings`, `median_to_mean_earnings_ratio_oews` | BLS OEWS | 2025 | nur USA |

### `wage_distribution_us_states.csv`
50 Bundesstaaten + District of Columbia, je fünf Kennzahlen aus BLS OEWS Mai 2025,
Berufsgruppe „All Occupations", alle Branchen, über die BLS Public Data API
(Serien `OEUS<FIPS>0000000000000000<Datentyp>`):
`median_annual_wage_oews`, `mean_annual_wage_oews`, `median_hourly_wage_oews`,
`oews_employment`, `median_to_mean_wage_ratio_oews` (*berechnet*).

---

## 2. Aufgabe 3 (a) — Ist die US-Verteilung messbar schiefer?

**Ja, und nicht knapp.** Rangfolge D9/D1 der Bruttoverdienste Vollzeitbeschäftigter,
OECD 2024, *abgelesen*:

| # | Land | D9/D1 | D9/D5 | D5/D1 |
|---|---|---|---|---|
| 1 | USA | 4,79 | 2,48 | 1,93 |
| 2 | Polen | 3,52 | 2,08 | 1,69 |
| 3 | Vereinigtes Königreich | 2,95 | 1,89 | 1,56 |
| 4 | Deutschland | 2,89 | 1,77 | 1,64 |
| 5 | Frankreich | 2,82 | 1,92 | 1,47 |
| 6 | Schweiz | 2,77 | 1,85 | 1,50 |
| 7 | Dänemark | 2,61 | 1,74 | 1,50 |
| 8 | Finnland | 2,44 | 1,68 | 1,45 |
| 9 | Italien | 2,38 | 1,83 | 1,30 |
| 10 | Spanien | 2,37 | 1,93 | 1,23 |
| 11 | Norwegen | 2,30 | 1,64 | 1,41 |
| 12 | Schweden | 2,21 | 1,62 | 1,37 |
| — | Russland | LÜCKE | LÜCKE | LÜCKE |

Der US-Wert liegt 36 % über dem zweitplatzierten Polen und mehr als doppelt so hoch wie
Schweden. Der Abstand USA–Polen ist größer als der Abstand Polen–Schweden.

Wichtig für die Erzählung: die US-Spreizung entsteht **an beiden Enden**. D9/D5 = 2,48
ist der höchste Wert der Reihe (Nächster: Polen 2,08), D5/D1 = 1,93 ebenfalls
(Nächster: Polen 1,69). Ein Bild, das nur „Spitzenverdiener ziehen hoch" erzählt, greift
zu kurz — das untere Ende ist relativ zum Median genauso weit weg wie das obere.

Ergänzend, *berechnet* aus OECD MIN2AVE 2024, Median/Durchschnitt für Vollzeitbeschäftigte:
USA 0,706 · Polen 0,798 · Frankreich 0,807 · Vereinigtes Königreich 0,834 ·
Spanien 0,836 · Deutschland 0,887. Die USA liegen auch hier am Rand der Verteilung.
Für Italien, Schweiz, Dänemark, Norwegen, Schweden, Finnland liegt der Wert nicht vor
(MIN2AVE existiert nur für Länder mit gesetzlichem Mindestlohn) — **Lücke, nicht geschätzt**.

---

## 3. Aufgabe 3 (b) — Wie viel des US-Vorsprungs verschwindet?

Sauber beantwortbar für die sechs Länder mit Median/Durchschnitt-Verhältnis aus derselben
OECD-Quelle. Basis: OECD-Durchschnittsjahreslohn 2024 in USD KKP (konstante Preise 2025),
multipliziert mit dem jeweiligen Median/Durchschnitt-Verhältnis desselben Jahres.
Das Ergebnis ist **inferiert**, nicht abgelesen (Vorbehalt siehe unten).

| Land | US-Vorsprung beim **Durchschnitt** | US-Vorsprung beim **Median** |
|---|---|---|
| Deutschland | +14,3 % | **−9,0 %** |
| Vereinigtes Königreich | +29,9 % | +10,0 % |
| Frankreich | +42,9 % | +25,0 % |
| Spanien | +49,9 % | +26,5 % |
| Polen | +82,3 % | +61,3 % |

**Antwort:** Zwischen einem Drittel und zwei Dritteln des Vorsprungs verschwinden.
Gegenüber Deutschland kippt das Vorzeichen: Beim Durchschnittslohn liegen die USA
14 % vorn, beim Median 9 % hinten. Gegenüber Großbritannien schrumpft ein
Drittel-Vorsprung auf ein Zehntel. Gegenüber Polen bleibt der Vorsprung groß.

**Vorbehalt, der mitgedruckt gehört:** Das Verhältnis Median/Durchschnitt bezieht sich in
MIN2AVE auf **Vollzeitbeschäftigte**, das Niveau in AV_AN_WAGE auf **Vollzeitäquivalente
aller Beschäftigten**. Das ist nicht exakt dieselbe Grundgesamtheit. Die Rechnung trägt
als Größenordnung und als Richtungsaussage; sie trägt nicht als Präzisionszahl auf
hundert Dollar. Für sechs der dreizehn Länder ist sie gar nicht möglich.

**Was die Datenlage NICHT hergibt:** einen Median-Niveauvergleich aller 13 Länder aus
einer Quelle. Es gibt keine Erhebung, die Median-Bruttoverdienste für die EU-Länder,
die Schweiz, Norwegen, das Vereinigte Königreich, Russland und die USA gemeinsam und
gleich abgegrenzt ausweist. Wer eine solche Rangliste zeichnen will, mischt Quellen.

---

## 4. Aufgabe 3 (c) — Trägt die Paarung Staaten-Median gegen Länder-Median?

**Empfehlung: NEIN für `median_annual_wage_oews` (Staaten) gegen
`median_gross_annual_earnings` aus Eurostat SES (Länder). Nicht in eine Grafik.**

Vier Brüche, jeder für sich hinreichend:

1. **Jahr.** OEWS = Mai 2025, Eurostat SES = 2022. Drei Jahre, in denen die Nominallöhne
   in Europa zweistellig gestiegen sind. Die europäischen Werte sind systematisch zu
   niedrig — nicht wegen Wohlstand, sondern wegen des Erhebungsdatums. Die SES ist
   vierjährlich; ein 2025er-Gegenstück gibt es erst mit SES 2026.
2. **Vollzeit/Teilzeit.** Die Eurostat-Jahresverdienstreihe ist faktisch eine
   Vollzeit-Reihe (die Zellen `worktime=TOTAL` und `worktime=FT` sind für alle 37 Gebiete
   wertgleich — am 2026-09-18 zellenweise geprüft). OEWS umfasst Vollzeit **und** Teilzeit.
   Der US-Median ist dadurch nach unten verzerrt, der europäische nicht.
3. **Was „Jahreslohn" heißt.** OEWS erhebt Stundenlöhne und rechnet den Jahreslohn für
   Teilzeitkräfte mit 2080 Stunden hoch. Der US-„Jahreslohn" ist damit für einen
   erheblichen Teil der Fälle **kein tatsächlich bezogenes Jahreseinkommen**, sondern eine
   Vollzeit-Hochrechnung. Eurostat misst tatsächlich gezahlte Jahresverdienste.
4. **Branchenabgrenzung.** Eurostat SES: NACE B–S **ohne O**, also ohne öffentliche
   Verwaltung, und ohne Landwirtschaft, und nur Unternehmen ab 10 Beschäftigten.
   OEWS: alle Branchen einschließlich öffentlicher Verwaltung, alle Betriebsgrößen.

Brutto/netto ist der einzige Punkt, an dem die Paarung sauber ist: beide Reihen sind
Bruttoverdienste vor Steuern und Arbeitnehmerbeiträgen.

**Was stattdessen trägt:**

- **Für die Verteilungsfrage** (das ist die eigentliche Frage der Folge): die
  Dezilverhältnisse aus Abschnitt 2. Eine Quelle, ein Jahr, dimensionslos, USA enthalten.
  Diese Zahlenreihe ist ohne Einschränkung grafikfähig.
- **Für einen Niveauvergleich Staaten ↔ Länder:** die **Stundenverdienste**
  (`median_hourly_wage_oews` gegen `median_gross_hourly_earnings`). Damit fällt Bruch 2
  und 3 weg — die Vollzeit/Teilzeit-Frage verschwindet, wenn man je Stunde misst. Bruch 1
  (Jahr) und 4 (Branchen) bleiben und müssen an der Grafik stehen. Das ist die einzige
  Paarung, die ich mit Einschränkung empfehlen würde.
- **Für den Median/Durchschnitt-Vergleich innerhalb der USA:**
  `median_to_mean_wage_ratio_oews`. Definitionsfest, weil Zähler und Nenner aus derselben
  Zelle derselben Erhebung stammen.

---

## 5. Lücken — gemeldet, nicht geschätzt

| Lücke | Betroffen | Geprüft |
|---|---|---|
| **Russland vollständig** | alle Länder-Kennzahlen | Nicht OECD-Mitglied; `REF_AREA=RUS` in DEC_I, MIN2AVE und AV_AN_WAGE über alle Jahre 0 Zeilen. In der geo-Liste von `earn_ses22_adeci` und `earn_ses_pub2s` nicht enthalten. Kein Ersatz aus einer anderen Quelle gebildet — das hätte die Ein-Quellen-Regel der Aufgabe 1 gebrochen. |
| Median/Durchschnitt für IT, CH, DK, NO, SE, FI | `median_to_mean_earnings_ratio` | OECD MIN2AVE existiert nur für Länder mit gesetzlichem Mindestlohn; für diese sechs 2024 keine Zellen. |
| Vereinigtes Königreich in Eurostat SES 2022 | `median_gross_annual_earnings`, `median_gross_hourly_earnings_pps` | Geo-Code `UK` ist in `earn_ses_pub2s` gelistet, hat aber für 2022 in EUR, NAC und PPS jeweils **keinen** Wert (zellenweise geprüft). Folge des EU-Austritts. Ersatz aus ONS ASHE 2025 eingetragen und als andere Quelle/anderes Jahr gekennzeichnet. |
| USA in Eurostat SES | alle SES-Reihen | Kein EU-/EFTA-Land. Ersatz aus BLS OEWS Mai 2025, als andere Quelle gekennzeichnet. |
| KKS-Umrechnung für UK und USA | `median_gross_hourly_earnings_pps` | Eurostat-KKS gibt es nur für Eurostat-Gebiete; keine eigene Umrechnung vorgenommen. |
| BLS-Flatfiles (`oesm25st.zip`) | — | Direkter Download von bls.gov wird serverseitig geblockt („Access Denied", auch mit Browser-Headern, 2026-09-18 geprüft). Bezug stattdessen über die BLS Public Data API — dieselben Schätzwerte, anderer Transportweg. |

---

## 6. Definitionsfallen für die Folge

1. **Durchschnitt und Median nie aus verschiedenen Erhebungen dividieren.** Abschnitt 0
   zeigt, was dabei herauskommt: ein Verhältnis von 0,51 statt 0,72.
2. **„Median der Löhne" ist mehrdeutig.** Median je *Person mit Erwerbseinkommen* (ACS),
   je *Arbeitsverhältnis* (OEWS, Eurostat SES), je *Vollzeitbeschäftigtem* (OECD, ASHE) —
   drei verschiedene Zahlen für dieselbe Sprachform.
3. **District of Columbia ist kein Bundesstaat und kein Vergleichsfall.** Median 91.540 USD,
   nächster Wert Massachusetts 63.590 USD. DC ist eine Innenstadt ohne Umland. In jeder
   Grafik separat ausweisen oder weglassen.
4. **Dezilverhältnisse sind dimensionslos** — kein Wechselkurs, keine Kaufkraftparität,
   keine Inflationsbereinigung nötig. Das ist der Grund, warum sie die belastbarste
   Zahlenreihe dieser Folge sind.
5. **Die OECD-Dezilreihe erfasst nur Vollzeitbeschäftigte.** Sie beantwortet „wie weit
   liegen Vollzeitlöhne auseinander", nicht „wie weit liegen Erwerbseinkommen auseinander".
   Teilzeit, Teiljahr und Erwerbslosigkeit sind ausgeblendet — der reale
   Einkommensabstand ist größer als D9/D1 zeigt, in allen 12 Ländern.
