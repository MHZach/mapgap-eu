# Ergaenzung 2 Laender — Indien und Serbien

Erstellt 2026-09-18. **Der Bestand wurde nicht angefasst** — weder `countries_*.csv`
noch die `*_add14.csv`. Neue Dateien:

| Datei | Datenzeilen |
|---|---|
| `countries_health_add2.csv` | 14 |
| `countries_justice_add2.csv` | 15 |
| `countries_economy_add2.csv` | 19 |
| `fiscal_debt_deficit_add2.csv` | 4 |
| `prison_context_all.csv` | 72 (36 Laender/Jurisdiktionen x 2 Kennzahlen) |

Spalten, Metrik-Namen, Einheiten, Quellen und Jahrgaenge sind aus dem Bestand uebernommen.
Jede Zahl wurde in dieser Sitzung aus der in `source_url` genannten Quelle gezogen.
**Keine Zahl stammt aus dem Gedaechtnis, keine ist geschaetzt oder interpoliert.**

## Vintage-Kontrolle: gleiche Quellstaende wie Bestand und add14

Vor der Ergaenzung nachgezogen und gegen die Bestandszeilen verglichen — **alle treffen exakt**:

| Kontrolle | Bestand/add14 | heute abgerufen |
|---|---|---|
| IMF NGDPDPC Deutschland 2025 | 60438,8 | 60438,79 |
| IMF NGDPDPC Italien 2025 | 43270,4 | 43270,357 |
| IMF PPPPC Deutschland 2025 | 74004,0 | 74003,998 |
| IMF GGXWDG_NGDP Deutschland 2025 | 62,9 | 62,9 |
| IMF GGXCNL_NGDP USA 2025 | -6,8 | -6,8 |
| UNDP hdi_2023 Deutschland | 0,959 | 0,959 |
| WHO GHO `NCD_BMI_30C` Deutschland 2024 | 24,5 | 24,485093 |
| WHO GHO `NCD_BMI_30C` Portugal 2024 | 23,0 | 22,982331 |
| Weltbank `SH.STA.MMRT` Deutschland 2022 | 4 | 4 |
| OECD PF2.1.A Deutschland Mutterschutz-FRE / gesamt | 14,0 / 38,2 | 14,0 / 38,2 |
| WSI Mindestlohn Deutschland (EUR) | 13,90 | 13,90 |
| EZB EUR/USD 2026-09-17 | 1,1481 | 1,1481 |
| ITF Portugal 2019 | 6,7 | 6,698253778 |
| UNODC Portugal 2019 | 0,71 | 0,705776822 |
| Small Arms Survey Portugal | 21,3 | 21,3 |
| World Prison Brief Portugal 2018 | 125 | 125 |

**WHO-Mortalitaets-Rechenweg gegengeprueft:** Mit demselben Skript, das die Serbien-Raten
rechnet, wurden Portugal und Litauen 2019 nachgezogen. Die Zaehler treffen die im add14-CSV
dokumentierten exakt: Portugal Toetungsdelikte **90** Faelle, Schusswaffen gesamt **100**,
Suizid **71**, Toetung **23**; Litauen Toetungsrate **2,22**. Codeabgrenzung und Nennerlogik
sind damit belegt identisch.

---

# PRUEFUNG 1 — Indien, Abdeckung der Todesursachenstatistik

## 1.1 Wie vollstaendig ist die Sterbefallregistrierung?

Quelle: **WHO SEARO, "2025 Review of progress in implementing the Regional Action Framework
on CRVS — INDIA"** (Stand 23.09.2025), Indikator 1D "Percentage of all deaths that are
registered within one year of occurrence". Alle Werte **abgelesen**:

| Jahr | 2014 | 2015 | 2018 | 2019 | 2020 |
|---|---|---|---|---|---|
| registriert | 67,5 % | 70,0 % | 79,0 % | 89,0 % | **94,3 %** |
| nicht registriert | 32,5 % | 30,0 % | 21,0 % | 11,0 % | 5,7 % |

URL: https://cdn.who.int/media/docs/default-source/searo/his/crvs-profile-2025/sear_crvs_2025profile_ind_20250923.pdf

Die Registrierung selbst ist also weitgehend vollstaendig. **Das ist nicht das Problem.**

## 1.2 Welcher Anteil davon ist medizinisch ursachenzertifiziert?

Hier stehen **zwei verschiedene Nenner** nebeneinander. Sie werden regelmaessig verwechselt:

**(a) Anteil an ALLEN registrierten Sterbefaellen** — die Groesse, die fuer eine
Todesursachenstatistik zaehlt:

| Jahr | registrierte Sterbefaelle | davon medizinisch zertifiziert | Anteil |
|---|---|---|---|
| 2021 | 10.224.506 | 2.395.128 | **23,4 %** |
| 2023 | 8.659.679 | 1.900.956 | **22,0 %** |

Quelle: Office of the Registrar General of India, "Report on Medical Certification of Cause of
Death" (MCCD) 2021 bzw. 2023, sowie "Report on Vital Statistics of India based on the Civil
Registration System" 2021.
**Belegart-Vorbehalt:** Die Primaer-PDFs liegen auf `dc.crsorgi.gov.in`. Dieser Host war am
2026-09-18 aus dieser Sitzung **nicht erreichbar** (`ECONNREFUSED 103.151.152.102:443`,
mehrfach, auch ueber `crsorgi.gov.in`). Die Zahlen sind daher aus der begutachteten
Sekundaerliteratur uebernommen, die den RGI-Bericht direkt zitiert:
*"Of the 8,659,679 deaths recorded in India in 2023, 1,900,956 (22.0 %) were medically
certified"* — International Journal of Community Medicine and Public Health, "Strengthening
cause-of-death certification in India: evidence from the 2021-2023 MCCD report",
https://www.ijcmph.com/index.php/ijcmph/article/view/15379.
**belegart = abgelesen (aus Sekundaerquelle), Primaerquelle nicht erreichbar.**

**(b) Anteil an den Sterbefaellen in Gesundheitseinrichtungen oder unter aerztlicher Betreuung**
— die Groesse, die die WHO als Indikator 1E (adjusted) fuehrt:

| Jahr | 2014 | 2015 | 2018 | 2019 | 2020 |
|---|---|---|---|---|---|
| zertifiziert | 36,3 % | 41,4 % | 58,5 % | 58,6 % | **76,2 %** |

**Die 76,2 % und die 22 % widersprechen sich nicht — sie haben verschiedene Nenner.**
Wer die 76,2 % als Abdeckung der Todesursachenstatistik liest, ueberschaetzt sie um mehr als
das Dreifache. Zusatzbefund aus derselben Sekundaerliteratur: die Zertifizierungsquote streut
zwischen den Bundesstaaten von **100 % (Goa)** bis **5,5 % (Bihar)**.

## 1.3 Meldet Indien ueberhaupt Mortalitaetsdaten an die WHO?

Ausgezaehlt, nicht angenommen. Alle ICD-10-Rohdateien der WHO Mortality Database wurden am
2026-09-18 geladen und nach Laendercode **3100 (India, laut `mort_country_codes`)** durchsucht:

| Rohdatei | Groesse | Zeilen mit Country=3100 |
|---|---|---|
| `Morticd10_part1` | 11,3 MB | **0** |
| `Morticd10_part2` | 10,6 MB | **0** |
| `Morticd10_part3` | 11,6 MB | **0** |
| `Morticd10_part4` | 9,0 MB | **0** |
| `Morticd10_part5` | 8,9 MB | **0** |
| `morticd10_add` | 1,9 MB | **0** |

`morticd9`, `morticd8`, `morticd7` stehen unter denselben URLs **nicht mehr zum Download**
(Antwortgroesse 215 Byte, keine Zip-Datei).

**Indien kommt in keinem Jahr, in keiner Datei, mit keiner einzigen Zeile vor.**
Das ist kein fehlender Jahrgang, sondern das Fehlen der gesamten Laenderachse.
Zur Gegenprobe: Serbien (4273) steht in `Morticd10_part5` mit den Jahren 2017–2020.

## 1.4 EMPFEHLUNG — klar

> **NEIN.** Mord-, Schusswaffen- und Verkehrsraten fuer Indien sind aus der WHO-Reihe
> **nicht** verwendbar — nicht weil die Werte unsicher waeren, sondern weil **es sie nicht gibt**.
> Indien meldet keine Todesursachen-Mikrodaten an die WHO Mortality Database.

Konsequenz im Datensatz:

- `homicide_rate_who_mortality` Indien: **Luecke, keine Zeile.**
- `firearm_deaths_total` / `_suicide` / `_homicide` Indien: **Luecke, keine Zeile.**
- `transport_deaths_rate_who_mortality` Indien: **Luecke, keine Zeile.**

Und der Grund dahinter waere selbst dann bindend, wenn Indien meldete: bei 22 % zertifizierten
Sterbefaellen und einer bundesstaatlichen Spanne von 5,5 % bis 100 % waere jede daraus
gerechnete Rate ueberwiegend eine Funktion der Zertifizierungsdichte, nicht des Geschehens.

## 1.5 Was stattdessen im CSV steht — und was damit NICHT gemacht werden darf

Fuer Indien ist **nur** die UNODC-Zeile eingetragen:
`homicide_rate_unodc` = **2,95** je 100.000 (2019, 40.976 Faelle).
Die UNODC-Datei nennt als Quelle fuer Indien ausdruecklich **"MoI/NCRB India"** — Innenministerium
und National Crime Records Bureau, also **Polizeistatistik**.

> **Das ist eine andere Groesse.** Sie zaehlt polizeilich registrierte Toetungsdelikte,
> nicht aerztlich bescheinigte Todesursachen. Sie darf **nicht** in dieselbe Spalte oder dieselbe
> Grafik wie `homicide_rate_who_mortality` anderer Laender.

Das ist kein theoretischer Einwand. Der Bestand dokumentiert unter D1/D-G, dass beide Reihen
schon bei OECD-Laendern in beide Richtungen auseinanderlaufen. Bei Indien kommt hinzu, dass die
Polizeireihe die **einzige** ist — es gibt keine zweite, an der man die erste messen koennte.

Serbien hat beide, und sie stimmen nahezu ueberein: WHO **1,24** (86 Faelle) gegen
UNODC **1,26** (88 Faelle). Das ist die Ausnahme, nicht die Regel — und es ist der Beleg dafuer,
dass Serbiens Meldung belastbar ist.

## 1.6 Verkehrstote Indien — dieselbe Lage, andere Quelle

`traffic_deaths_rate` (ITF/OECD 2019) ist fuer Indien **nicht** verfuegbar: Indien steht zwar in
`REF_AREA` des ITF-Dataflows, die Reihe `FATALITIES / 10P5HB / ROAD` endet aber **2017**
(letzter Wert 10,88; abgelesen 2026-09-18). Kein 2019er Wert, kein Ersatz eingesetzt.

Stattdessen als **eigene Metrik** (wie im Bestand fuer andere Laender):
`traffic_deaths_rate_who_estimate` = **14,6** (2021, WHO GHO `RS_198`) — eine **modellierte
WHO-Schaetzung**, keine nationale Meldezahl. Serbien hat beide: ITF **7,65** (2019) und
WHO-Schaetzung **7,4** (2021).

---

# PRUEFUNG 2 — Indien, Haftrate und die Interpretationsfalle

## 2.1 Die Rohzahl bestaetigt die Erwartung

| Kennzahl | Wert | Stichtag | Beleg |
|---|---|---|---|
| `incarceration_rate_prison_jail_total` | **34** | 2018 | WPB-Trendtabelle, 466.084 Gefangene |
| `incarceration_rate_prison_jail_latest` | **36** | 31.12.2024 | 511.542 Gefangene / 1.438,7 Mio (UN) |

Das ist der **niedrigste Wert im gesamten Datensatz** — unter Japan (33 latest, 40 fuer 2018)
liegt Indien 2018 sogar knapp. Die in der Aufgabenstellung genannte Erwartung von "rund 35"
trifft.

## 2.2 Die zwei Zusatzzahlen, die den Fall entscheiden

Beide aus World Prison Brief, Laenderseiten, alle **abgelesen**, Stichtage in
`prison_context_all.csv` je Zeile. Vergleich wie beauftragt:

| | Haftrate | **U-Haft-Anteil** | **Belegungsgrad** | Stichtag |
|---|---|---|---|---|
| **Indien** | 36 | **72,6 %** | **112,7 %** | 31.12.2024 |
| Finnland | 58 | 27,0 % | 109,8 % | 31.01.2025 |
| Norwegen | 54 | 29,5 % | 81,1 % | 31.08.2026 / 31.01.2025 |
| USA | 542 | 25,5 % | c. 86,1 % | 2023 / 2022 |

Indiens U-Haft-Anteil ist **der hoechste des gesamten Datensatzes** — und zwar mit grossem
Abstand: Platz 2 ist die Schweiz mit 50,1 %, Platz 3 Kanada mit 49,6 %. Indien liegt
**22,5 Punkte** ueber dem naechsten Land und rund **das 2,7-fache** ueber Finnland, Norwegen
und den USA, die alle zwischen 25 und 30 % liegen.

## 2.3 Aufspaltung der Haftrate (berechnet)

Rate mal Anteil, je Land aus denselben Stichtagen (bei Indien, Finnland, Norwegen und den USA
tragen Rate und Anteil jeweils denselben Stichtag — geprueft auf den WPB-Seiten):

| | Haftrate | davon **verurteilt** | davon **nicht verurteilt** |
|---|---|---|---|
| **Indien** | 36 | **9,9** | **26,1** |
| Finnland | 58 | 42,3 | 15,7 |
| Norwegen | 54 | 38,1 | 15,9 |
| USA | 542 | 403,8 | 138,2 |
| Serbien | 174 | 136,6 | 37,4 |

*belegart: berechnet. Zaehler und Anteil sind abgelesen; die Multiplikation ist von mir.
Vorbehalt: der U-Haft-Anteil ist ein Anteil an der Gefangenenzahl am Stichtag, kein Zufluss —
er sagt nichts ueber die Verweildauer.*

## 2.4 Was diese beiden Zahlen nahelegen

**Sie legen begrenzte Justizkapazitaet nahe, nicht Strafmilde.** Drei Belege, nicht einer:

1. **Die verurteilte Haftrate ist noch extremer als die Gesamtrate.** Indien sperrt rund
   **10 verurteilte** Menschen je 100.000 ein — ein Viertel des finnischen Werts (42,3) und
   ein Vierzigstel des US-Werts (403,8). Gleichzeitig sitzen **26,1 je 100.000 ohne Urteil**,
   mehr als in Finnland (15,7) und Norwegen (15,9) zusammengenommen pro Kopf.
   Ein Strafrechtssystem, das milde ist, sperrt wenige ein. Ein System, das nicht zu Urteilen
   kommt, sperrt viele ohne Urteil ein und wenige mit. Indien zeigt das zweite Muster.

2. **Die Anstalten sind ueberbelegt, obwohl die Haftrate die niedrigste ist.**
   112,7 % Belegung bei Rate 36. Norwegen: 81,1 % bei Rate 54. Die USA: c. 86,1 % bei Rate 542.
   Niedrige Haftrate und Ueberbelegung schliessen sich nur dann nicht aus, wenn die Kapazitaet
   selbst klein ist — Indiens offizielle Kapazitaet betraegt **453.769 Plaetze** fuer 1.438,7 Mio
   Einwohner, also rund **32 Plaetze je 100.000** (berechnet aus abgelesenen WPB-Zahlen).
   Die Kapazitaet, nicht die Strafpraxis, ist die bindende Groesse.

3. **Gegenprobe an Laendern, wo Milde belegt ist.** Japan hat eine aehnlich niedrige Rate (33),
   aber **15,8 %** U-Haft und **47,3 %** Belegung — halb leere Anstalten. Das ist das Bild einer
   niedrigen Haftrate ohne Kapazitaetsdruck. Indiens Bild ist ein anderes.

**Was NICHT belegt ist:** dass die Ursache Verfahrensdauer, Kautionspraxis oder Richtermangel
ist. Das waere **inferiert**. Belegt sind: Anteil, Belegungsgrad, Kapazitaet je Kopf und der
Kontrast zu Japan. Die Zuordnung zu einer konkreten Ursache im Justizapparat ist **nicht geprueft**.

> **Regel fuer die Serie:** Indien darf in keiner Grafik als "Land mit der mildesten Strafpraxis"
> erscheinen, ohne dass U-Haft-Anteil und Belegungsgrad danebenstehen. Die Haftrate allein
> misst bei Indien vor allem, wie viele Plaetze es gibt.

## 2.5 `prison_context_all.csv` — Abdeckung

**36 von 36** Jurisdiktionen haben beide Werte. Vollstaendig: alle 16 Bestandslaender, die drei
UK-Teiljurisdiktionen, alle 14 add14-Laender (Bosnien in seinen zwei Entitaeten, weil World
Prison Brief keine Gesamtjurisdiktion fuehrt — siehe add14-NOTES L2), Indien und Serbien.

**Fallen in dieser Datei:**

- **Kein gemeinsamer Stichtag.** Die Spanne reicht von **31.12.2014** (Israel, U-Haft) bis
  **September 2026**. Die Spalte `year` traegt je Zeile den Stichtag der Quelle, nicht ein Jahr.
  Wo die Quelle kein Datum, sondern eine Umschreibung nennt ("mid-2025", "May 2026",
  "average, year to 31.3.2024"), steht diese Umschreibung woertlich in `year` **und** in
  `source_name`. Das ist Absicht: eine erfundene Datumsnormalisierung waere schlechter.
- **USA-Belegung ist eine Naeherung.** WPB schreibt "c. 86,1 %" und setzt sie aus drei
  Teilsystemen zusammen: 72,4 % in local jails, 110,4 % in federal prisons, c. 94,0 % in state
  prisons (2022, abgelesen). Der Circa-Vermerk steht in `source_name`. Der US-Gesamtwert ist
  damit **nicht** gleichwertig mit den Einzelstichtagswerten der uebrigen Laender — die
  **Bundesgefaengnisse liegen ueber Kapazitaet, das Aggregat verdeckt das**.
- **Kanada mischt Ebenen und Jahre.** U-Haft 49,6 % ist ein Jahresdurchschnitt bis 31.03.2024,
  die Belegung 102,2 % ein Jahresdurchschnitt bis **31.03.2015** — neun Jahre auseinander, und
  in der Quelle aufgeteilt in 98,8 % (federal) gegen 104,4 % (provincial/territorial).
- **Israel: U-Haft-Anteil ist von 2014**, der Belegungsgrad von 2023. Der U-Haft-Wert ist der
  aelteste der Datei.
- **Australien-Belegung ist von 2017**, der U-Haft-Anteil von 2025 — acht Jahre auseinander.
- **Italien und Portugal** schliessen Teilpopulationen aus (Italien ohne Jugendanstalten,
  Portugal ohne psychiatrische Einrichtungen). Steht je Zeile in `source_name`.
- **Bosnien hat zwei Zeilen je Kennzahl**, keine Gesamtzahl. Der Brcko-Distrikt ist in keiner
  von beiden enthalten. Beide Entitaeten nicht mitteln — es gibt keinen belegten Gesamtnenner.

---

# SERBIEN — Abwesenheit im Rohabruf belegt, nicht angenommen

Serbien ist weder OECD- noch EU-Mitglied. Jede Reihe wurde einzeln geprueft.

| Reihe | Serbien enthalten? | Beleg (Abruf 2026-09-18) |
|---|---|---|
| WHO Mortality Database (`Morticd10_part5`) | **ja** | Land 4273, Jahre 2017–2020 |
| World Prison Brief | **ja** | `/country/serbia`, Trendtabelle 2000–2020 + aktuell |
| UNODC CTS | **ja** | 2003–2024, Quelle "Eurostat/CTS/GSH 2023 Revision/SDG" |
| ITF/OECD Verkehrssicherheit | **ja** | REF_AREA=SRB, 2019 = 7,645529633 |
| Small Arms Survey 2017 | **ja** | SRB, 39,1 je 100 Einwohner |
| WHO GHO `NCD_BMI_30C` | **ja** | 2024 = 25,603771 |
| WHO GHO `RS_198` | **ja** | 2021 = 7,4 |
| Weltbank WDI | **ja** | LE, Saeuglingssterblichkeit, MMR |
| IWF WEO April 2026 | **ja** | alle vier Indikatoren |
| UNDP HDR 2025 | **ja** | hdi_2023 = 0,833, Rang 62 |
| WSI-Mindestlohnreihe | **ja** | Abb. 1, Block "Sonstiges Europa": 4,28 EUR |
| OECD `DF_LE` (Lebenserwartung) | **nein** | 51 REF_AREA-Codes im Rohabruf, SRB nicht dabei |
| OECD `DF_MIM` (Saeuglings-/Muettersterblichkeit) | **nein** | 51 Codes, SRB nicht dabei |
| OECD `DF_HEALTH_LVNG_BW` (Koerpergewicht) | **nein** | 50 Codes, SRB nicht dabei |
| OECD `DF_HEALTH_PROT` (Versicherung) | **nein** | 46 Codes, SRB nicht dabei |
| OECD Income Distribution Database | **nein** | 41 Codes zurueckgegeben, SRB nicht dabei |
| OECD Family Database PF2.1.A | **nein** | Volltext der Tabelle durchsucht, kein Eintrag |

**Die Erwartung der Aufgabenstellung trifft:** WHO-Mortalitaet und World Prison Brief fuehren
Serbien. Ueberraschung in die andere Richtung: auch **ITF** fuehrt Serbien (ITF-Mitgliedschaft
ist nicht an OECD-Mitgliedschaft gebunden — dasselbe Muster wie bei Bosnien in add14), und die
**WSI-Mindestlohnreihe** fuehrt Serbien ebenfalls, anders als Bosnien.

**Serbiens WHO-Meldung ist brauchbar** — anders als die bosnische (add14, L1). Auszaehlung 2019,
alles abgelesen: Gesamtsterbefaelle `AAA` = **101.458**; `R99` (unbekannte Ursache) = 4.915
= **4,8 %**; `Y34` (unbestimmte Absicht) = **167**; Transportunfaelle V01–V99 = **550**.
Zum Vergleich Bosnien: 0 Transporttote kodiert, 918 Faelle in Y34, 12,8 % R99.
Serbiens externe Todesursachen sind kodiert. Die ITF-Rate (7,65) und die aus der
Todesursachenstatistik gerechnete Transportrate (7,92) liegen nahe beieinander — eine
unabhaengige Bestaetigung.

---

# INDIEN — was die OECD-Reihen ueberraschend doch liefern

Entgegen der Erwartung steht Indien als OECD-Partnerland in drei der vier OECD-Gesundheits-
Dataflows (`DF_LE`, `DF_MIM`, `DF_HEALTH_LVNG_BW`), nicht aber in `DF_HEALTH_PROT`.
**Das ist aber keine gleichwertige Datenlage**, und das ist die wichtigste Definitionsfalle
dieses Blocks:

**Die OECD-Lebenserwartung fuer Indien ist keine nationale Sterbetafel.** Die OECD-Werte 2022
(gesamt 71,7 / maennlich 70,2 / weiblich 73,3) sind **zifferngleich** mit der Weltbank-/UN-WPP-
Modellreihe `SP.DYN.LE00.IN` (71,698 / 70,237 / 73,271). Fuer OECD-Mitglieder stammt die Reihe
aus nationalen Sterbetafeln; fuer Indien ist sie durchgereicht. Deshalb traegt die Spalte
`messmethode` fuer Indien `un_wpp_modellreihe_ueber_oecd` statt `national_life_tables`.
Dasselbe bei `infant_mortality`: OECD 2023 = 24,5, Weltbank `SP.DYN.IMRT.IN` 2023 = 24,5.

Damit ist die Lage fuer beide neuen Laender methodisch **gleich**, nur formal verschieden:
Indien bekommt die Modellreihe ueber die OECD, Serbien direkt ueber die Weltbank.
**Beide sind Modellschaetzungen, keine Registerzahlen** und sollten in einer Grafik gegenueber
den OECD-Mitgliedern markiert werden.

**`adult_obesity_measured` Indien ist eine fortgeschriebene Reihe, keine Messserie.**
Die OECD-Werte 2015–2022 lauten 4,8 / 5,1 / 5,4 / 5,7 / 6,1 / 6,4 / 6,8 / 7,2 — ein linearer
Anstieg von 0,3–0,4 Punkten pro Jahr ueber acht Jahre. Unabhaengige Erhebungen streuen so nicht.
Der Wert steht im CSV (abgelesen), gehoert aber nicht in eine Rangliste. Belegt ist die
Zahlenfolge; dass es sich um eine Fortschreibung handelt, ist **inferiert**.

**`adult_obesity_self_reported` Indien ist von 2014** — elf Jahre aelter als der juengste Wert
im Bestand (Israel/Lettland 2025). Der Bestand fuehrt diese Spalte bereits als Jahresmix
2019–2025; mit Indien wird die Spanne **2014–2025, zwoelf Jahre**. Bei jeder Jahresregel
faellt Indien als Erstes heraus.

---

# LUECKEN — vollstaendige Liste

## Indien (9 Luecken)

| Kennzahl | Grund | im CSV |
|---|---|---|
| `homicide_rate_who_mortality` | Indien in WHO Mortality DB in **keiner** Datei enthalten (0 Zeilen, 6 Dateien ausgezaehlt) | keine Zeile |
| `firearm_deaths_total` | dito | keine Zeile |
| `firearm_deaths_suicide` | dito | keine Zeile |
| `firearm_deaths_homicide` | dito | keine Zeile |
| `traffic_deaths_rate` (ITF 2019) | ITF-Reihe fuer Indien endet 2017; kein 2019er Wert | keine Zeile; Ersatz `traffic_deaths_rate_who_estimate` = 14,6 |
| `health_insurance_coverage` | Indien nicht im OECD-Dataflow `DF_HEALTH_PROT` (46 Codes ausgezaehlt) | keine Zeile |
| `maternal_mortality_registered` | OECD `DF_MIM` fuehrt fuer Indien nur `INM` und `NEOM`, kein `MATM` | keine Zeile |
| `infant_mortality_min22weeks` | `GESTATION_THRESHOLD=WK22` fuer Indien in keinem Jahr | keine Zeile |
| `bezahlte_gesamtfreistellung_mutter_fre_wochen` | nicht in PF2.1.A; ILO-Ersatz nicht ueberfuehrbar (siehe unten) | `nicht_in_quellreihe_enthalten` |
| `armutsquote_50pct_median`, `median_verfuegbares_einkommen_aequiv_netto` | nicht in OECD IDD (41 Codes ausgezaehlt) | `nicht_in_quellreihe_enthalten` |

Sachverhalt, **keine** Luecke: `mindestlohn_usd_pro_stunde` = `kein_einheitlicher_nationaler_satz`
(siehe unten).

## Serbien (7 Luecken)

| Kennzahl | Grund | im CSV |
|---|---|---|
| `adult_obesity_self_reported` | nicht im OECD-Dataflow `DF_HEALTH_LVNG_BW` | keine Zeile |
| `adult_obesity_measured` | dito | keine Zeile |
| `health_insurance_coverage` | nicht in `DF_HEALTH_PROT` | keine Zeile |
| `maternal_mortality_registered` | nicht in `DF_MIM` | keine Zeile |
| `infant_mortality_min22weeks` | dito | keine Zeile |
| `bezahlte_gesamtfreistellung_mutter_fre_wochen` | nicht in PF2.1.A; ILO-Ersatz nicht ueberfuehrbar | `nicht_in_quellreihe_enthalten` |
| `armutsquote_50pct_median`, `median_verfuegbares_einkommen_aequiv_netto` | nicht in OECD IDD | `nicht_in_quellreihe_enthalten` |

---

# DEFINITIONSFALLEN

## F1 — Mutterschutz-FRE aus ILO ist NICHT die OECD-Spalte

Auftragsgemaess wurde `mutterschutz_full_rate_equivalent_wochen` fuer beide Laender aus der
**ILO Global Care Policy Portal**-Reihe gefuellt (Dauer x Lohnersatzrate, Stand 2025):

- **Indien:** 26 Wochen x 100 % = **26,0** FRE-Wochen
- **Serbien:** 20 Wochen x 100 % = **20,0** FRE-Wochen

**Die Gegenprobe gegen OECD PF2.1.A faellt aber ueberwiegend durch.** Fuer fuenf Laender, die
in beiden Quellen stehen (alles abgelesen, FRE selbst gerechnet):

| Land | ILO: Dauer x Rate = FRE | OECD PF2.1.A, Spalte (3) | Treffer? |
|---|---|---|---|
| Deutschland | 14 x 100 % = 14,0 | 14,0 | **ja** |
| Israel | 26 x 100 % = 26,0 | 15,0 | nein |
| Griechenland | 43 x 100 % = 43,0 | 33,3 | nein |
| Portugal | 17 x 100 % = 17,0 | 6,0 | nein |
| Ungarn | 24 x 70 % = 16,8 | 24,0 | nein |

**1 von 5.** Die beiden Quellen zaehlen unterschiedlich, welche Wochen zum "Mutterschutz" und
welche zum "parental leave" gehoeren, und die OECD rechnet mit Beitragsbemessungsgrenzen und
Durchschnittsverdiensten, die ILO mit dem gesetzlichen Nominalsatz.

> **Die Indien- und Serbien-Werte stehen im CSV, weil so beauftragt, und sind in `source_name`
> als andere Quelle markiert. Sie duerfen nicht ohne Markierung neben die OECD-Werte gestellt
> werden.** Wer eine homogene Spalte braucht, laesst beide Laender weg.

## F2 — `bezahlte_gesamtfreistellung_mutter_fre_wochen` wurde bewusst NICHT gefuellt

Die ILO-Ersatzreihe traegt "Duration of parental leave available to **households**" — eine
Haushaltsgroesse, keine mutterspezifische. Gegenprobe Deutschland:
ILO 14 x 100 % + 312 x 11 % = **48,3** gegen OECD **38,2**. Ein selbst gebildeter Wert waere
eine andere Kennzahl, kein Ersatz. Daher `nicht_in_quellreihe_enthalten`, belegart `nicht geprueft`.

Zur Information, **nicht** im Wert (ILO 2025, abgelesen): Indien hat **keinen** gesetzlichen
Elternurlaub; Serbien 52 Wochen bei 100 % Lohnersatz als Haushaltsanspruch.

## F3 — Indiens Mindestlohn: `kein_einheitlicher_nationaler_satz`, kein Durchschnitt

Indien setzt Mindestloehne nach Minimum Wages Act 1948 / Code on Wages 2019 je **Bundesstaat**,
**Zone**, **Branche** (scheduled employment), **Taetigkeit** und **Qualifikationsstufe** fest,
halbjaehrlich ueber die Variable Dearness Allowance angepasst. Der zentrale "national floor level
minimum wage" ist ausdruecklich **nicht bindend**. Spannweite fuer ungelernte Arbeit 2026:
**INR 6.600/Monat** (Arunachal Pradesh) bis **INR 23.376,43/Monat** (Karnataka Zone I) — Faktor 3,5.

**Negativbeleg:** Indien kommt in der Laenderliste des WSI-Mindestlohnberichts 2026
(Report Nr. 111, Abb. 1) nicht vor — geprueft, nicht angenommen.

**Ein Durchschnitt ueber Bundesstaaten wurde nicht gebildet.** Er waere eine Erfindung: es gibt
keinen Beschaeftigungsgewichtungsschluessel in der Quelle, und der Wert haengt vollstaendig
davon ab, welche Qualifikationsstufe und Zone man waehlt.
Dies ist die dritte Bauart dieser Spalte im Datensatz — neben `kein_gesetzlicher_mindestlohn`
(Italien, Oesterreich) und `keine_vergleichbare_quelle` (Bosnien).

## F4 — Serbiens Mindestlohn ist eine WSI-Schaetzung, kein amtlicher Bruttosatz

WSI-Fussnote ** zu Serbien: *"Geschaetzt, da Mindestlohn als Nettolohn festgelegt wird."*
Der Wert 4,28 EUR ist eine WSI-Umrechnung eines Netto-Satzes in einen Brutto-Stundensatz.
Er steht in derselben Spalte wie die amtlichen Bruttosaetze der EU-Laender, ist aber **nicht
dieselbe Groesse**. Dasselbe gilt in der WSI-Tabelle fuer Nordmazedonien.
USD-Umrechnung wie im Bestand: 4,28 x 1,1481 (EZB, Stichtag 2026-09-17) = **4,91**.

## F5 — Indiens Mindesturlaub gilt nur fuer Fabrikbeschaeftigte

12,0 Arbeitstage ist aus **Section 79(1) Factories Act 1948** gerechnet: wer 240 Tage im
Kalenderjahr gearbeitet hat, bekommt "one day for every twenty days of work" = 240/20 = 12.
**Der Anspruch gilt nur im Geltungsbereich des Factories Act.** Beschaeftigte ausserhalb fallen
unter die Shops-and-Establishments-Gesetze der **einzelnen Bundesstaaten** mit abweichenden
Anspruechen. Einen landesweit einheitlichen Urlaubsanspruch gibt es nicht.
Der Bare-Act-Wortlaut wurde ueber advocatekhoj.com gelesen — `indiacode.nic.in` lieferte
**HTTP 403**. Serbien dagegen ist eindeutig: Art. 69 Zakon o radu, "no less than 20 work days",
bereits Arbeitstage, keine Normalisierung noetig.

Damit ist Indien mit 12 Tagen der **niedrigste** Wert des Datensatzes, gleichauf mit Israel (12),
und wie Israel nicht an die EU-Arbeitszeitrichtlinie gebunden.

## F6 — Die Spannweiten werden durch Indien gesprengt

Indien veraendert die Skalen des Datensatzes so stark, dass jede gemeinsame Grafik geprueft
werden muss (alle Werte aus den CSV, abgelesen):

- `bip_pro_kopf_nominal_2025e`: Indien **2.675,3** USD gegen USA 89.991,2 — **Faktor 34**.
  Eine lineare Achse macht alle uebrigen Unterschiede unsichtbar.
- Nominal gegen KKP: Indien 2.675,3 gegen **11.789,3** Int$ — **Faktor 4,4**, der groesste Keil
  im Datensatz (zum Vergleich Ungarn 1,87, Kroatien 1,88). Nominal- und KKP-Rangfolgen nie mischen.
- `hdi`: Indien **0,685** ist der einzige Wert unter 0,80 im ganzen Datensatz.
- `incarceration_rate_prison_jail_latest`: Indien 36 gegen USA 542 — Faktor 15.
- `civilian_firearms_per_100`: Indien **5,3** gegen USA (Bestand). Aber laut derselben Quelle
  sind **61,4 Mio von 71,1 Mio** indischen Zivilwaffen **nicht registriert** — rund 86 %.
  Die 5,3 sind eine Schaetzung, die zu ueber vier Fuenfteln auf einer Dunkelfeldannahme beruht,
  nicht auf einem Register. Das ist eine andere Belegqualitaet als bei Laendern mit Registern.
- `general_government_gross_debt_pct_gdp`: Indien **84,1 %** bei einem Defizit von **-7,4 %** —
  das hoechste Defizit des Datensatzes (USA -6,8 %).

## F7 — Serbien ist datentechnisch unauffaellig, inhaltlich nicht

Serbien fuellt 20 von 30 Kennzahlen und hat mit **174** die dritthoechste Haftrate des
Datensatzes (nach Ungarn 206 und Israel 217) bei einem **unterdurchschnittlichen** U-Haft-Anteil
(21,5 %) und einem Belegungsgrad **unter** 100 % (95,6 %). Das ist das Spiegelbild Indiens:
viele Verurteilte, ausreichend Plaetze. Wer die beiden nebeneinanderstellt, zeigt, dass die
Haftrate ohne Kontext nichts ueber Strenge aussagt.

---

# BELEGART-VERTEILUNG

- **abgelesen** — IWF WEO, UNDP HDI, WHO GHO (Adipositas, `RS_198`), Weltbank WDI, OECD-Dataflows,
  UNODC, ITF, Small Arms Survey, World Prison Brief (alle 72 Zeilen in `prison_context_all.csv`),
  WSI-EUR-Originalwert Serbien, Indiens Mindestlohn-Sachverhalt, Serbiens Urlaubsnorm,
  MCCD-Anteile (aus Sekundaerquelle, Primaerhost nicht erreichbar), WHO-CRVS-Registrierungsquoten.
- **berechnet** — Serbiens vier WHO-Mortalitaetsraten (Zaehler und Nenner abgelesen, Rate
  gerechnet, Rechenweg in jeder Zeile), Serbiens Mindestlohn in USD (Kursumrechnung),
  Indiens Mindesturlaub (240/20), beide Mutterschutz-FRE-Werte (Dauer x Rate),
  die Aufspaltung der Haftraten in Abschnitt 2.3.
- **nicht geprueft** — die sechs Luecken, die als Wert `nicht_in_quellreihe_enthalten` tragen.
  Die **Abwesenheit** aus der Quellreihe ist jeweils geprueft; der **Wert** ist nicht ermittelt
  und wurde nicht geschaetzt.
- **inferiert** — kommt in keinem CSV-Feld vor. Zwei Aussagen dieses Dokuments sind inferiert
  und dort so markiert: dass Indiens `adult_obesity_measured`-Reihe eine Fortschreibung ist,
  und die Ursachenzuordnung in Abschnitt 2.4.
- **angenommen** — kommt nicht vor.

---

# NICHT GEPRUEFT

- Ob die WHO fuer Indien eine **modellierte** Mortalitaetsreihe (Global Health Estimates) fuehrt.
  Das waere eine andere Quelle als der Bestand (Rohdaten der Mortality Database) und haette die
  Homogenitaet gebrochen; deshalb als Luecke gemeldet statt aus einer Fremdquelle gefuellt.
- Ob NCRB-Polizeidaten fuer Indien eine eigene, konsistente Verkehrstoten- oder Schusswaffenreihe
  liefern, die als **eigene Metrik** aufgenommen werden koennte. Nicht beauftragt, nicht gesucht.
- Die Unsicherheitsintervalle zu `adult_obesity` (WHO liefert Low/High) und zu
  `maternal_mortality` (MMEIG-Spanne) — wie im Bestand nicht uebernommen.
- Ob der WSI-Schaetzweg fuer Serbien (netto auf brutto) dokumentiert ist. Die Fussnote sagt nur,
  **dass** geschaetzt wurde.
- Ob die WPB-Nenner fuer Indien (1.438,7 Mio, UN) und Serbien (6,56 Mio, Eurostat) mit den
  jeweiligen amtlichen Bevoelkerungsreihen uebereinstimmen.
- Ob Serbien in Eurostat- oder WHO-Europe-Reihen mit Versicherungsabdeckung und
  selbstberichteter Adipositas gefuehrt wird — waere eine andere Quelle als der Bestand.
- `OBS_STATUS`-Flags in den OECD-Abrufen fuer Indien.

---

# ABRUFPROTOKOLL (alles 2026-09-18)

| Quelle | Zugriff | Ergebnis |
|---|---|---|
| IMF DataMapper API (NGDPDPC, PPPPC, GGXWDG_NGDP, GGXCNL_NGDP, LP) | curl, JSON | OK, IND und SRB enthalten |
| UNDP HDR 2025 Composite Indices CSV | curl | OK (Encoding latin-1) |
| WHO GHO OData (`NCD_BMI_30C`, `RS_198`) | curl | OK |
| Weltbank API (`SH.STA.MMRT`, `SP.DYN.LE00.*`, `SP.DYN.IMRT.IN`) | curl | OK, lastupdated 2026-07-13 |
| OECD SDMX `DF_LE`, `DF_MIM`, `DF_HEALTH_LVNG_BW`, `DF_HEALTH_PROT` | curl | OK; IND in 3 von 4, SRB in 0 von 4 |
| OECD SDMX Income Distribution Database | curl | OK; weder IND noch SRB |
| OECD Family Database PF2.1 PDF | curl + pdftotext -layout | OK; weder IND noch SRB |
| WHO Mortality Database, 6 Rohdateien | curl + unzip | OK; IND 0 Zeilen, SRB vorhanden |
| WHO Mortality `morticd9/8/7` | curl | **nicht mehr verfuegbar** (215 Byte Antwort) |
| UNODC `data_cts_intentional_homicide.xlsx` | curl + openpyxl | OK, Dateistand 12.07.2026 |
| ITF/OECD `DSD_INDICATORS@DF_SAFETY` | curl | OK; SRB 2019, IND nur bis 2017 |
| Small Arms Survey Annex PDF | curl + pdftotext | OK |
| World Prison Brief, 36 Laenderseiten | urllib | OK |
| WSI Report Nr. 111 PDF | curl + pdftotext -layout | OK, Abb. 1 gelesen |
| EZB eurofxref-hist-90d.xml | curl | OK, 2026-09-17: USD 1,1481 |
| ILO Global Care Policy Portal (IND, SRB, DEU, ISR, GRC, PRT, HUN) | curl | OK |
| WHO SEARO CRVS-Profil Indien 2025 | WebFetch + pdftotext | OK |
| **`dc.crsorgi.gov.in` / `crsorgi.gov.in` (RGI, MCCD-Primaerberichte)** | curl, WebFetch | **ECONNREFUSED — nicht erreichbar** |
| **`indiacode.nic.in`** | WebFetch | **HTTP 403** |
