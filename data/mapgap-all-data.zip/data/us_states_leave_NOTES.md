# US-Bundesstaaten — Bezahlte Elternzeit und gesetzlicher Urlaub

Datei: `us_states_leave.csv` · Stichtag aller Statusangaben: **18.09.2026** · Erhebung: 18.09.2026

Einheiten: 50 Bundesstaaten + District of Columbia als eigene Zeile (DC zaehlt **nicht** zu den 50).
Spalten: `metric,state,value,unit,year,source_name,source_url,belegart`.

---

## 1. Die 15 Jurisdiktionen mit Programm (14 Staaten + DC)

| Jurisdiktion | Leistungen ab | Status 18.09.2026 | Bonding-Wochen | Ersatzrate Durchschnittsverdiener | FRE-Wochen |
|---|---|---|---|---|---|
| California | 01.07.2004 | in_kraft | 8 | 70,0 % | 5,60 |
| New Jersey | 01.07.2009 | in_kraft | 12 | 59,6 % | 7,15 |
| Rhode Island | 01.01.2014 | in_kraft | 8 | 60,0 % | 4,80 |
| New York | 01.01.2018 | in_kraft | 12 | 52,0 % | 6,24 |
| Washington | 01.01.2020 | in_kraft | 12 | 68,3 % | 8,20 |
| District of Columbia | 01.07.2020 | in_kraft | 12 | 43,7 % | 5,24 |
| Massachusetts | 01.01.2021 | in_kraft | 12 | 55,9 % | 6,71 |
| Connecticut | 01.01.2022 | in_kraft | 12 | 48,9 % | 5,87 |
| Oregon | 03.09.2023 | in_kraft | 12 | 80,9 % | 9,71 |
| Colorado | 01.01.2024 | in_kraft | 12 | 67,3 % | 8,08 |
| Delaware | 01.01.2026 | in_kraft | 12 | 56,0 % | 6,72 |
| Minnesota | 01.01.2026 | in_kraft | 12 | 75,1 % | 9,01 |
| Maine | 01.05.2026 | in_kraft | 12 | 77,3 % | 9,28 |
| Maryland | 01.01.2028 | beschlossen_noch_nicht_in_kraft | 12 | 59,7 % | 7,16 |
| Virginia | 01.12.2028 | beschlossen_noch_nicht_in_kraft | 12 | 80,0 % | 9,60 |

**36 Bundesstaaten ohne Programm** (`kein_programm`, Wochen = 0, Rate = 0, FRE = 0):
Alabama, Alaska, Arizona, Arkansas, Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa, Kansas,
Kentucky, Louisiana, Michigan, Mississippi, Missouri, Montana, Nebraska, Nevada, New Hampshire,
New Mexico, North Carolina, North Dakota, Ohio, Oklahoma, Pennsylvania, South Carolina, South Dakota,
Tennessee, Texas, Utah, Vermont, West Virginia, Wisconsin, Wyoming.

Rechnung: 14 Staaten mit Programm + 36 ohne = 50. DC kommt als 51. Zeile hinzu.

---

## 2. Definitionsfallen

**F-1 — Beitraege eingezogen ist nicht Leistungen gezahlt.**
Maryland zieht ab **01.01.2027** Beitraege ein (0,9 % der Loehne, haelftig geteilt), zahlt aber erst ab
**01.01.2028**. Virginia zieht ab **01.04.2028** ein, zahlt ab **01.12.2028**. Beide sind am Stichtag
18.09.2026 folglich `beschlossen_noch_nicht_in_kraft`, nicht `in_kraft`. Wer nach „Staaten mit
PFML-Gesetz" zaehlt, kommt auf 15; wer nach „zahlt tatsaechlich" zaehlt, auf 13.

**F-2 — Die Ersatzraten sind progressiv gestaffelt UND gedeckelt.**
Eine einzelne Prozentzahl gibt es nicht. `paid_family_leave_wage_replacement` in dieser Datei ist
definiert als: **effektive Ersatzrate eines Verdieners mit dem durchschnittlichen Wochenlohn des
Bundesstaats, nach Anwendung der Staffelung UND des Wochendeckels.** Formel je Zeile:
`Rate = min(Staffelformel(AWW); Wochendeckel) / AWW`.
Bezugsgroesse AWW = BLS QCEW Average Weekly Wage, Q1 2026, je Staat
(https://www.bls.gov/news.release/cewqtr.t03.htm). Belegart `berechnet`.

Staffelung und Deckel (Parameter 2026) im Einzelnen:

| Jurisdiktion | Staffelung | Wochendeckel | AWW (QCEW Q1 2026) | Deckel bindet? |
|---|---|---|---|---|
| California | 90 % unter 1.252,30 USD (= 70 % SAWW), sonst 70 % | 1.765 USD | 1.986 | nein |
| Colorado | 90 % bis 767,47 USD (50 % SAWW), darueber 50 % | 1.381,45 USD | 1.774 | nein |
| Connecticut | 95 % bis 677,60 USD (40x Mindestlohn 16,94 USD), darueber 60 % | 1.016,40 USD (60x Mindestlohn) | 2.080 | **ja** |
| Delaware | 80 % flach (unter 100 USD AWW: 100 %) | 900 USD | 1.606 | **ja** |
| District of Columbia | 90 % bis 1.104 USD (150 % x Mindestlohn 18,40 x 40), darueber 50 % | 1.190 USD | 2.725 | **ja** |
| Maine | 90 % bis 624,56 USD (50 % SAWW), darueber 66 % | 1.249,12 USD (= SAWW) | 1.327 | nein |
| Maryland | 90 % fuer niedrige Loehne, sonst 50 % | 1.000 USD | 1.676 | **ja** |
| Massachusetts | 80 % bis 961,24 USD (50 % SAWW 1.922,48), darueber 50 % | 1.230,39 USD | 2.201 | **ja** |
| Minnesota | 90 % bis 711,50 USD, 66 % bis 1.423 USD, 55 % darueber | 1.423 USD (= SAWW) | 1.630 | nein |
| New Jersey | 85 % flach | 1.119 USD | 1.879 | **ja** |
| New York | 67 % flach | 1.228,53 USD | 2.363 | **ja** |
| Oregon | 100 % bis 916,58 USD (65 % SAWW 1.410,13), darueber 50 % | 1.636,56 USD | 1.481 | nein |
| Rhode Island | 4,62 % des hoechsten Basisquartals ≈ 60 % des AWW | 1.103 USD | 1.487 | nein |
| Virginia | 80 % flach | 100 % SAWW | 1.665 | nein |
| Washington | 90 % bis 915 USD (50 % SAWW 1.830), darueber 50 % | 1.647 USD | 1.998 | nein |

Konsequenz: In sieben Jurisdiktionen (CT, DE, DC, MD, MA, NJ, NY) bestimmt **der Deckel**, nicht die
nominale Rate, was ein Durchschnittsverdiener bekommt. DC hat nominal die zweitgrosszuegigste Staffel
(90 %) und landet wegen des niedrigen Deckels bei 43,7 % — dem schlechtesten Wert im Feld. Wer nur die
nominale Spitzenrate vergleicht, dreht die Rangfolge um.

**F-3 — Elternzeit ist nicht gleich Mutterschutz.**
`paid_family_leave_weeks` misst ausschliesslich **Bonding Leave** (Zeit zur Bindung an das Neugeborene).
Die medizinisch begruendete Zeit rund um die Geburt laeuft in allen Programmen als **Medical Leave** und
kommt bei der Mutter zusaetzlich obendrauf — typisch 6 bis 12 Wochen. Beispiele:
- Connecticut: 12 Wochen + **2 Zusatzwochen** bei schwangerschaftsbedingter Arbeitsunfaehigkeit.
- Colorado: + 4 Wochen bei Schwangerschaftskomplikationen; seit 2026 zusaetzlich **+12 Wochen**, wenn das
  Kind stationaer auf einer Neugeborenen-Intensivstation (NICU) liegt.
- Washington: bis zu 18 Wochen kombiniert bei Schwangerschaftskomplikationen.
- District of Columbia: + 2 Wochen Praenatalzeit (also bis 14 Wochen rund um die Geburt).
- Minnesota / Massachusetts / Oregon: bis zu 20 Wochen kombiniert (Family + Medical) pro Jahr.
Die Spalte bildet all das **nicht** ab. Ein Vergleich mit europaeischen Mutterschutz-plus-Elternzeit-Werten
unterschaetzt die USA hier systematisch.

**F-4 — Delaware: 12 Wochen gelten nur fuer Elternzeit.**
Delaware Paid Leave gibt 12 Wochen Parental Leave pro Jahr, aber fuer **alle anderen** Anlaesse nur
6 Wochen je 24 Monate. Ausserdem gestaffelte Arbeitgebergroessen: ab 10 Beschaeftigten nur Elternzeit,
ab 25 Beschaeftigten das volle Leistungspaket. Sekundaerquellen, die pauschal „6-8 Wochen" nennen
(so New America), meinen die Nicht-Eltern-Anlaesse und sind fuer diese Kennzahl falsch.

**F-5 — Rhode Island rechnet ueber das Quartal, nicht ueber den Wochenlohn.**
Die TCI-Wochenleistung ist 4,62 % des hoechsten Quartals der Basisperiode. 4,62 % x 13 Wochen = 60,1 %,
daher der Ansatz 60 %. Gesetzlich steigt der Faktor auf 5,38 % (ab 01.01.2027, ≈ 70 %) und 5,77 %
(ab 01.01.2028, ≈ 75 %). Die Wochenzahl wurde zum 01.01.2026 von 7 auf **8** angehoben.
New America fuehrt RI mit „70 % (2026)" — das ist nach dem Gesetzestext **ein Jahr zu frueh**;
diese Datei folgt dem Gesetzestext (60 % in 2026).

**F-6 — FRE-Wochen.**
`paid_family_leave_fre_weeks` = `paid_family_leave_weeks` x `paid_family_leave_wage_replacement` / 100,
Belegart `berechnet`. Gegenstueck zur OECD-Kennzahl PF2.1 („full-rate equivalent" Wochen) auf der
Laenderseite. **Nicht identisch**: OECD PF2.1 rechnet fuer eine Person mit dem
Durchschnittsverdienst des Landes und umfasst Mutterschutz plus Elternzeit; diese Spalte umfasst nur
Bonding Leave (siehe F-3) und nimmt den Durchschnittsverdienst des jeweiligen Bundesstaats. Der
US-Bundeswert liegt unabhaengig davon bei 0 — es gibt kein nationales Programm; FMLA (1993) gibt nur
12 Wochen **unbezahlt** und nur fuer rund 56 % der Beschaeftigten.

**F-7 — QCEW-Q1-Loehne sind bonus-verzerrt.**
Der BLS-QCEW-Durchschnittslohn des ersten Quartals enthaelt Jahresboni und liegt daher ueber dem
Jahresdurchschnitt — besonders in Finanzzentren (CT, NY, MA, DC). Wo der Deckel bindet, faellt die
berechnete Ersatzrate dadurch etwas **zu niedrig** aus. Wo er nicht bindet, ist der Effekt gering.
Konsistenz ueber alle Staaten war hier wichtiger als die Wahl des Quartals; ein Neulauf auf den
QCEW-Jahresdurchschnitt wuerde CT, NY, MA und DC um schaetzungsweise 2 bis 5 Prozentpunkte anheben.

**F-8 — Gesetzlicher Urlaub ist etwas anderes als bezahlte Krankentage.**
`statutory_paid_vacation_days` = **0 in allen 50 Staaten und DC** — geprueft, nicht angenommen.
Der Fair Labor Standards Act verlangt keine Bezahlung fuer nicht gearbeitete Zeit, und kein
Bundesstaat kennt einen gesetzlichen Mindesturlaub. Was existiert, sind Auszahlungsregeln fuer
ungenutzte Urlaubstage bei Kuendigung (PTO-Payout-Gesetze in CA, CO, MT u.a.) — die schreiben aber
keinen Anspruch vor, sondern nur, wie mit freiwillig gewaehrtem Urlaub umzugehen ist.
Nicht verwechseln.

---

## 3. Bezahlte Krankentage (`paid_sick_leave_days`)

Zusatzmetrik, nicht Teil des urspruenglichen Auftragskerns. 16 Jurisdiktionen mit belegter jaehrlicher
Nutzungsobergrenze, umgerechnet mit **8 Stunden = 1 Arbeitstag** (Belegart `berechnet`):

Alaska 7,0 · Arizona 5,0 · California 5,0 · Colorado 6,0 · Connecticut 5,0 · District of Columbia 7,0 ·
Maryland 8,0 · Massachusetts 5,0 · Michigan 5,0 · Nebraska 7,0 · New Jersey 5,0 · New Mexico 8,0 ·
New York 7,0 · Oregon 5,0 · Rhode Island 5,0 · Vermont 5,0

Angesetzt ist jeweils der Wert fuer die **groesste Arbeitgeberklasse**. Mehrere Staaten staffeln nach
Betriebsgroesse (Alaska 56 h ab 15 Beschaeftigten, sonst 40 h; Arizona 40 h ab 15, sonst 24 h;
Nebraska 56 h ab 20, 40 h bei 11-19; New York 56 h ab 100 Beschaeftigten). Kleinbetriebsbeschaeftigte
bekommen also weniger als der Tabellenwert.

Alle uebrigen Staaten: **0**, Belegart `abgelesen`.

---

## 4. Luecken und offene Punkte

**L-1 — `paid_sick_leave_days` fuer fuenf Staaten leer (`nicht geprueft`):**
- **Minnesota, Washington**: Gesetz vorhanden, aber ohne eindeutige jaehrliche Nutzungsobergrenze in der
  Quelle („no specified maximum"). Ein Wert waere geraten.
- **Illinois, Maine, Nevada**: haben bezahlte Freizeit **fuer jeden Zweck** („any reason"), nicht
  krankheitsgebunden. Eine 0 waere hier sachlich falsch, ein Krankentage-Wert ebenso.

**L-2 — Maryland-Ersatzrate ist eine Untergrenzen-Rechnung.**
Marylands Tier-Schwelle ist an eine noch nicht veroeffentlichte SAWW gebunden. Da der Deckel von
1.000 USD bei einem AWW von 1.676 USD unter jeder plausiblen Staffelvariante bindet, ist das Ergebnis
(59,7 %) trotzdem robust. Der Wert kann sich aendern, wenn Maryland den Deckel bis 2028 anhebt —
das Gesetz sieht eine jaehrliche Anpassung vor, die noch nicht feststeht.

**L-3 — Virginia-Parameter aus der Gesetzesfassung, nicht aus einem laufenden Programm.**
80 % / Deckel 100 % SAWW / 12 Wochen stammen aus HB 1207 bzw. SB 2 (unterzeichnet 22.04.2026). Bis
zum Leistungsstart 01.12.2028 sind Verordnungsanpassungen moeglich. Bei Maryland gilt dasselbe:
Marylands Termin wurde bereits mehrfach verschoben (urspruenglich 2025).

**L-4 — Primaerquellen teils nicht direkt lesbar.**
`nationalpartnership.org`, `bipartisanpolicy.org` und die PDF-Uebersicht der National Partnership
liefern beim automatisierten Abruf HTTP 403. Die Jurisdiktionsliste ist deshalb ueber
**A Better Balance** (Uebersichtsseite) und **New America** (19.05.2026) belegt, die Einzelparameter
ueber die jeweiligen Landesbehoerden bzw. deren aktuelle Leistungsbekanntmachungen. Wo ein Parameter
nur ueber eine Sekundaerquelle belegt ist (New Jersey, New York: Wochen und Rate ueber New America),
steht das so in `source_name`.

**L-5 — Kein Wert fuer kommunale Programme.**
Einzelne Staedte (z. B. San Francisco Paid Parental Leave Ordinance) stocken die Landesleistung auf.
Nicht erfasst; die Datei ist rein bundesstaatlich.

---

## 5. Zeilenbilanz

306 Datenzeilen + 1 Kopfzeile = 307.
51 Einheiten (50 Staaten + DC) x 6 Metriken:
`paid_family_leave_status`, `paid_family_leave_weeks`, `paid_family_leave_wage_replacement`,
`paid_family_leave_fre_weeks`, `statutory_paid_vacation_days`, `paid_sick_leave_days`.
