# Schusswaffentote Kinder und Jugendliche (Alter 1-19) — US-Bundesstaaten und Laender

Dateien: `youth_firearm_us_states.csv` (408 Zeilen) · `youth_firearm_countries.csv` (186 Zeilen).
Erstellt am 2026-09-18. Altersbegrenzte Variante der bestehenden Reihen in
`us_states_justice.csv` / `countries_justice.csv`. **Bestand unveraendert.**

Kein Wert ist geschaetzt, interpoliert oder aus dem Gedaechtnis ergaenzt. Luecken stehen als Luecke.

---

## 0. Die Definition — auf beiden Seiten dieselbe

| | US-Bundesstaaten | Laender |
|---|---|---|
| Quelle | CDC WONDER D158 „Underlying Cause of Death, 2018-2024, Single Race" | WHO Mortality Database, Rohdateien `Morticd10_part5`/`part6` + `morticd10_add` |
| Zaehler | Injury Mechanism = **Firearm** = ICD-10 W32-W34, X72-X74, X93-X95, Y22-Y24, Y35.0, U01.4 | dieselben ICD-10-Codes, direkt aus den Rohdaten gefiltert |
| Intentionen | alle (Unfall, Suizid, Toetung, unbestimmt, polizeiliche Gewalt/Kriegshandlung) | alle |
| Alter | Single-Year Ages 1,2,…,19 einzeln ausgewaehlt | Altersspalten `Deaths3`-`Deaths9` (1, 2, 3, 4, 5-9, 10-14, 15-19) |
| Nenner | WONDER-Bevoelkerung derselben Altersauswahl | WHO-Datei `mort_pop`, Spalten `Pop3`-`Pop9` |
| Rate | Rohrate je 100.000, **nicht** altersstandardisiert | Rohrate je 100.000, **nicht** altersstandardisiert |

**Kein Anteilsrechnen.** Auf beiden Seiten sind die Altersgruppen als eigene Spalten in den
Rohdaten vorhanden und wurden aufsummiert. Es wurde nirgends ein Alters-Anteil auf eine
Gesamtzahl angewendet.

### V1 — Belegter Gleichheitsnachweis der beiden Pipelines
Fuer die USA laesst sich dieselbe Groesse aus beiden Quellen rechnen:

* WHO-Rohdatei, USA 2019, Codes wie oben, Spalten `Deaths3`-`Deaths9`: **3.378 Tote** (berechnet).
* CDC WONDER D158, USA 2019, Mechanism = Firearm, Single-Year Ages 1-19: **3.378 Tote** (abgelesen).

Die beiden Wege liefern **exakt dieselbe Zahl**. Damit ist die Definitionsgleichheit nicht nur
behauptet, sondern gezeigt. (Auch die Nenner stimmen ueberein: 77.842.364 aus der Census-Datei NC-EST2019 und
77.842.364 in der WONDER-Ausgabe fuer 2019.)

---

## 1. US-Bundesstaaten

### 1.1 Was im CSV steht
Acht Metrik/Jahr-Kombinationen je 51 Gebietseinheiten (50 Staaten + DC):

| Metrik | Jahr | vollstaendig? |
|---|---|---|
| `firearm_deaths_youth_rate` / `_count` | 2024 | **45/50** Staaten + DC — 5 unterdrueckt |
| `firearm_deaths_youth_rate` / `_count` | 2020-2024 (5-Jahres-Pool) | **50/50** + DC — keine Unterdrueckung |
| `firearm_deaths_youth_homicide_rate` / `_count` | 2020-2024 (5-Jahres-Pool) | **45/50** + DC — 5 unterdrueckt |
| `firearm_deaths_youth_suicide_rate` / `_count` | 2020-2024 (5-Jahres-Pool) | **47/50** — 3 Staaten + DC unterdrueckt |

### 1.2 Unterdrueckungen (CDC-Regel: Zellen mit weniger als 10 Faellen)
**Unterdrueckt heisst LUECKE, nicht null.** Im CSV steht dort ein leeres Feld, und die
Quellenspalte sagt es ausdruecklich.

* **Jahr 2024, alle Intentionen — 5 Staaten:** Hawaii, New Hampshire, North Dakota, Rhode Island, Vermont.
* **Pool 2020-2024, alle Intentionen — 0 Staaten.** Der Mehrjahres-Pool behebt das Problem vollstaendig.
* **Pool 2020-2024, Toetung — 5 Staaten:** Hawaii, Maine, North Dakota, Vermont, Wyoming.
* **Pool 2020-2024, Suizid — 3 Staaten + DC:** Delaware, Hawaii, Rhode Island, District of Columbia.

**Antwort auf die Frage im Auftrag:** Ja, der Mehrjahres-Pool behebt die Unterdrueckung — aber
nur fuer die Gesamtgroesse. Bei der Aufspaltung nach Toetung und Suizid bleiben auch im
5-Jahres-Pool Luecken, weil die Fallzahlen in kleinen Staaten je Intention weiter unter 10 liegen.

### 1.3 Transkriptionsprobe (berechnet)
Die Summe der 51 abgelesenen Werte des Pools ergibt **22.013** — genau den von WONDER
ausgewiesenen Gesamtwert. Die drei uebrigen Abfragen weichen genau um die Summe der
unterdrueckten Zellen ab (2024: 20 Faelle auf 5 Staaten; Toetung: 34 auf 5; Suizid: 18 auf 4) —
jeweils plausibel mit weniger als 10 je Zelle. Die Transkription aus der WONDER-Ausgabe ist
damit geprueft.

### 1.4 Min / Median / Max ueber die 50 Staaten (DC separat)

| Reihe | n/50 | Min | Median | Max | DC |
|---|---|---|---|---|---|
| alle Intentionen, 2024 | 45 | 1,3 (New Jersey) | 5,4 | 13,6 (Mississippi) | 17,5 |
| alle Intentionen, Pool 2020-2024 | 50 | 1,0 (Hawaii) | 5,6 | 14,7 (Louisiana) | 18,4 |
| Toetung, Pool 2020-2024 | 45 | 0,5 (Idaho) | 3,4 | 11,6 (Louisiana) | 17,5 |
| Suizid, Pool 2020-2024 | 47 | 0,3 (Massachusetts, New Jersey) | 2,2 | 6,6 (Montana) | unterdrueckt |

Belegart der Zeile: **berechnet** aus den abgelesenen Einzelwerten. Der Median der
2024er-Reihe beruht nur auf 45 Staaten; die 5 fehlenden sind alle kleine Staaten mit niedrigen
Werten, der wahre Median der 50 laege also eher etwas niedriger. Fuer Rankings die Pool-Reihe
verwenden, nicht die 2024er.

### 1.5 Warum ueber die Weboberflaeche und nicht ueber die API
Die CDC-WONDER-API laesst fuer Sterbedaten **keine** Gliederung nach Bundesstaat zu. Im
API-Hilfetext steht woertlich, dass Abfragen fuer Sterbe- und Geburtsstatistik des NVSS nicht nach
Region, Division, State, County oder Urbanisierung eingeschraenkt oder gruppiert werden duerfen.
Ein POST auf denselben Endpunkt ausserhalb eines Browsers wird zusaetzlich von der vorgelagerten
Firewall mit „Access Denied" beantwortet (geprueft 2026-09-18, alle `stage=request`-Anfragen).
Die Werte stammen deshalb aus der regulaeren Weboberflaeche. Die Abfrageparameter sind in der
Quellenspalte jeder Zeile vollstaendig dokumentiert und reproduzierbar.

### 1.6 Definitionsfallen (US-Seite)
* **F-US-1 — Nicht altersstandardisiert.** Rohraten. Die CDC-Seite „Stats of the States" zeigt
  altersstandardisierte Werte; die sind mit diesen nicht identisch. Fuer den Laendervergleich ist
  die Rohrate die richtige Groesse.
* **F-US-2 — Suizid + Toetung ist nicht die Gesamtzahl.** Unfall, unbestimmte Intention und
  polizeiliche Gewaltanwendung fehlen in der Summe. Pool 2020-2024 national: 22.013 gesamt
  gegenueber 14.264 Toetung + 6.430 Suizid = 20.694; die Differenz von 1.319 ist die Restkategorie.
* **F-US-3 — Der Pool ist eine Personenjahr-Rate.** Zaehler = Tote 2020-2024, Nenner = Summe der
  fuenf Jahresbevoelkerungen. Nicht mit einer Jahresrate verwechseln und nicht mit 5 multiplizieren.
* **F-US-4 — DC ist kein Bundesstaat** und in keinem Min/Median/Max enthalten.
* **F-US-5 — Wohnsitzprinzip.** WONDER zaehlt nach Wohnsitz des Verstorbenen, nicht nach Sterbeort.

---

## 2. Laender

### 2.1 Was im CSV steht
Sechs Metriken je 31 Gebietseinheiten (die 30 beauftragten Laender + USA als Bezugsgroesse,
weil die USA in der bestehenden Reihe `countries_justice.csv` ebenfalls mitlaufen):
`firearm_deaths_youth_rate`, `_homicide_rate`, `_suicide_rate` und die drei zugehoerigen
`_count`-Metriken. Jahr durchgaengig **2019** — dasselbe Ankerjahr wie im Bestand.

### 2.2 Ergebnis (Rate je 100.000 im Alter 1-19 und absolute Fallzahl, 2019)

| Land | Rate gesamt | n gesamt | n Toetung | n Suizid | Nenner (Alter 1-19) |
|---|---|---|---|---|---|
| USA | **4,34** | 3.378 | 2.013 | 1.167 | 77.842.364 |
| Kanada | **0,73** | 57 | 24 | 26 | 7.769.675 |
| Schweden | 0,44 | 10 | 9 | 1 | 2.275.375 |
| Israel | 0,36 | 11 | 7 | 4 | 3.081.413 |
| Oesterreich | 0,24 | 4 | 2 | 2 | 1.634.167 |
| Belgien | 0,20 | 5 | 3 | 1 | 2.456.854 |
| Schweiz | 0,18 | 3 | 2 | 0 | 1.627.997 |
| Finnland | 0,18 | 2 | 0 | 2 | 1.126.349 |
| Norwegen | 0,17 | 2 | 1 | 1 | 1.196.994 |
| Frankreich | 0,16 | 24 | 13 | 8 | 14.880.550 |
| Daenemark | 0,16 | 2 | 2 | 0 | 1.235.744 |
| Kroatien | 0,14 | 1 | 1 | 0 | 727.778 |
| Portugal | 0,11 | 2 | 2 | 0 | 1.872.424 |
| Italien | 0,11 | 11 | 2 | 7 | 10.136.122 |
| Tschechien | 0,10 | 2 | 0 | 2 | 2.061.029 |
| Griechenland | 0,10 | 2 | 1 | 1 | 1.994.085 |
| Australien | 0,10 | 6 | 1 | 5 | 5.923.705 |
| Niederlande | 0,08 | 3 | 3 | 0 | 3.590.064 |
| Deutschland | 0,05 | 7 | 3 | 3 | 14.532.978 |
| Spanien | 0,04 | 4 | 0 | 1 | 8.898.606 |
| Vereinigtes Koenigreich | 0,03 | 4 | 1 | 3 | 14.895.068 |
| Polen | 0,03 | 2 | 0 | 0 | 7.267.722 |
| Suedkorea | 0,01 | 1 | 0 | 0 | 8.960.193 |
| Japan | 0,00 | 0 | 0 | 0 | 19.832.378 |
| Ungarn | 0,00 | 0 | 0 | 0 | 1.816.252 |
| Irland | 0,00 | 0 | 0 | 0 | 1.277.231 |
| Lettland | 0,00 | 0 | 0 | 0 | 375.469 |
| Litauen | 0,00 | 0 | 0 | 0 | 528.414 |
| Estland | 0,00 | 0 | 0 | 0 | 264.255 |
| Bosnien | 0,00 | 0 | 0 | 0 | kein Nenner (s. L-L-2) |
| Russland | **LUECKE** | — | — | — | — |

(Sortierung nach Rate. Die Raten sind **berechnet**, die Fallzahlen **abgelesen**.)

### 2.3 Warum die Fallzahl mitgeliefert wird — das ist der wichtigste Punkt dieser Tabelle
Mehrere Raten beruhen auf ein bis vier Toten. Beispiele: Kroatien 0,14 = **1 Toter**.
Daenemark 0,16 = **2 Tote**. Schweiz 0,18 = **3 Tote**. Portugal 0,11 = **2 Tote**.
Deutschland 0,05 = **7 Tote**.

**Ein einziger Todesfall mehr oder weniger verschiebt diese Raten um 50 bis 100 Prozent.**
Solche Werte duerfen nicht als Rangliste dargestellt werden und tragen keine Aussage darueber,
welches europaeische Land „sicherer" ist. Was sie tragen, ist der Groessenunterschied zu den USA:
3.378 gegenueber ein- bis zweistelligen Zahlen. Eine Nullzeile (Japan, Ungarn, Irland, Lettland,
Litauen, Estland, Bosnien) heisst hier tatsaechlich null gemeldete Faelle — die WHO unterdrueckt
anders als CDC keine kleinen Zellen.

### 2.4 Abweichende Nenner (dokumentierte Ausnahmen)
Die WHO-Populationsdatei `mort_pop` fuehrt fuer vier Laender das Jahr 2019 nicht. Ersatznenner,
jeweils Alter 1-19, Belegart abgelesen:

| Land | Nenner | Quelle | Stichtag |
|---|---|---|---|
| USA | 77.842.364 | US Census Bureau, NC-EST2019-AGESEX-RES (Einzeljahrgaenge) | 1. Juli 2019 |
| Kanada | 7.769.675 | Statistics Canada, Tabelle 17-10-0005-01 | 1. Juli 2019 |
| Portugal | 1.872.424 | Eurostat `demo_pjan` | 1. Januar 2019 |
| Estland | 264.255 | Eurostat `demo_pjan` | 1. Januar 2019 |

**Falle:** Eurostat ist ein Stichtag zum 1. Januar, die WHO-Datei und die US/CA-Quellen sind
Jahresmitte. Bei diesen Groessenordnungen liegt der Unterschied im Promillebereich und dreht keine
Reihenfolge, er ist aber kein Rundungsfehler und gehoert erwaehnt.

### 2.5 Luecken auf der Laenderseite
* **L-L-1 — Russland: keine Schusswaffenzahl moeglich.** Russland meldet an die WHO nur die
  gekuerzte Ursachenliste (`List` = 101, 104 Positionen). Die Schusswaffen-Codes sind darin nicht
  getrennt enthalten. Das entspricht dem Bestand: auch `countries_justice.csv` fuehrt Russland bei
  allen drei `firearm_*`-Metriken nicht. Kein Ersatz, keine Schaetzung.
* **L-L-2 — Bosnien: kein Nenner fuer 2019.** Die WHO-Populationsdatei fuehrt Bosnien nur
  1985-1991, 2010-2016 und 2021-2024, nicht 2019. Eurostat `demo_pjan` und `demo_pjangroup`
  liefern fuer Bosnien 2019 ebenfalls nichts (geprueft 2026-09-18), die World-Bank-Altersreihen
  sind fuer BIH ab 2016 leer, und die UN-Data-Portal-API verlangt inzwischen einen Token (HTTP 401).
  Der **Zaehler** ist belegt und lautet 0: Bosnien meldet fuer 2019 durchaus Codes aus dem
  Schusswaffenbereich (X73 und Y24 tauchen in den Rohdaten auf, alle Alter), aber keinen einzigen
  im Alter 1-19, bei 121 gemeldeten Sterbefaellen dieser Altersgruppe insgesamt. Die Rate ist
  deshalb **exakt 0,00 unabhaengig vom Nenner**; ein Nenner wurde nicht geschaetzt.
* **L-L-3 — Keine Konfidenzintervalle.** Die WHO-Rohdaten liefern keine. Bei n=1 bis n=7 waere ein
  Intervall die eigentlich interessante Angabe; sie fehlt.

### 2.6 Definitionsfallen (Laenderseite)
* **F-L-1 — Altersformate.** Die WHO-Spalten `Deaths3`-`Deaths9` decken je nach `Frmat` des Landes
  entweder Einzeljahre (Frmat 00/01) oder das zusammengefasste Feld 1-4 (Frmat 02, bei Frankreich,
  Finnland, Irland, Kanada) ab. In beiden Faellen ergibt die Summe der Spalten 3 bis 9 genau
  Alter 1-19. Kein Land des Satzes nutzt Frmat 08/09 (5-14/15-24), bei denen die Abgrenzung
  nicht moeglich waere. Geprueft je Land, `Frmat` steht in den Rohdaten.
* **F-L-2 — Norwegen und Deutschland aus Zusatzdateien.** Norwegen 2019 steht nicht in
  `Morticd10_part5`, sondern in `morticd10_add/Norway.xlsx`; Deutschland ist in beiden Quellen
  gefuehrt. Gleiches Vorgehen wie im Bestand.
* **F-L-3 — Vereinigtes Koenigreich = Landescode 4308 (Gesamt-UK)**, nicht die drei Teilgebiete
  4310/4320/4330. Nicht mischen.

---

## 3. Der wichtigste Vorbehalt der ganzen Lieferung: die Jahre passen nicht zusammen

Die Staatenwerte sind 2024 beziehungsweise 2020-2024. Die Laenderwerte sind 2019 — weil die
WHO Mortality Database fuer mehrere dieser Laender kein spaeteres gemeinsames Jahr fuehrt und weil
der Bestand dasselbe Ankerjahr nutzt. **Eine Grafik darf nicht „Stand 2024" ueber beide Seiten
schreiben.**

Als Bruecke liegt die US-Zeile in beiden Dateien vor:
* USA 2019, WHO-Rechenweg: **4,34** je 100.000 (3.378 Tote) — in `youth_firearm_countries.csv`.
* USA 2024, CDC WONDER: **4,9** je 100.000 (3.865 Tote); Pool 2020-2024: **5,6**.
Wer die Laenderreihe von 2019 gegen die Staatenreihe von 2024 stellt, vergleicht also gegen eine
US-Groesse, die seither um rund ein Achtel gestiegen ist.

---

## 4. AUFGABE 3 — Belegpruefung: „Schusswaffen sind in den USA seit 2020 die haeufigste Todesursache bei Kindern und Jugendlichen"

### 4.1 Die Referenz
Goldstick JE, Cunningham RM, Carter PM. *Current Causes of Death in Children and Adolescents in
the United States.* New England Journal of Medicine 2022; 386:1955-1956, veroeffentlicht am
20. April 2022. DOI 10.1056/NEJMc2201761.
Volltext frei: https://pmc.ncbi.nlm.nih.gov/articles/PMC10042524
Datenquelle der Autoren: CDC WONDER. Betrachtungszeitraum der Auswertung: 1999 bis 2020.

**Die Altersabgrenzung der Autoren lautet woertlich „persons 1 to 19 years of age"** — also
Alter 1 bis 19, Saeuglinge (unter 1 Jahr) ausdruecklich ausgeschlossen. (abgelesen)

Aktualisierung derselben Autorengruppe: *Current Causes of Death among Children and Adolescents
in the United States*, NEJM 2026; 394:1958-1959, DOI 10.1056/NEJMc2600445, PubMed 42127398,
Auswertung 2018-2023, wieder Alter 1-19. Diese Aktualisierung wurde **nicht** im Volltext
geprueft (NEJM antwortet mit HTTP 403); die daraus zitierten Angaben — 4.455 Schusswaffentote
im Alter 1-19 im Jahr 2023 und ein Anstieg der Rate um 3,9 Prozent von 2020 bis 2023 — sind
**nicht geprueft** und stammen aus der Verlagszusammenfassung.

### 4.2 Eigene Nachrechnung an der Primaerquelle (CDC WONDER D158, Abfrage 2026-09-18)
Gruppierung: Injury Mechanism & All Other Leading Causes; Single-Year Ages einzeln; USA gesamt.
Alle Zahlen **abgelesen**.

| Alter | Jahr | Platz 1 | Platz 2 | Platz 3 |
|---|---|---|---|---|
| **1-19** | 2019 | Schusswaffen **3.378** | Strassenverkehr 3.233 | Ersterstickung 1.508 |
| **1-19** | 2020 | Schusswaffen **4.357** | Strassenverkehr 3.639 | Vergiftung 1.845 |
| **1-19** | 2024 | Schusswaffen **3.865** | Strassenverkehr 3.709 | „uebrige Krankheiten" 1.906, Krebs 1.757 |
| **1-17** | 2024 | Schusswaffen **2.214** | Strassenverkehr 2.119 | „uebrige Krankheiten" 1.587, Krebs 1.511 |
| **0-19** | 2024 | **Perinatale Zustaende 9.979** | **Angeborene Fehlbildungen 5.123** | Schusswaffen 3.879, dann Strassenverkehr 3.783 |

### 4.3 Verdikt

1. **Die Aussage haelt fuer die Altersgruppe 1-19 und gilt auch fuer den aktuellsten Jahrgang.**
   2024 stehen Schusswaffen mit 3.865 Toten weiter vor dem Strassenverkehr mit 3.709.
2. **Aber der Abstand ist klein geworden.** 2020 lagen 718 Tote zwischen Platz 1 und Platz 2
   (20 Prozent), 2024 nur noch **156 Tote (4 Prozent)**. Das ist keine komfortable Fuehrung; eine
   Datenrevision oder ein normales Schwankungsjahr kann die Reihenfolge kippen. Wer „mit
   grossem Abstand" schreibt, schreibt die Lage von 2020, nicht die von 2024.
3. **„seit 2020" ist im aktuellen Datenstand zu spaet angesetzt.** In der heute abrufbaren Datei
   (D158, Vintage 2024) liegen Schusswaffen bereits **2019** vorn: 3.378 gegenueber 3.233.
   Die Autoren berichteten 2022 auf Basis der damaligen Datei den Wechsel fuer 2020. Der
   Unterschied ist kein Widerspruch, sondern Folge spaeterer Datenrevisionen und einer anderen
   WONDER-Vintage. Sauber formuliert: **„spaetestens seit 2020"**.
4. **Die Altersabgrenzung traegt das Ergebnis — ausdruecklich ja.**
   Nimmt man Saeuglinge hinzu (Alter 0-19), rutschen Schusswaffen auf **Platz 3** hinter
   perinatale Zustaende und angeborene Fehlbildungen. Die Aussage steht und faellt damit, dass
   das erste Lebensjahr ausgeschlossen wird. Das ist fachlich gut begruendet (Saeuglingssterben
   folgt einer voellig anderen Ursachenstruktur und wird in der Epidemiologie regelmaessig
   getrennt gefuehrt), es ist aber eine Setzung, und wer die Aussage zitiert, muss „ab dem
   ersten Geburtstag" mitliefern.
   Die Untergrenze 17 statt 19 kippt das Ergebnis dagegen **nicht**: auch fuer 1-17 liegen
   Schusswaffen 2024 vorn (2.214 gegenueber 2.119) — wieder mit nur 4 Prozent Abstand.
5. **Der Vergleichsgegner ist eine Mechanismus-Kategorie, keine „Todesursache" im Sinne der
   amtlichen 15er-Liste.** „Schusswaffen" fasst Toetung, Suizid, Unfall und polizeiliche Gewalt
   zusammen, „Strassenverkehr" ebenso. In der klassischen Rangliste der Todesursachen tauchen
   beide so nicht auf. Die Aussage ist korrekt, aber nur innerhalb dieser Systematik.

---

## 5. AUFGABE 4 — Schulschiessereien: zwei Zaehlungen, zwei Definitionen

**Nur als Kontextzahl fuer den Fliesstext. Kein Ranking, kein Laendervergleich.**

### 5.1 Die weite Zaehlung — K-12 School Shooting Database (David Riedman)
Definition woertlich von der Datenbank: gezaehlt wird, „when a gun is fired, brandished with
intent to harm, or a bullet hits school property for any reason, regardless of the number of
victims, time, or day of the week". Ausdruecklich eingeschlossen sind Bandenschiessereien,
haeusliche Gewalt, Vorfaelle bei Sportveranstaltungen und Abendterminen, Suizide, eskalierte
Schlaegereien und Unfaelle. Ein Vorfall ohne jeden Verletzten zaehlt mit.
Quelle: https://k12ssdb.org/all-shootings (Datenstand der veroeffentlichten Diagramme,
abgerufen 2026-09-18)

* **2024: 336 Vorfaelle** (abgelesen aus dem Diagramm „Incidents by Year 1966-2026").
  Zum Einordnen: 2023 = 352 (Hoechstwert der Reihe), 2022 = 308, 2021 = 257, 2020 = 116, 2019 = 96.
* **2024: 276 Opfer** — getoetet **und** verletzt zusammen (Diagramm „Number of victims (fatal and
  wounded) on K-12 school property"). 2023 = 250, 2022 = 273, 2021 = 189, 2020 = 74, 2019 = 119.
* **LUECKE:** Eine getrennte Zahl nur der **Getoeteten** veroeffentlicht die Datenbank in ihren
  frei zugaenglichen Diagrammen nicht. Der Rohdatensatz ist laut Website nur auf schriftliche
  Anfrage per E-Mail erhaeltlich. Die Zahl der Toten 2024 nach dieser weiten Definition ist
  deshalb hier **nicht beschafft** — sie wurde nicht geschaetzt.
* Presseberichte nennen fuer 2024 269 statt 276 Opfer. Die Datenbank wird laufend nachgepflegt;
  massgeblich ist der hier abgelesene Stand mit Datum.

### 5.2 Die enge Zaehlung — FBI, Active Shooter Incidents in the United States in 2024
Definition woertlich: „one or more individuals actively engaged in killing or attempting to kill
people in a populated area". Erfasst wird also der Amoklauf, nicht jeder Schuss auf dem Gelaende.
Quelle (geprueft): FBI-Pressemitteilung vom 3. Juni 2025,
https://www.fbi.gov/news/press-releases/fbi-releases-2024-active-shooter-incidents-in-the-united-states-report

* **2024 insgesamt: 24 Amoklauf-Vorfaelle** in 19 Bundesstaaten, verteilt auf fuenf Ortskategorien,
  darunter „education". Gegenueber 2023 (48) eine Halbierung. (abgelesen, Pressemitteilung)
* Der Bericht selbst weist fuer die Kategorie „education" **4 Vorfaelle mit 8 Getoeteten und
  23 Verletzten** aus. Diese drei Zahlen sind **nicht geprueft**: das PDF des Berichts
  (https://www.fbi.gov/file-repository/reports-and-publications/2024-active-shooter-report)
  wird von der vorgelagerten FBI-Firewall mit HTTP 403 beantwortet, alle Download-Pfade wurden
  probiert. Die Angabe stammt aus einer Sekundaerzusammenfassung, die sich auf den Bericht beruft
  (Campus Safety Magazine, Juni 2025). Vor einer Veroeffentlichung am Originalbericht nachziehen.

### 5.3 Der Definitionsunterschied in einem Satz
336 gegenueber 4 — derselbe Gegenstand, zwei Zaehlungen, Faktor 84. Die weite Zaehlung misst,
wie oft an amerikanischen Schulen ueberhaupt geschossen wird; die enge misst, wie oft jemand
an einer Schule wahllos Menschen zu toeten versucht. Wer die Zahlen mischt, erzeugt einen Fehler
um fast zwei Groessenordnungen.

### 5.4 Vergleichbare Vorfaelle in den uebrigen 29 Laendern
**Es gibt dafuer keine einheitliche Quelle, und es wurde keine zusammengestellt.**
Es existiert kein internationales Register, das Schulschiessereien nach einer der beiden oben
genannten Definitionen laenderuebergreifend und fuer denselben Zeitraum erfasst. Die vorhandenen
Zusammenstellungen sind journalistische oder enzyklopaedische Einzelfallsammlungen mit jeweils
eigener, meist enger und nicht offengelegter Abgrenzung. Die bekannteste Gegenueberstellung
(CNN, Mai 2018: 288 Schulschiessereien in den USA gegenueber 5 in den uebrigen G7-Staaten
zwischen Januar 2009 und Mai 2018) verwendet eine dritte Definition — „mindestens eine Person
angeschossen" — und endet 2018. Sie ist damit weder mit der K-12-Zaehlung noch mit der
FBI-Zaehlung noch mit dem hier betrachteten Jahr 2024 kompatibel und wurde nicht uebernommen.

**Konsequenz fuer den Text:** Die Schulschiesserei-Zahl darf als US-Kontextzahl stehen, aber
nicht als Vergleichszeile in der Laendertabelle. Was sich belegt vergleichen laesst, ist die
Sterblichkeit (Abschnitte 1 und 2) — und die ist ohnehin die groessere Zahl: an amerikanischen
Schulen starben nach der weiten Zaehlung im Jahr 2024 hoechstens ein paar Dutzend Menschen,
waehrend im selben Jahr 3.865 Kinder und Jugendliche im Alter 1-19 durch Schusswaffen starben.
Schulschiessereien sind der sichtbare, aber kleine Teil.

---

## 6. Belegarten in den beiden CSV

* **abgelesen** — der Wert steht so in der Quelle: alle US-Werte (WONDER-Ausgabe) und alle
  `*_count`-Metriken der Laender (WHO-Rohdatei).
* **berechnet** — Rate = Tote / Bevoelkerung x 100.000, aus abgelesenen Zaehlern und Nennern;
  betrifft alle `*_rate`-Metriken der Laender.
* **nicht geprueft** — nur die Russland-Zeilen; dort steht kein Wert, sondern die Begruendung
  der Luecke.
* Nicht verwendet: *inferiert*, *angenommen*. Es steht kein geschaetzter Wert in den Dateien.
