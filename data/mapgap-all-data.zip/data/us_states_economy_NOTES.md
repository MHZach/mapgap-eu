# US-Bundesstaaten — Wirtschaftskennzahlen: Definitionsfallen, Lücken, Kennwerte

Stand der Recherche: 2026-09-18. Alle Werte in `us_states_economy.csv` (50 Staaten + DC separat)
und `fiscal_debt_deficit.csv` (13 Entities + USA-Detailzeilen).

Belegarten: `abgelesen` = direkt aus der Quelle übernommen · `berechnet` = aus abgelesenen
Quellwerten nach angegebener Formel gerechnet · `inferiert` / `angenommen` / `nicht geprüft`
sind im Text explizit markiert.

---

## 1. Vollständigkeit

| Kennzahl | Staaten | Jahr | Quelle |
|---|---|---|---|
| `gdp_per_capita_nominal` | 50/50 (+DC) | 2025 | BEA SAGDP1 / SAINC1 |
| `median_household_income` | 50/50 (+DC) | 2024 | Census ACS 1-Jahr, B19013 |
| `minimum_wage` | 50/50 (+DC) | Stand 01.07.2026 | DOL WHD |
| `minimum_wage_status` | 50/50 (+DC) | Stand 01.07.2026 | DOL WHD |
| `poverty_rate_official_acs` | 50/50 (+DC) | 2024 | Census ACS 1-Jahr, DP03 |
| `poverty_rate_spm_3yr_avg` | 50/50 (+DC) | 2022–2024 | Census P60-287 (CPS ASEC) |
| `poverty_rate_officialplus_3yr_avg` | 50/50 (+DC) | 2022–2024 | Census P60-287 (CPS ASEC) |
| `regional_price_parity_all_items` | 50/50 (+DC) | 2024 | BEA SARPP |

Keine Lücke auf Staatenebene. Die Lücken liegen bei den Bundeskennzahlen (siehe §6).

---

## 2. Min / Max / Median je Kennzahl (nur die 50 Staaten, DC ausgeschlossen)

| Kennzahl | Minimum | Maximum | Median | DC (nachrichtlich) |
|---|---|---|---|---|
| BIP pro Kopf nominal (USD, 2025) | Mississippi 55.877 | New York 123.369 | 81.157 | 277.689 |
| Median Household Income (USD, 2024) | Mississippi 59.127 | Massachusetts 104.828 | 77.803 | 109.707 |
| Mindestlohn (USD/h, 01.07.2026) | 7,25 (20 Staaten) | Washington 17,13 | 11,63 | 18,40 |
| Armutsquote ACS (%, 2024) | New Hampshire 7,2 | Louisiana 18,7 | 11,6 | 17,3 |
| SPM-Armutsquote (%, Ø 2022–2024) | Maine 6,7 | Louisiana 17,7 | 10,55 | 15,3 |
| Official+-Armutsquote (%, Ø 2022–2024) | Utah 6,6 | Louisiana 19,4 | 9,45 | 12,4 |
| Regional Price Parity (US=100, 2024) | Arkansas 86,9 | Kalifornien 110,7 | 96,67 | 109,9 |

DC ist in keiner dieser Kennzahlen Teil der 50 — DC verzerrt vor allem das BIP pro Kopf
(Pendler-Effekt: Wertschöpfung in DC, Wohnsitz in MD/VA) und gehört in einer
„If country XY were a US state"-Grafik nicht in die Verteilung.

---

## 3. Definitionsfallen — Staatenebene

**3.1 Nominal vs. kaufkraftbereinigt (RPP).**
`gdp_per_capita_nominal` und `median_household_income` sind laufende US-Dollar ohne
regionale Preisbereinigung. Die BEA Regional Price Parity (`regional_price_parity_all_items`,
US=100) ist der offizielle Deflator dafür. Kaufkraftbereinigung: `Wert / (RPP/100)`.
Spannweite 86,9 (AR) bis 110,7 (CA) — das sind rund 27 % Unterschied im Preisniveau; wer
Mississippi mit Kalifornien vergleicht, vergleicht ohne RPP zwei verschiedene Dinge.
Achtung: Die RPP bezieht sich auf die USA = 100, **nicht** auf internationale PPP.
Ein Ländervergleich „Land XY vs. US-Staat" braucht zusätzlich eine internationale
PPP-Umrechnung (Weltbank/OECD/IMF) — RPP und internationale PPP sind nicht dasselbe und
dürfen nicht multipliziert werden, ohne die Bezugsbasis explizit zu machen.
Letzter RPP-Jahrgang ist **2024**, das BIP pro Kopf ist **2025** — Jahresversatz bei
Kaufkraftbereinigung ausweisen.

**3.2 BIP pro Kopf ist berechnet, nicht abgelesen.**
BEA veröffentlicht in SAGDP1 „Real GDP", „Chain-type quantity index" und
„Current-dollar GDP" — eine fertige Zeile „nominales BIP pro Kopf" gibt es dort nicht.
Gerechnet wurde: `Current-dollar GDP (SAGDP1, LineCode 3, Mio. USD) × 1e6 / Bevölkerung
(SAINC1, LineCode 2, Personen)`, beide für 2025. Belegart `berechnet`.
2025 ist der jüngste Jahrgang (BEA-Release April 2026) und damit noch revisionsanfällig.
Wer stattdessen BEAs „per capita real GDP" nimmt, bekommt verkettete 2017er-Dollar —
andere Größe, nicht mischbar.

**3.3 Zwei Armutsbegriffe, die sich systematisch widersprechen.**
- `poverty_rate_official_acs` (2024, ACS, DP03): offizielle Armutsschwelle, Vorsteuer-Bar-
  einkommen, **keine** regionale Preisbereinigung, keine Sachleistungen.
- `poverty_rate_spm_3yr_avg` (Ø 2022–2024, CPS ASEC): Supplemental Poverty Measure —
  berücksichtigt Sachleistungen (SNAP, Wohngeld), Steuern/Gutschriften, Gesundheits- und
  Arbeitskosten **und** regionale Wohnkostenunterschiede.
Folge: Kalifornien sieht in der offiziellen Quote unauffällig aus (ACS 11,8 %) und in der
SPM dramatisch schlechter (17,7 %); Mississippi/Alabama umgekehrt. Beide Reihen NIE in
einer Grafik nebeneinander als „die Armutsquote" darstellen.
Die beiden Reihen sind zusätzlich **verschiedene Erhebungen** (ACS vs. CPS ASEC),
**verschiedene Zeiträume** (Einzeljahr 2024 vs. 3-Jahres-Schnitt 2022–2024) und
**verschiedene Fehlermargen**. Deshalb liegt `poverty_rate_officialplus_3yr_avg` aus
derselben CPS-Tabelle mit in der CSV: nur SPM gegen Official+ ist ein methodisch
zulässiger Vergleich.

**3.4 SPM-Werte sind vorläufig — Revision angekündigt.**
Census-Statement vom 17.07.2026: BLS hat nach entdeckten Kodierfehlern die SPM-Schwellen
2019–2024 neu veröffentlicht; Census will die SPM-Raten 2019–2024 neu ausweisen
(Working Paper vor dem September-Armutsbericht).
→ https://www.census.gov/newsroom/press-releases/2026/statement-on-supplemental-poverty-measure.html
Die hier abgelegten SPM-Werte stammen aus P60-287 (Sept. 2025) und sind damit der
**Stand vor der Revision**. Vor Veröffentlichung einer Grafik neu ziehen.
Belegart der Revisionslage: `abgelesen` (Census-Statement), Auswirkung auf Staatenwerte:
`nicht geprüft`.

**3.5 Mindestlohn: ein Wert pro Staat ist eine Vereinfachung.**
Quelle ist die DOL-Consolidated-Table mit Stand **01.07.2026** (also nicht „2026" als
Jahresmittel — Kalenderjahr-Sprünge z. B. in Florida zum 30.09.).
Regel für den eingetragenen Wert: **der allgemeine Satz für die größte Arbeitgebergruppe.**
Gestaffelte Staaten und was das bedeutet:
- New York: 16,00 USD (übriger Staat) eingetragen; 17,00 USD in NYC/Long Island/Westchester.
- New Jersey: 15,92 USD (Regelfall) eingetragen; 15,23 USD für Saison-/Kleinbetriebe.
- Oregon: 15,55 USD (Standard) eingetragen; 16,80 USD Portland-Metro, 14,55 USD nonurban.
- Ohio: 11,00 USD eingetragen; 7,25 USD für Kleinbetriebe unterhalb der Umsatzschwelle.
Wer eine Landkarte baut, muss sich für eine dieser Lesarten entscheiden und sie beschriften.

**3.6 „Kein eigener Mindestlohn" ist nicht dasselbe wie „7,25".**
`minimum_wage_status` trennt drei Fälle (Quelle: DOL „Minimum Wage Laws in the States"):
- `kein_eigener_landesmindestlohn` (5): Alabama, Louisiana, Mississippi, South Carolina,
  Tennessee — es gilt der Bundeswert 7,25 USD für FLSA-gedeckte Arbeitgeber.
- `landessatz_unter_bundeswert` (2): Georgia (5,15 USD) und Wyoming (5,15 USD) — faktisch
  gilt ebenfalls 7,25 USD, sobald FLSA greift.
- `eigener_landesmindestlohn`: alle übrigen, einschließlich der Staaten, die ihren eigenen
  Satz auf exakt 7,25 USD gesetzt haben (u. a. Idaho, Indiana, Iowa, Kansas, Kentucky,
  New Hampshire, North Carolina, North Dakota, Oklahoma, Pennsylvania, Texas, Utah,
  Wisconsin). Diese sind rechtlich etwas anderes als „kein Gesetz", auch wenn der Zahlwert
  identisch ist.
Nicht geprüft: Die DOL-Staatenseite nennt zusätzlich Sondersätze unterhalb des Bundeswerts
für nicht-FLSA-gedeckte Arbeitgeber (Montana 4,00 USD für Kleinstbetriebe, Oklahoma
2,00 USD für bestimmte Arbeitgeber). Diese Sonderfälle sind in der CSV **nicht** abgebildet.

**3.7 Erhebungsjahre sind nicht einheitlich.**
BIP 2025 · Einkommen und ACS-Armut 2024 · SPM Ø 2022–2024 · RPP 2024 · Mindestlohn
Stand 01.07.2026. Jede Grafik muss das Jahr an der Kennzahl tragen, nicht in der Fußzeile.

---

## 4. Definitionsfallen — Schulden und Defizit

**4.1 Gross debt vs. debt held by the public.**
- *Total public debt outstanding* (Bruttoschuld) enthält die Intragovernmental Holdings —
  Schulden des Bundes bei eigenen Treuhandfonds (v. a. Social Security). Ende FY2025:
  37,64 Bio. USD, davon 7,36 Bio. intragouvernemental.
- *Debt held by the public* (30,28 Bio. USD Ende FY2025) ist die ökonomisch relevante
  Größe für Marktbeanspruchung und die Kennzahl, auf die CBO seine Projektionen stellt.
Der Unterschied sind rund 24 Prozentpunkte BIP-Quote. Wer eine Zahl nennt, muss sagen welche.

**4.2 IMF „general government" ≠ US-Bundesebene.**
`general_government_gross_debt_pct_gdp` des IWF für die USA (123,9 % für 2025) umfasst
Bund **und** Bundesstaaten/Kommunen nach GFSM-2001-Abgrenzung. Die aus Treasury/BEA
gerechnete Bundes-Bruttoquote (123,96 %) liegt zufällig sehr nah daran — das ist
**keine** Bestätigung, sondern Zufall zweier verschiedener Abgrenzungen
(Bundesebene brutto vs. Gesamtstaat konsolidiert). Nicht als Gegenprobe verwenden.

**4.3 Maastricht-Schuldenstand ≠ IWF general government gross debt.**
Für die EU-Länder (DE, FR, IT, ES, DK, SE, FI, PL) veröffentlicht Eurostat den
Maastricht-Schuldenstand: konsolidiert, zu Nominalwert, nur Bargeld/Einlagen,
Schuldverschreibungen und Kredite. Die IWF-Größe `GGXWDG` ist brutto und enthält
zusätzlich u. a. „other accounts payable", Versicherungs-/Pensionsverpflichtungen.
Die Werte liegen deshalb je nach Land um wenige Prozentpunkte auseinander.
**Deshalb sind alle 13 Entities in `fiscal_debt_deficit.csv` aus derselben Quelle
(IWF DataMapper/WEO) und demselben Jahr (2025).** Eurostat-Werte dürfen nicht
einzeln dazugemischt werden.

**4.4 Fiskaljahr-Versatz.**
Das US-Bundesfiskaljahr läuft 01.10.–30.09. FY2025 = 01.10.2024–30.09.2025.
Alle IWF-Werte in dieser CSV sind **Kalenderjahr 2025**. Das US-Defizit von 5,85 % (FY2025,
Treasury/BEA) und die IWF-Angabe von −6,8 % (Kalenderjahr 2025, Gesamtstaat) sind daher
zwei verschiedene Größen über zwei verschiedene Zeiträume und zwei verschiedene
Staatsebenen. Nie als Korrektur voneinander lesen.

**4.5 Defizit-Vorzeichen.**
Der IWF-Indikator ist *net lending(+)/borrowing(−)*: negative Werte = Defizit,
positive = Überschuss (Norwegen +9,3 %, Dänemark +2,9 %, Schweiz +0,5 %).
Die Treasury-Zeile `federal_deficit_absolute` ist dagegen ein **positiver** Defizitbetrag.
Vorzeichenkonvention beim Plotten prüfen.

**4.6 Norwegen-Falle.**
Norwegens Überschuss und die niedrige Nettoposition stammen aus den Öl-/Fondseinnahmen
(Staatlicher Pensionsfonds Ausland). Die Brutto-Schuldenquote von 45,0 % sagt über die
norwegische Fiskallage praktisch nichts, solange das Fondsvermögen nicht gegengerechnet wird.
Für eine ehrliche Grafik gehört bei Norwegen ein Hinweis dazu.

**4.7 Russland: Datengüte.**
Die IWF-Werte für Russland (17,2 % Schuldenquote, −3,9 % Defizit für 2025) beruhen auf
nationalen Meldungen; die Belastbarkeit ist seit 2022 eingeschränkt. Belegart bleibt
`abgelesen` (der IWF sagt das so), aber die Datengüte ist `nicht geprüft`.

**4.8 WEO-Jahrgang.**
Der Abruf lief über den IMF-DataMapper am 2026-09-18. Die Projektionsreihe endet 2031,
was auf den WEO-Jahrgang April 2026 hindeutet — das ist `inferiert`, nicht abgelesen:
die DataMapper-API weist den Jahrgang nicht aus. Für eine Publikation den Jahrgang in der
WEO-Datenbank selbst bestätigen.

---

## 5. Belegpfad der Staatenwerte

- **BIP pro Kopf**: BEA-Bulkdateien `SAGDP.zip` / `SAINC.zip`, direkt heruntergeladen und
  lokal gerechnet. `berechnet`.
- **Median Household Income / ACS-Armutsquote**: Tabellen 1 und 2 des CRS-Berichts R48943,
  die ACS-Tabellen B19013 bzw. DP03 wiedergeben. Gegenprobe gegen die Census-Primärquelle
  ACSBR-025 („Household Income in States and Metropolitan Areas: 2024",
  https://www2.census.gov/library/publications/2025/demo/acsbr-025.pdf) für
  Massachusetts (104.828) und Mississippi (59.127) — **exakte Übereinstimmung**.
  Nicht geprüft: die übrigen 48 Staaten gegen die Primärquelle.
- **SPM / Official+**: Census-Originaldatei `spm_opm_state.xlsx` zu P60-287. `abgelesen`.
- **RPP**: BEA `SARPP.zip`, Tabelle SARPP LineCode 1 („RPPs: All items"). `abgelesen`.
- **Mindestlohn**: DOL Consolidated State Minimum Wage Table, über WebFetch gelesen
  (curl wird von dol.gov per Akamai geblockt). Der Seiteninhalt wurde in drei
  überlappenden Durchgängen abgefragt; die Sätze waren über die Durchgänge konsistent.
  Einschränkung: Die farbcodierte Spaltenzuordnung der DOL-Tabelle ist per Textabruf
  **nicht** zuverlässig lesbar — die Kategorien in `minimum_wage_status` stammen deshalb
  aus der separaten DOL-Seite „Minimum Wage Laws in the States".

---

## 6. Lücken und was nicht beschafft werden konnte

1. **Census-API ohne Schlüssel nicht nutzbar.** `api.census.gov` antwortet mit
   302 → `missing_key.html`. Es lag kein Census-API-Key vor. Deshalb der Umweg über
   CRS-/Census-Publikationstabellen. Für wiederkehrende Läufe: Key beantragen.
2. **CBO nicht abrufbar.** `cbo.gov` liefert für WebFetch und curl HTTP 403.
   Die CBO-Werte für FY2025 (Defizit % BIP, Schuld in Händen der Öffentlichkeit % BIP)
   konnten deshalb **nicht primär belegt** werden. Die in der CSV stehenden Quoten sind
   stattdessen aus Treasury-Ist-Daten und BEA-BIP selbst gerechnet (`berechnet`).
   Eine Suchergebnis-Zusammenfassung nannte 5,9 % bzw. 99,8 % — das ist
   `nicht geprüft` und steht bewusst nicht in der CSV; die selbst gerechneten
   5,85 % und 99,72 % liegen in derselben Größenordnung.
3. **ACS 2025 1-Jahres-Schätzungen liegen nicht vor.** Census hat den Termin wegen einer
   neuen Disclosure-Avoidance-Vorgabe des Handelsministeriums nicht terminiert
   (Stand 18.09.2026). Jüngster verfügbarer ACS-Jahrgang bleibt 2024.
4. **SPM-Revision** (siehe 3.4): Staatenwerte sind Stand vor der Neuberechnung.
5. **Internationale PPP-Umrechnung** wurde nicht beschafft — RPP allein reicht für einen
   Länder-vs.-Staat-Vergleich nicht (siehe 3.1).
6. **DOL-Sondersätze** unterhalb des Bundeswerts (MT, OK) nicht abgebildet (siehe 3.6).

---

## 7. Quellen (URLs)

- BEA Regional, SAGDP: https://apps.bea.gov/regional/zip/SAGDP.zip
- BEA Regional, SAINC: https://apps.bea.gov/regional/zip/SAINC.zip
- BEA Regional Price Parities: https://apps.bea.gov/regional/zip/SARPP.zip
- BEA NIPA quartalsweise (A191RC): https://apps.bea.gov/national/Release/TXT/NipaDataQ.txt
- CRS R48943, „Income and Poverty by State and Congressional District":
  https://www.congress.gov/crs_external_products/R/HTML/R48943.html
- Census ACSBR-025: https://www2.census.gov/library/publications/2025/demo/acsbr-025.pdf
- Census P60-287, Staatentabelle SPM/Official+:
  https://www2.census.gov/programs-surveys/demo/tables/p60/287/spm_opm_state.xlsx
- Census-Statement zur SPM-Revision:
  https://www.census.gov/newsroom/press-releases/2026/statement-on-supplemental-poverty-measure.html
- DOL WHD Consolidated State Minimum Wage Table: https://www.dol.gov/agencies/whd/mw-consolidated
- DOL WHD Minimum Wage Laws in the States: https://www.dol.gov/agencies/whd/minimum-wage/state
- U.S. Treasury Fiscal Data, Debt to the Penny:
  https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v2/accounting/od/debt_to_penny
- U.S. Treasury Fiscal Data, MTS Table 1:
  https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/mts/mts_table_1
- IMF DataMapper, GGXWDG_NGDP: https://www.imf.org/external/datamapper/api/v1/GGXWDG_NGDP
- IMF DataMapper, GGXCNL_NGDP: https://www.imf.org/external/datamapper/api/v1/GGXCNL_NGDP
