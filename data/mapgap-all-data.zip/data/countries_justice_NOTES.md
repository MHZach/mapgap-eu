# Länderwerte — Vergleichsbasis Gewalt / Justiz / Verkehr

Datei: `countries_justice.csv` (150 Zeilen, 11 Metriken × 12–16 Gebietseinheiten).
Erstellt am 2026-09-18. Gegenstück zu `us_states_justice.csv` / `us_states_justice_NOTES.md`.

Länder: Deutschland, Frankreich, Italien, Spanien, Schweiz, Vereinigtes Königreich, Dänemark,
Norwegen, Schweden, Finnland, Polen, Russland, USA (13).
Zusätzlich sind dort, wo die Quelle das UK nur dreigeteilt führt, auch die Einzelzeilen
„Vereinigtes Königreich (England und Wales) / (Schottland) / (Nordirland)" enthalten.

Spalte `belegart`:
- **abgelesen** — der Wert steht so in der Quelldatei.
- **berechnet** — aus abgelesenen Zähler-/Nennerwerten von mir gerechnet (Rechenweg steht in `source_name`).
Kein Wert wurde von mir geschätzt, inferiert oder aus dem Gedächtnis ergänzt.
**Achtung, das ist nicht dasselbe wie „alle Werte sind Messwerte":** zwei Reihen sind mit
`abgelesen` gekennzeichnet, weil der Wert so in der Quelle steht — der Quellwert selbst ist aber
ein Schätzwert. Das betrifft `traffic_deaths_rate_who_estimate` (WHO-Modellrechnung) und
`civilian_firearms_per_100` (Small Arms Survey, Experten-/Surveyschätzung; siehe D10).

---

## Übersicht je Kennzahl: gemeinsame Quelle, gemeinsames Jahr?

| Metrik im CSV | Quelle | Jahr | alle 13 aus einer Quelle? | alle 13 im selben Jahr? |
|---|---|---|---|---|
| `homicide_rate_who_mortality` | WHO Mortality Database (Rohdaten) | 2019 | **ja**, aber Russland mit abweichender Zählerabgrenzung (→ R1) | **ja** |
| `homicide_rate_unodc` | UNODC CTS | 2019 | **ja** | **ja** (UK berechnet) |
| `firearm_deaths_total` | WHO Mortality Database | 2019 | nein — **12/13, Russland fehlt** | ja |
| `firearm_deaths_suicide` | WHO Mortality Database | 2019 | nein — **12/13, Russland fehlt** | ja |
| `firearm_deaths_homicide` | WHO Mortality Database | 2019 | nein — **12/13, Russland fehlt** | ja |
| `incarceration_rate_prison_jail_total` | World Prison Brief, Trendtabelle | 2018 | **ja** | **ja** (UK berechnet) |
| `incarceration_rate_prison_jail_latest` | World Prison Brief, aktueller Stand | 2023–2026 | **12/13** — für das UK gesamt bewusst kein Wert (→ D8) | **NEIN — Stichtage 3,5 Jahre auseinander** |
| `traffic_deaths_rate` | ITF/OECD (gemeldete Zahlen) | 2019 | nein — **12/13, Russland fehlt** | ja |
| `traffic_deaths_rate_who_estimate` | WHO GHO RS_198 (modelliert) | 2021 | **ja** | **ja** |
| `transport_deaths_rate_who_mortality` | WHO Mortality Database | 2019 | **ja** | **ja** |
| `civilian_firearms_per_100` | Small Arms Survey | 2017 | **ja** | **ja** (UK berechnet) |

---

## Warum 2019 das Ankerjahr ist

Die WHO Mortality Database ist die einzige Quelle, die für alle 13 Länder
registrierungsbasierte Todesursachendaten in derselben Systematik führt. Ihre Abdeckung endet
je Land unterschiedlich. Bindende Restriktion ist **Russland: letzter verfügbarer Jahrgang 2019**.
Abdeckung je Land in `Morticd10_part5`/`part6` bzw. den Zusatzdateien (belegart: **abgelesen**,
Auswertung der Spalten Country/Year am 2026-09-18):
Russland 2017–2019 · Deutschland 2017–2020 in den Hauptdateien, 2021 ff. in `Germany.xlsx` ·
Norwegen 2013–2016 in den Hauptdateien, 2017–2024 in `Norway.xlsx` ·
Dänemark 2017–2022 · Frankreich, Italien, Schweiz, USA 2017–2023 ·
Finnland, Polen, Spanien, Schweden, UK 2017–2024.
2019 ist zugleich das letzte Vor-Corona-Jahr — das ist ein Vorteil, weil 2020/2021 bei
Verkehrstoten und Gefangenenzahlen (siehe D5) stark verzerrt sind.

Bei World Prison Brief wurde aus demselben Grund **2018** gewählt: es ist das jüngste Jahr, für
das die WPB-Trendtabelle alle 15 abgerufenen Jurisdiktionen führt (12 Länder + die drei
UK-Teilgebiete; die 16. CSV-Zeile „Vereinigtes Königreich" ist von mir berechnet), und es ist vor
dem Corona-Einbruch. Belegart: **abgelesen**, Parse der 15 Länderseiten am 2026-09-18.
Die Trendtabellen springen in Zweijahresschritten — 2019 gibt es dort für kein Land.

---

## Quellen und Rechenweg je Kennzahl

### 1. Tötungsdelikte, Todesursachenstatistik (`homicide_rate_who_mortality`)
Rohdateien `Morticd10_part5` (2017–2020) sowie `morticd10_add` → `Norway.xlsx` (Norwegen ab 2017),
Nenner `mort_pop`. Download: https://www.who.int/data/data-collection-tools/who-mortality-database
Zähler-Definition für 12 der 13 Länder **identisch zur CDC-Größe** im US-Staaten-CSV:
ICD-10 **X85–Y09 + Y87.1 + U01–U02**. Ausnahme Russland, siehe R1.
Rate = Todesfälle aller Altersgruppen (`Deaths1`) / Bevölkerung (`Pop1`) × 100.000 → **Rohrate**, nicht
altersstandardisiert.

**Validierung gegen die veröffentlichten NCHS-Werte.**
Zähler (belegart: **abgelesen** aus `Morticd10_part5`, USA 2019): Tötungsdelikte **19.141**,
Schusswaffentote gesamt **39.707**, davon Suizid **23.941**, davon Tötung **14.414**,
Gesamtsterbefälle **2.854.838**.
Nenner (belegart: **abgelesen**): **330.226.227** = Weltbank `SP.POP.TOTL`, USA 2019,
API-Abruf am 2026-09-18, Datenstand der Reihe laut API-Header `lastupdated: 2026-07-13`.
Die WHO-Populationsdatei führt die USA nur bis 2007, deshalb dieser Fremdnenner — für alle
übrigen zwölf Länder stammt der Nenner aus der WHO-Datei `mort_pop`.
Raten (belegart: **berechnet**): 5,80 · 12,02 · 7,25 · 4,36.
Die Zähler stimmen mit den von NCHS für 2019 publizierten Zahlen überein (Gesamtsterbefälle
2.854.838 ist der NCHS-Endstand). Dass damit **dieselbe Kausaldefinition** wie im US-Staaten-CSV
verwendet wird, ist daraus **inferiert**, nicht unabhängig belegt: der Zählerabgleich stützt es,
ein Abgleich der CDC-Definitionsdokumentation steht aus.

### 2. Tötungsdelikte, Polizeidaten (`homicide_rate_unodc`)
UNODC `data_cts_intentional_homicide.xlsx`, Dateistand 12.07.2026, Filter
Indicator = „Victims of intentional homicide", Dimension/Sex/Age = Total, Unit = „Rate per 100,000 population".
https://data.unodc.org/sites/dataportal.unodc.org/files/2026-07/data_cts_intentional_homicide.xlsx
Die alte URL `dataunodc.un.org/dp-intentional-homicide-victims` leitet per 302 auf das neue Portal um.

### 3. Schusswaffentote (`firearm_deaths_total` / `_suicide` / `_homicide`)
Gleiche WHO-Rohdaten, gleiche Methode wie 1.
- gesamt: **W32–W34, X72–X74, X93–X95, Y22–Y24, Y35.0, U01.4** (alle Intentionen — CDC-Definition)
- Suizid: X72–X74 · Tötung: X93–X95 + U01.4

### 4. Gefängnisinsassen (`incarceration_rate_prison_jail_total`, `_latest`)
World Prison Brief, Länderseiten, Feld „Prison population total (including pre-trial detainees /
remand prisoners)" bzw. Trendtabelle „Prison population trend".
Die Rate schließt Untersuchungshaft ein und ist damit die zu `incarceration_rate_prison_jail_total`
im US-Staaten-CSV (PPI-Gesamtrate) passende Größe.

### 5. Verkehrstote (`traffic_deaths_rate`)
ITF/OECD SDMX, Dataflow `OECD.ITF:DSD_INDICATORS@DF_SAFETY`, MEASURE=FATALITIES,
UNIT_MEASURE=10P5HB („per 100 000 inhabitants"), TRANSPORT_MODE=ROAD.
https://sdmx.oecd.org/public/rest/data/OECD.ITF,DSD_INDICATORS@DF_SAFETY,/all?format=csvfilewithlabels
National gemeldete Straßenverkehrstote, 30-Tage-Definition. Dass dies die zum IIHS/FARS-Wert des
US-Staaten-CSV passende Größe ist, ist **inferiert** (beides Polizei-/Unfallmeldedaten je Einwohner);
ein Abgleich der FARS-Definitionsdokumentation steht aus. Nachweislich gleich sind beide nicht:
ITF führt die USA 2019 mit 11,01, IIHS/FARS-Median der Bundesstaaten 2024 ist 11,95 — unterschiedliche
Jahre, unterschiedliche Ebenen (→ D7).

### 6. Verkehrstote, WHO-Schätzung (`traffic_deaths_rate_who_estimate`)
WHO GHO Indikator `RS_198`, https://ghoapi.azureedge.net/api/RS_198 — Grundlage: WHO Global Status
Report on Road Safety 2023. Enthält **nur das Jahr 2021**, kein Alternativjahr. Rohrate.
Nur diese Reihe deckt Russland ab.

### 7. Transportunfälle, Todesursachenstatistik (`transport_deaths_rate_who_mortality`)
Gleiche WHO-Rohdaten wie 1., ICD-10 **V01–V99**. Mitgeliefert, weil dies die einzige
Verkehrstoten-Größe ist, die für alle 13 Länder aus **derselben Quelle und demselben Jahr wie die
Tötungsdelikte** stammt. **Nicht** dasselbe wie 5. — siehe D4.

### 8. Schusswaffen in Privatbesitz (`civilian_firearms_per_100`)
Small Arms Survey, Annex „Civilian Firearms Holdings, 2017" zum Briefing Paper „Estimating Global
Civilian-held Firearms Numbers" (Aaron Karp, Juni 2018), Spalte „Estimate of civilian firearms per
100 persons". https://www.smallarmssurvey.org/sites/default/files/resources/SAS-BP-Civilian-held-firearms-annexe.pdf
Achtung: die häufig zitierte URL `SAS-BP-Civilian-Firearms-Numbers.pdf` ist das Briefing Paper und
enthält nur Top-25-Tabellen; die Länderliste steht ausschließlich im Annex oben.

---

## Definitionsfallen

**D1 — Todesursachenstatistik und Polizeistatistik gehen in Europa und in den USA in
ENTGEGENGESETZTE Richtungen auseinander.**
In zehn der zwölf europäischen Länder liegt die UNODC-Polizeirate ÜBER der WHO-Sterbeurkundenrate
(Deutschland 0,75 vs. 0,39; Frankreich 1,15 vs. 0,64; UK 1,16 vs. 0,46; Finnland 1,47 vs. 1,12).
In den USA ist es umgekehrt: UNODC 4,93 vs. WHO 5,80.
Das heißt: Ein Vergleich „FBI-USA gegen Polizei-Europa" und ein Vergleich „CDC-USA gegen
Sterbeurkunden-Europa" liefern **unterschiedliche Abstände**. Weil die US-Staatenwerte CDC-Daten
sind, ist `homicide_rate_who_mortality` die passende Zeile. `homicide_rate_unodc` ist als
Kontrollgröße mitgeliefert — **die beiden Zeilen dürfen nicht in einer Grafik gemischt werden.**

**D2 — Rohrate, nicht altersstandardisiert.**
Alle WHO-Zeilen sind Rohraten (Todesfälle / Gesamtbevölkerung), passend zu den CDC-Rohraten der
US-Staaten. Die bekannten WHO-GHO-Reihen `VIOLENCE_HOMICIDERATE` und `SDGROADAGE` sind **modellierte
bzw. altersstandardisierte** Größen und liefern andere Zahlen. Gegenprobe (belegart: **abgelesen**,
API-Abruf 2026-09-18, https://ghoapi.azureedge.net/api/VIOLENCE_HOMICIDERATE): Deutschland 2019
steht dort mit **0,9 [0,8–1,1]** — gegen 0,39 in der WHO-Rohdatenrechnung und 0,75 bei UNODC.
Drei Quellen, drei Größenordnungen für dasselbe Land und dasselbe Jahr. Nicht mischen.

**D3 — „Schusswaffentote" heißt überwiegend Suizid.**
In jedem der 12 Länder mit Aufteilung liegt die Schusswaffen-Suizidrate über der
Schusswaffen-Tötungsrate, in den USA um das 1,7-fache (7,25 vs. 4,36). In der Schweiz (2,13 vs. 0,13)
und Finnland (2,10 vs. 0,24) ist der Abstand rechnerisch mehr als achtfach — **dieser Faktor ist
keine belastbare Aussage**, weil sein Nenner auf 11 bzw. 13 Todesfällen beruht (→ D9); er gehört
nicht in eine Grafik. Wer nur `firearm_deaths_total` zeigt,
zeigt in Europa fast ausschließlich Suizide. `suicide + homicide` ergibt NICHT die Gesamtzahl —
Unfall, polizeiliche Gewaltanwendung und unbestimmte Intention fehlen in der Summe (gleiche Lage
wie F3 im US-Staaten-Dokument).

**D4 — Verkehrstote: drei verschiedene Größen, drei verschiedene Zahlen.**
Für Polen 2019: ITF (Polizei, 30-Tage) **7,66** · WHO-Modellschätzung 2021 **6,5** ·
Sterbeurkunden V01–V99 2019 **9,95**. Die Sterbeurkundenreihe enthält auch Schiffs- und
Flugunfälle sowie die Sammelpositionen V98/V99 („sonstiger / nicht näher bezeichneter
Transportunfall"). Der Block V90–V99 (Wasser-, Luft- und sonstige/nicht näher bezeichnete Transportunfälle) umfasst
in Polen **654** und in Deutschland **599** Fälle — belegart: **berechnet**, aus den abgelesenen
Zählern V01–V99 (Polen 3.776, Deutschland 3.373) minus V01–V89 (Polen 3.122, Deutschland 2.774);
Nenner wie in Abschnitt 1. Bei Polen entspricht das 1,72 Punkten der Rate von 9,95. Die US-Staatenwerte stammen aus IIHS/FARS,
also Polizeidaten → **`traffic_deaths_rate` (ITF) ist die passende Zeile**, mit der Russland-Lücke.

**D5 — 2020 als Vergleichsjahr für Gefangenenzahlen ist unbrauchbar.**
Die US-Gefangenenrate fällt bei WPB von **642** (2018) auf **505** (2020), absolut von 2.102.400 auf
1.674.200 — ein Corona-Effekt in den local jails, der in Europa keine Entsprechung hat
(Deutschland 77 → 72). Belegart: **abgelesen**, WPB-Trendtabelle
https://www.prisonstudies.org/country/united-states-america bzw. `/germany`, Abruf 2026-09-18.
Deshalb steht **2018** im CSV.
Ein Direktvergleich mit dem US-Staaten-CSV ist nur eingeschränkt möglich: dort steht der **Median
über 50 Staaten** (608, PPI-Mischvintage 2019–2024), hier eine **Landesrate**. Median über Staaten
und bevölkerungsgewichtete Landesrate sind zwei Ebenen und dürfen nicht als derselbe Wert gelesen
werden. Ein PPI-US-Gesamtwert liegt mir nicht vor — **nicht geprüft**.

**D6 — Die Jahre sind über die Kennzahlen hinweg nicht einheitlich.**
WHO 2019 · UNODC 2019 · WPB 2018 · ITF 2019 · WHO-Verkehrsschätzung 2021 · Small Arms Survey 2017.
Eine Grafik darf über alle Kennzahlen hinweg keinen einheitlichen Stand behaupten.

**D7 — Die US-Staatenwerte sind 2023/2024, die Länderwerte 2017–2021. Zwei Brüche auf einmal.**
Das ist die größte Schwachstelle der ganzen Serie, und sie hat zwei getrennte Ursachen.

*Bruch 1, das Jahr.* `us_states_justice.csv` führt CDC 2024, IIHS/FARS 2024, BJS 2023 und einen
PPI-Mischvintage 2019–2024 (US-NOTES F7/F9). Das CSV hier führt WHO/UNODC/ITF 2019, WPB 2018,
WHO-Verkehrsschätzung 2021, Small Arms Survey 2017. Der Versatz ist je Kennzahl ein anderer:
Tötungsdelikte und Schusswaffentote 5 Jahre · Verkehrstote 5 Jahre · Haft 6 Jahre gegen einen
Mischvintage · Waffenbesitz im US-CSV gar nicht enthalten.

*Bruch 2, die Ebene.* Die US-Datei liefert **Einzelstaaten**; die daraus in den US-NOTES gebildeten
Werte 5,35 · 14,6 · 608 · 11,95 sind **ungewichtete Mediane über 50 Staaten** (dort ausdrücklich
als `berechnet` gekennzeichnet), nicht die US-Landesrate. Die Werte in diesem CSV sind dagegen
Landesraten. Ein Satz wie „die USA liegen bei 5,8, der Staaten-Median bei 5,35" stellt zwei
verschiedene Größen nebeneinander und ist keine Zeitreihenaussage.

Für die Grafikserie ist das unkritisch, solange jedes Land gegen **einzelne** Bundesstaaten gestellt
wird — das ist ja der Zweck. Kritisch wird es, sobald jemand „USA" als Balken neben die Länder
setzt oder den Staaten-Median als „die USA" bezeichnet.

Konsequenz: Entweder die US-Staatenwerte auf 2019 zurückziehen (der CDC-Datensatz enthält 2019),
oder den Jahresversatz je Kennzahl in der Grafik ausweisen. **Nicht stillschweigend gleichsetzen.**

**D8 — Das Vereinigte Königreich existiert in drei von fünf Quellen nicht als Einheit.**
UNODC, World Prison Brief und Small Arms Survey führen ausschließlich England & Wales, Schottland
und Nordirland getrennt (`prisonstudies.org/country/united-kingdom` antwortet mit HTTP 404, geprüft
2026-09-18). Die WHO Mortality Database und ITF führen das UK dagegen als Ganzes.
Im CSV stehen deshalb für `homicide_rate_unodc`, `incarceration_rate_prison_jail_total` und
`civilian_firearms_per_100` **beides**: die drei Einzelzeilen (`abgelesen`) und eine UK-Gesamtzeile
(`berechnet`, Rechenweg in `source_name`).
**Ausnahme `incarceration_rate_prison_jail_latest`: dort gibt es bewusst KEINE UK-Gesamtzeile.**
Die drei Stichtage liegen hier fünf Wochen auseinander (E&W 24.08.2026, Schottland 31.07.2026,
Nordirland 28.08.2026); eine Summe daraus wäre ein Zählstand, den es an keinem Tag gab. Das ist
eine ausgewiesene Lücke, kein vergessener Wert.
Vorbehalt auch zur berechneten UNODC-UK-Zeile: England & Wales zählt nach dem Homicide Index,
Schottland und Nordirland nach eigenen nationalen Regeln. Die Summe ist arithmetisch korrekt, aber
keine einheitlich definierte Größe. Die Spreizung innerhalb des UK ist
erheblich — Haftrate 2018: E&W 140, Schottland 140, Nordirland 81; Waffenbesitz: Nordirland 11,0
gegen England & Wales 4,6.

**D9 — Kleine Fallzahlen.**
Bei den Schusswaffen-Tötungen beruhen mehrere Länderwerte auf sehr wenigen Fällen — absolute
Todesfälle 2019, belegart: **abgelesen** aus `Morticd10_part5` bzw. `Norway.xlsx` (im CSV stehen
nur die Raten): Norwegen 3, Dänemark 9, Polen 9, Schweiz 11, Finnland 13, UK 19, Deutschland 40,
Schweden 45, Spanien 52, Italien 87, Frankreich 139. Diese Werte schwanken von Jahr zu Jahr um ein
Vielfaches und taugen nicht für eine Rangaussage („sicherstes Land").

**D10 — Small Arms Survey zählt Waffen, nicht Besitzer, und schätzt.**
Für Russland und die Schweiz beruht der Wert auf reiner Expertenschätzung (Methode 2 im Annex), der
Anteil nicht registrierter Waffen liegt dort bei 62,5 % (Russland: 11.020.000 von 17.620.000) bzw.
66,0 % (Schweiz: 1.540.281 von 2.332.000) — belegart: **berechnet** aus den abgelesenen
Annex-Spalten „Registered firearms" / „Unregistered firearms". Stand 2017; eine neuere Ausgabe
existiert nicht (die SAS-Datenbankseite führt weiterhin die Juni-2018-Papiere als aktuell).

---

## Russland — Vorbehalte

**R1 — Todesursachenstatistik nur bis 2019, und nur in der Kurzliste.**
Russland meldet an die WHO nur die aggregierte Kurzliste 101, nicht die Detailliste 104. Der
Tötungsdelikt-Wert stammt aus Position **1102 = Assault, X85–Y09** — ohne Y87.1 (Spätfolgen), die bei
den anderen Ländern enthalten sind. Y87.1-Fälle 2019 (belegart: **abgelesen** aus
`Morticd10_part5`): USA 203, UK 5, Frankreich 2, Deutschland 2 — in allen übrigen Ländern null.
Der Effekt ist in Europa damit vernachlässigbar (< 0,01 je 100.000) und beträgt in den USA
203 von 19.141 Tötungsdelikten = 1,1 % (belegart: **berechnet**). Russlands Zähler ist also um
höchstens diese Größenordnung enger als der der übrigen Länder.
Russland-Zähler 2019: **7.302** Tötungsdelikte (Position 1102), Nenner 146.764.655 → 4,98.
Letzter Jahrgang: **2019**. Werte ab 2022 gibt es in dieser Quelle nicht — die im Auftrag genannte
Kriegs-Problematik greift hier faktisch nicht, weil es gar keine Nachkriegsjahre gibt.

**R2 — Schusswaffentote: LÜCKE, nicht geschätzt.**
Die Kurzliste 101 kennt keine Tatmittel-Aufteilung. Für Russland gibt es in dieser Quelle **keinen**
Schusswaffenwert, weder gesamt noch nach Intention. Nicht ersetzt, nicht approximiert.

**R3 — Verkehrstote: LÜCKE bei ITF.**
Die ITF/OECD-Datenbank enthält `REF_AREA = RUS` in keinem einzigen Jahr (1994–2025 geprüft;
enthalten sind u. a. ARM, AZE, GEO, KAZ, MDA, UKR, UZB). Im ITF Road Safety Annual Report 2023
kommt „Russia" nicht vor. Der einzige Russland-Wert ist die **modellierte** WHO-Schätzung 10,6 für
2021 — eine Schätzung, keine russische Polizeistatistik. Nicht geprüft: ältere IRTAD-Berichte
2019–2022, deren PDFs über itf-oecd.org hinter einer Cloudflare-Sperre (HTTP 403) liegen; dort
könnte Russland als früheres IRTAD-Mitglied noch geführt sein.

**R4 — Gefangenenrate: Bruch in der Reihe, Ursache nicht belegt.**
WPB-Trend (belegart: **abgelesen**, https://www.prisonstudies.org/country/russian-federation,
Abruf 2026-09-18): 448 bei 646.085 Gefangenen (2016) → 416 / 602.176 (2018) → 363 / 523.928 (2020)
→ 322 / 465.896 (2022) → aktuell **197** (Mai 2026, 282.000 Gefangene bei einer WPB-seitig
angesetzten Bevölkerung von 143,5 Mio.). Die absolute Zahl
hat sich seit 2022 fast halbiert. **Nicht geprüft / nicht belegbar:** ob das real ist oder aus
Rekrutierung von Gefangenen für den Krieg, geänderter FSIN-Veröffentlichungspraxis oder einer
geänderten Bezugsbevölkerung folgt. Die WPB-Länderseite enthält dazu **keine** Fußnote (Volltext
geprüft 2026-09-18). Deshalb steht im CSV als Hauptwert der Jahrgang **2018 (416)**; der aktuelle
Wert steht separat unter `incarceration_rate_prison_jail_latest`.

**R5 — UNODC-Reihe ab 2022 auffällig.**
UNODC führt Russland 2021: 6,77 · 2022: 6,43 · 2023: 6,05 · 2024: 7,82 (belegart: **abgelesen**
aus `data_cts_intentional_homicide.xlsx`). Der Sprung 2023→2024 beträgt +29 % (belegart:
**berechnet**) und ist in der Quelle nicht erklärt. Die Reihe beruht auf NSO-Meldungen mit UNODC-Revisionen (GSH 2019 + GSH 2023). Im CSV steht
der Jahrgang 2019 (7,64); die Jahre ab 2022 sind bewusst nicht übernommen.

**R6 — Nenner.**
Die WHO-Populationsdatei führt Russland 2019 mit 146.764.655 (einschließlich der Krim), die
Weltbank mit 145.453.291. Im CSV steht die WHO-Zahl, weil sie zum Zählerbestand derselben Datei
gehört. Mit dem Weltbank-Nenner läge die Tötungsrate bei 5,02 statt 4,98 — der Unterschied ist für
die Grafik ohne Belang, muss aber bei Nachrechnungen bekannt sein.

---

## Weitere Lücken (nicht geschätzt, nicht ersetzt)

**L1 — Keine gemeinsame Quelle für gemeldete Verkehrstote aller 13.**
ITF deckt 12 ab (ohne Russland), WHO-RS_198 alle 13, aber modelliert. Ein Mischen beider Reihen wäre
ein Methodenbruch. In den drei geprüften Fällen liegt die WHO-Schätzung über der Meldezahl
**desselben Jahres 2021** (belegart: **abgelesen**, ITF 2021 gegen WHO RS_198 2021):
USA 12,93 → 14,2 · Polen 6,07 → 6,5 · Deutschland 3,08 → 3,3.
**Wichtig:** Diese drei ITF-Werte sind 2021er Werte und stehen NICHT im CSV — dort steht die
ITF-Reihe für 2019 (USA 11,01 · Polen 7,66 · Deutschland 3,67). Ob der Aufschlag über alle zwölf
ITF-Länder hinweg gilt, ist **nicht geprüft**. Beide Reihen stehen getrennt im CSV.

**L2 — Norwegen und Deutschland nur über Zusatzdateien.**
In den regulären WHO-Rohdateien `Morticd10_part5/part6` fehlt Norwegen ab 2017 vollständig und
Deutschland ab 2021. Beide sind in `morticd10_add.zip` als `Norway.xlsx` / `Germany.xlsx` enthalten
(Norwegen 2017–2024, Deutschland 2021+). Wer nur die Hauptdateien lädt, hält Norwegen
fälschlich für eine Datenlücke. Norwegen meldet ab 2017 in einem Sonder-Altersformat und hat sehr
kleine Zellen aggregiert; die hier verwendete Spalte `Deaths1` (alle Altersgruppen) ist davon nicht
betroffen.

**L3 — Finnland kann Y35.0 nicht isolieren.**
Finnland meldet dreistellige ICD-Codes; `Y35` (polizeiliche Gewaltanwendung) lässt sich nicht in
`Y35.0` (mit Schusswaffe) und den Rest zerlegen. Betroffen: 1 Todesfall 2019, der bei Finnland
in `firearm_deaths_total` fehlt. Effekt auf die Rate: < 0,02.

**L4 — UNODC weist den Herkunftstyp CJ/PH nicht mehr aus.**
Die frühere dataUNODC-Kennzeichnung „CJ = criminal justice / PH = public health" existiert in der
Juli-2026-Datei nicht mehr; stattdessen steht ein Institutionsfeld (CTS, NP, MoI, NSO, NCCP,
Eurostat, SDG, GSH-Revisionen). Für keines der 13 Länder erscheint 2019 ein WHO- oder
Mortality-Data-Code — die Werte sind damit polizei-/justizseitig, das ist aber **inferiert**,
nicht von UNODC ausgewiesen.

**L4a — Die Ableitung ist nicht als Skript im Repo.**
Die WHO-Rohdaten (rund 150 MB entpackt), die UNODC-XLSX, die 15 WPB-HTML-Seiten, die
ITF-SDMX-CSV und das SAS-Annex-PDF wurden in ein Sitzungs-Scratchpad geladen und dort
ausgewertet; im Repo liegen nur `countries_justice.csv` und diese Datei. Wer die Zahlen
nachrechnen will, braucht die in „Quellen und Rechenweg je Kennzahl" genannten URLs und die dort
angegebenen Filter — das reicht für eine vollständige Rekonstruktion, ist aber keine
Ein-Klick-Reproduktion.

**L5 — Keine Konfidenzintervalle.**
WHO-Rohdaten, UNODC, WPB, ITF und Small Arms Survey liefern in diesen Tabellen keine
Unsicherheitsangaben. Auch WHO-RS_198 hat die Felder `Low`/`High` durchgängig leer.

**L6 — Small Arms Survey: kein Update seit 2017.**
Nicht geprüft: ob es unveröffentlichte oder interne Aktualisierungen gibt. Die öffentliche
Datenbankseite führt seit Juni 2018 unverändert denselben Stand.
