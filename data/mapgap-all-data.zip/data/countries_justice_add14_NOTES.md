# Ergaenzung 14 Laender — Gewalt / Justiz / Verkehr

Datei: `countries_justice_add14.csv` (119 Datenzeilen + Kopfzeile = 120 Zeilen).
Erstellt am 2026-09-18. **Der Bestand `countries_justice.csv` wurde nicht angefasst.**
Ueberschneidung der Laendermengen: keine (geprueft, leere Schnittmenge).

Laender (14, ASCII): Portugal · Niederlande · Belgien · Oesterreich · Ungarn · Irland ·
Tschechien · Lettland · Litauen · Estland · Kroatien · Griechenland · Bosnien · Israel.

Metrik-Namen, Einheiten, Quellen und Jahrgaenge sind identisch zum Bestand — je Kennzahl
gegen die Bestandszeilen abgeglichen (`unit` Feld-fuer-Feld verglichen, alle 9 Kennzahlen OK).
Die beiden Bestandsreihen `transport_deaths_rate_who_mortality` und
`traffic_deaths_rate_who_estimate` waren nicht Teil des Auftrags und fehlen hier bewusst.

## Vollstaendigkeit je Kennzahl

| Kennzahl | Quelle | Jahr | vorhanden | fehlt |
|---|---|---|---|---|
| `homicide_rate_who_mortality` | WHO Mortality DB, Rohdaten | 2019 | 13/14 | **Bosnien** (L1) |
| `homicide_rate_unodc` | UNODC CTS | 2019 | 13/14 | **Belgien** (L3) |
| `firearm_deaths_total` | WHO Mortality DB | 2019 | 13/14 | **Bosnien** (L1) |
| `firearm_deaths_suicide` | WHO Mortality DB | 2019 | 13/14 | **Bosnien** (L1) |
| `firearm_deaths_homicide` | WHO Mortality DB | 2019 | 13/14 | **Bosnien** (L1) |
| `incarceration_rate_prison_jail_total` | World Prison Brief | 2018 | 13/14 | **Bosnien** (L2) |
| `incarceration_rate_prison_jail_latest` | World Prison Brief | 2023-12-31 bis 2026-09 | 13/14 | **Bosnien** (L2) |
| `traffic_deaths_rate` | ITF/OECD | 2019 | **14/14** | — |
| `civilian_firearms_per_100` | Small Arms Survey | 2017 | **14/14** | — |

## Belegart

- **abgelesen** — Wert steht so in der Quelldatei (UNODC, WPB, ITF, Small Arms Survey).
- **berechnet** — WHO-Reihen: Zaehler und Nenner sind abgelesen, die Rate ist von mir gerechnet.
  Rechenweg und die abgelesenen Zaehler-/Nennerwerte stehen in jeder Zeile im Feld `source_name`.
- **Kein Wert ist geschaetzt, inferiert, angenommen oder aus dem Gedaechtnis ergaenzt.**
- Wie im Bestand gilt: `abgelesen` heisst nicht `Messwert`. `civilian_firearms_per_100` ist auch
  in der Quelle eine Experten-/Surveyschaetzung.

## Vorgehen (reproduzierbar)

1. WHO: `morticd10_part5.zip`, `mort_pop.zip`, `mort_country_codes.zip` von
   `https://cdn.who.int/media/docs/default-source/world-health-data-platform/mortality-raw-data/`
   am 2026-09-18 geladen (Dateistand der Rohdateien 22.02.2026). Filter `Year=2019`,
   Summe `Deaths1` (alle Altersgruppen) je ICD-10-Code; Nenner `Pop1` aus `pop`,
   ohne `Admin1`/`SubDiv`. Rohrate = Zaehler / Nenner x 100.000. Codeabgrenzung identisch
   zum Bestand (CDC-Definition).
2. Abdeckung 2019 vor der Rechnung geprueft, nicht angenommen: **alle 14 Laender** stehen mit
   dem Jahrgang 2019 in `Morticd10_part5` — auch Bosnien (4025) und Israel (3150).
   Damit war keine Zusatzdatei aus `morticd10_add` noetig.
3. UNODC, ITF, Small Arms Survey, World Prison Brief: dieselben URLs wie im Bestand,
   Abruf 2026-09-18.

---

## Luecken

### L1 — Bosnien, WHO-Mortalitaet: gemeldet, aber fuer externe Todesursachen unbrauchbar
Bosnien meldet fuer 2019 an die WHO (`Morticd10_part5`, Land 4025, 862 Zeilen, Sonderliste 103),
Gesamtsterbefaelle `AAA` = 38.829 — die Frage „meldet Bosnien ueberhaupt?" ist damit mit **ja**
beantwortet. Die externen Todesursachen sind aber praktisch nicht kodiert (alles abgelesen,
Auszaehlung am 2026-09-18):

- **V01–V99 (Transportunfaelle): 0 Faelle.** Kein einziger Verkehrstoter in der
  Todesursachenstatistik — das ist kein Befund, das ist ein Kodierungsausfall. Zum Vergleich:
  ITF weist fuer Bosnien 2019 eine Rate von 7,68 je 100.000 aus.
- **Y34 („nicht naeher bezeichnetes Ereignis, unbestimmte Absicht"): 918 Faelle** —
  99 % aller extern kodierten Faelle liegen in dieser Sammelposition.
- X85–Y09 + Y87.1 + U01–U02 (Toetungsdelikte): **1 Fall** (X92). Schusswaffen gesamt: 2 Faelle.
- Zusaetzlich R99 („unbekannte Todesursache") mit 4.966 Faellen = 12,8 % aller Sterbefaelle.

Eine Rate von 0,03 je 100.000 aus einem einzigen Fall waere eine Zahl ohne Aussage. Deshalb steht
fuer Bosnien **kein** WHO-Wert im CSV. UNODC fuehrt Bosnien 2019 dagegen mit 1,26 (Interpol/CTS/SDG) —
diese Zeile ist enthalten.

### L2 — Bosnien, World Prison Brief: keine Gesamtjurisdiktion
Geprueft am 2026-09-18 ueber die WPB-Europakarte: Es gibt genau **zwei** Laenderseiten,
`/country/bosnia-herzegovina-federation` und `/country/bosnia-herzegovina-republika-srpska`.
Eine Seite fuer Bosnien und Herzegowina als Ganzes existiert nicht, eine Seite fuer den
Brcko-Distrikt ebenfalls nicht.

- Republika Srpska, Trendtabelle 2018: 791 Gefangene, Rate **66**. (abgelesen)
- Foederation BiH, Trendtabelle: **kein 2018** — die Reihe endet 2014 (1.722 Gefangene, Rate 78). (abgelesen)

Eine Gesamtrate 2018 liesse sich also selbst mit Nenner nicht bilden, weil der Zaehler der
Foederation fuer 2018 fehlt. Und ohne belegten Gesamtnenner waere jede Mittelung der beiden
Raten ein selbst gebildeter Durchschnitt. **Es steht daher kein Bosnien-Wert im CSV, weder
fuer 2018 noch fuer `_latest`.** Zur Information, nicht im CSV, Stichtag 31.1.2025:
Foederation 1.108 Gefangene / Rate 52 · Republika Srpska 580 / Rate 48 — der Brcko-Distrikt
ist in keiner der beiden Zahlen enthalten.

### L3 — Belgien, UNODC: kein Jahrgang 2019
In `data_cts_intentional_homicide.xlsx` (Dateistand 12.07.2026) fuehrt Belgien beim Indikator
„Victims of intentional homicide", Dimension/Sex/Age = Total, **ausschliesslich das Jahr 2021**
(125 Faelle, Rate 1,08, Quelle MoI). Ein 2019er Wert existiert in der Datei nicht.
Keine Ersatzquelle eingesetzt — die Zeile fehlt. Die WHO-Reihe fuer Belgien 2019 ist vorhanden (0,83).

---

## Definitionsfallen

### D-A — Bosnien war die Erwartung, Bosnien ist die Ueberraschung
Die Vorab-Erwartung lautete: ITF fehlt (kein OECD-Mitglied), WPB fuehrt Bosnien, WHO unklar.
Geprueft ist es **genau umgekehrt**:
- **ITF: vorhanden** (REF_AREA=BIH, 7,68 je 100.000 fuer 2019). ITF-Mitgliedschaft ist nicht
  an OECD-Mitgliedschaft gebunden.
- **WPB: keine Gesamtjurisdiktion** (L2).
- **WHO: meldet, aber externe Ursachen unbrauchbar** (L1).

### D-B — Irland: die WHO-Toetungsrate ist wahrscheinlich untererfasst
Irland steht mit 0,26 (13 Faelle) und damit als niedrigster Wert der 14 Laender. UNODC fuehrt
Irland fuer dasselbe Jahr mit 0,63, also gut dem Zweieinhalbfachen. Die WHO-Zeitreihe fuer Irland
(abgelesen, `Morticd10_part5`): 2017 = 20 · 2018 = 22 · 2019 = 13 · 2020 = 8. Ein solcher Abfall
ist kein Kriminalitaetsverlauf, sondern ein Registrierungsartefakt: in Irland muessen Todesfaelle
mit gerichtsmedizinischer Klaerung vor der Registrierung durch ein Coroner-Verfahren, was den
Jahrgang der juengeren Jahre systematisch ausduennt. **Dass genau dies die Ursache ist, ist
inferiert, nicht belegt** — belegt sind nur die vier Jahreszahlen und die Differenz zu UNODC.
Irland sollte in keiner Rangliste als „sicherstes Land" gefuehrt werden, ohne dass diese
Einschraenkung danebensteht. Dieselbe Richtung, schwaecher, bei Portugal (WHO 0,87 vs. UNODC 0,71
— hier liegt WHO ausnahmsweise darueber).

### D-C — Kleine Fallzahlen bei `firearm_deaths_homicide`
Wie D9 im Bestandsdokument. Die Rate beruht in mehreren Laendern auf einstelligen Fallzahlen
(alle abgelesen, 2019): **Estland 1 Fall** · Litauen 2 · Irland 3 · Lettland 4 · Ungarn 5 ·
Oesterreich 12. Aus diesen Zeilen duerfen keine Verhaeltnisse („x-mal so hoch wie") gebildet
werden, und Estland gehoert nicht in eine Grafik dieser Kennzahl.

### D-D — Zwei Laender haben einen Fremdnenner
Die WHO-Populationsdatei `mort_pop` fuehrt fuer **Portugal** und **Estland** kein Jahr 2019
(Portugal endet 2018, Estland 2016; abgelesen). Fuer diese beiden ist der Nenner die
Weltbank-Reihe `SP.POP.TOTL` 2019 — Portugal 10.286.263, Estland 1.326.898 (abgelesen,
API-Abruf 2026-09-18, Datenstand laut API-Header `lastupdated: 2026-07-13`). Das ist dasselbe
Vorgehen, das im Bestand fuer die USA und Kanada dokumentiert ist. Fuer die uebrigen elf Laender
stammt der Nenner aus der WHO-Datei. Der Wechsel steht in jeder betroffenen Zeile im `source_name`.

### D-E — `incarceration_rate_prison_jail_latest` hat keinen gemeinsamen Stichtag
Die Stichtage der 13 Werte reichen vom **31.12.2023** (Israel) bis **September 2026**
(Portugal, Oesterreich, Estland) — rund 2,8 Jahre Spanne. Die Spalte `year` traegt deshalb je
Zeile den Stichtag, nicht ein Jahr. Diese Reihe darf nicht als Momentaufnahme dargestellt werden.
Zusammen mit dem Bestand (Stichtage bis zurueck zu 2023) ist die Spanne noch groesser.

### D-F — Portugals WPB-Nenner ist auffaellig
WPB rechnet die aktuelle portugiesische Rate (120) gegen „an estimated national population of
**11,45 million** at beginning of September 2026 (from Eurostat figures)" (abgelesen).
13.746 / 120 x 100.000 = 11,455 Mio., die Seite ist also in sich konsistent. Ob dieser Nenner
gegen die Eurostat-Bevoelkerungsreihe fuer Portugal stimmt, habe ich **nicht geprueft**.
Der Wert im CSV ist unveraendert der von WPB veroeffentlichte.

### D-G — Die Jahrgaenge sind uneinheitlich, wie im Bestand
WHO 2019 · UNODC 2019 · WPB 2018 · ITF 2019 · Small Arms Survey 2017 · WPB-`latest` 2023–2026.
Eine Grafik ueber mehrere Kennzahlen darf keinen einheitlichen Stand behaupten.
Es gilt unveraendert D1 des Bestandsdokuments: `homicide_rate_who_mortality` und
`homicide_rate_unodc` duerfen nicht in derselben Grafik gemischt werden. Zwoelf Laender haben
beide Werte. In **acht** liegt die UNODC-Polizeirate ueber der WHO-Sterbeurkundenrate
(Irland 0,63 vs. 0,26 · Litauen 3,36 vs. 2,22 · Oesterreich 0,87 vs. 0,52 · Tschechien 0,86 vs. 0,73 ·
Niederlande 0,71 vs. 0,62 · Israel 1,64 vs. 1,56 · Lettland 3,40 vs. 3,24 · Kroatien 0,83 vs. 0,81),
in **drei** darunter (Portugal 0,71 vs. 0,87 · Ungarn 0,67 vs. 0,82 · Griechenland 0,73 vs. 0,87),
in **einem** sind beide gleich (Estland 1,96). Die Richtung der Abweichung ist also nicht einheitlich —
welche der beiden Reihen man waehlt, veraendert die Rangfolge der Laender.
