# If country XY were a US state — Datenbasis

Stand: 2026-09-18. Alle Raenge beziehen sich auf die 50 Bundesstaaten; Washington D.C.
zaehlt nicht mit. Rang 1 = bester Wert, Rang 51 = schlechter als jeder Bundesstaat.

Die Spalte **Puffer** gibt an, um welchen Faktor sich der Landeswert verschlechtern
muesste, um den Rang zu verlieren. Ein grosser Puffer heisst: weder ein Jahresversatz
noch eine Datenrevision kippt diese Zeile.

## Bewusst nicht gerankt

| Kennzahl | Grund |
|---|---|
| Median-Haushaltseinkommen | OECD misst netto und aequivalenzgewichtet, der US-Census brutto je Haushalt. |
| Armutsquote | OECD ist relativ zum nationalen Median, die US-Quote ein Absolutmass. |
| HDI | Es gibt keinen HDI je US-Bundesstaat. |
| Muettersterblichkeit | Nur 39 Staaten publizieren eine Rate (NCHS unterdrueckt unter 20 Faellen). |
| Krankenversicherung | Laenderwerte 2020 gegen Staatenwerte 2024. |
| Mindesturlaub | Alle 50 Staaten bei null, der Rang traegt keine Information. |
| Loehne, jede Form | Durchschnitt fuehrt in die Irre (US-Median liegt UNTER dem deutschen), Medianlohn fehlt fuer 6 von 12 Laendern, und D9/D1 scheitert an 16 % gemessenem Methodenversatz plus Ebenenbruch: Deutschland enthaelt Muenchen bis Mecklenburg, Vermont nur Vermont. |

Diese drei gehoeren als Kontext unter die Tabelle, nicht als Rang hinein.

## Methodische Entscheidungen, die das Ergebnis tragen

1. **Adipositas nur Selbstauskunft gegen Selbstauskunft.** Die US-Staatenwerte stammen aus
   einer Telefonbefragung. Der OECD-Selbstauskunftswert der USA (34,2) trifft exakt den
   Median der 50 Staatenwerte — damit ist die Methodengleichheit belegt, nicht vermutet.
   Der gemessene WHO-Wert liegt rund 7 Punkte hoeher und darf hier nicht verwendet werden.
2. **Toetungsdelikte aus der Sterbeurkundenstatistik, nicht aus der Polizeistatistik.**
   Die US-Staatenwerte sind CDC-Daten. In Europa liegt die Polizeirate ueber der
   Sterbeurkundenrate, in den USA darunter — die beiden Reihen zu mischen verzerrt doppelt.
3. **Haftrate inklusive Untersuchungshaft.** Nur "state prison" halbiert die US-Werte
   (Median 299 statt 608) und macht den Vergleich wertlos.
4. **BIP/Kopf in zwei Zeilen.** Nominal zeigt Wechselkurs und Preisniveau mit;
   kaufkraftbereinigt wird der Staatenwert durch sein Preisniveau geteilt, wodurch beide
   Seiten in Dollar zu US-Durchschnittspreisen stehen.
5. **Adipositas nur bei passendem Erhebungsjahr.** Die Laenderreihe mischt Jahrgaenge;
   liegt das Landesjahr mehr als zwei Jahre von der US-Erhebung (2024) entfernt, faellt die
   Zeile fuer dieses Land weg statt fuer alle. Betrifft Frankreich, Polen und Russland.
6. **Elternzeit als Full-Rate-Equivalent.** Wochen ohne Lohnersatzrate zu vergleichen
   kehrt das Ergebnis um: 39 Wochen zu 30 Prozent sind weniger als 14 Wochen zu 100.



### Deutschland

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 80.7 | 1st | 2022 | 50/50 | 1.009x knapp |
| Saeuglingssterblichkeit | 3.2 | 3rd | 2023 | 50/50 | 1.025x knapp |
| Adipositas (Erwachsene) | 17.9 | 1st | 2025 | 50/50 | 1.40x |
| Toetungsdelikte | 0.39 | 1st | 2019 | 50/50 | 3.3x |
| Schusswaffentote gesamt | 0.96 | 1st | 2019 | 50/50 | 4.1x |
| Gefaengnisinsassen | 77 | 1st | 2018 | 50/50 | 3.1x |
| Verkehrstote | 3.7 | 1st | 2019 | 50/50 | 1.28x |
| BIP/Kopf nominal | $60,439 | 50th | 2025 | 50/50 | 1.082x knapp |
| BIP/Kopf kaufkraftbereinigt | $74,004 | 43rd | 2025 | 50/50 | 1.001x knapp |
| Mindestlohn | $15.96 | 7th | 2026-01-01 | 50/50 | 1.003x knapp |
| Mutterschutz (FRE-Wochen) | 14.0 | 1st | 2025 | 50/50 | 1.44x |
| Elternzeit gesamt (FRE-Wochen) | 38.2 | 1st | 2025 | 50/50 | 3.9x |

8 Kennzahlen auf Rang 1.


### Frankreich

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 82.3 | 1st | 2022 | 50/50 | 1.029x knapp |
| Saeuglingssterblichkeit | 4.0 | 6th | 2023 | 50/50 | 1.008x knapp |
| Toetungsdelikte | 0.64 | 1st | 2019 | 50/50 | 2.0x |
| Schusswaffentote gesamt | 2.27 | 1st | 2019 | 50/50 | 1.7x |
| Gefaengnisinsassen | 114 | 1st | 2018 | 50/50 | 2.1x |
| Verkehrstote | 4.8 | 2nd | 2019 | 50/50 | 1.060x knapp |
| BIP/Kopf nominal | $48,930 | 51st | 2025 | 50/50 | - |
| BIP/Kopf kaufkraftbereinigt | $66,276 | 50th | 2025 | 50/50 | 1.031x knapp |
| Mindestlohn | $13.80 | 21st | 2026-01-01 | 50/50 | 1.005x knapp |
| Mutterschutz (FRE-Wochen) | 16.0 | 1st | 2025 | 50/50 | 1.6x |
| Elternzeit gesamt (FRE-Wochen) | 19.6 | 1st | 2025 | 50/50 | 2.0x |

6 Kennzahlen auf Rang 1.

Jahresabstand zu gross: Adipositas (Erwachsene) (2019)


### Italien

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 82.8 | 1st | 2022 | 50/50 | 1.035x knapp |
| Saeuglingssterblichkeit | 2.5 | 1st | 2023 | 50/50 | 1.17x |
| Adipositas (Erwachsene) | 11.8 | 1st | 2024 | 50/50 | 2.1x |
| Toetungsdelikte | 0.43 | 1st | 2019 | 50/50 | 3.0x |
| Schusswaffentote gesamt | 0.93 | 1st | 2019 | 50/50 | 4.2x |
| Gefaengnisinsassen | 100 | 1st | 2018 | 50/50 | 2.4x |
| Verkehrstote | 5.3 | 3rd | 2019 | 50/50 | 1.036x knapp |
| BIP/Kopf nominal | $43,270 | 51st | 2025 | 50/50 | - |
| BIP/Kopf kaufkraftbereinigt | $63,538 | 51st | 2025 | 50/50 | - |
| Mindestlohn | kein_gesetzlicher_mindestlohn | n/a | 2026-01-01 | 50/50 | - |
| Mutterschutz (FRE-Wochen) | 17.4 | 1st | 2025 | 50/50 | 1.8x |
| Elternzeit gesamt (FRE-Wochen) | 31.7 | 1st | 2025 | 50/50 | 3.3x |

8 Kennzahlen auf Rang 1.


### Spanien

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 83.2 | 1st | 2022 | 50/50 | 1.040x knapp |
| Saeuglingssterblichkeit | 2.6 | 1st | 2023 | 50/50 | 1.13x |
| Adipositas (Erwachsene) | 14.7 | 1st | 2023 | 50/50 | 1.7x |
| Toetungsdelikte | 0.62 | 1st | 2019 | 50/50 | 2.1x |
| Schusswaffentote gesamt | 0.49 | 1st | 2019 | 50/50 | 8.0x |
| Gefaengnisinsassen | 128 | 1st | 2018 | 50/50 | 1.9x |
| Verkehrstote | 3.7 | 1st | 2019 | 50/50 | 1.26x |
| BIP/Kopf nominal | $38,290 | 51st | 2025 | 50/50 | - |
| BIP/Kopf kaufkraftbereinigt | $57,034 | 51st | 2025 | 50/50 | - |
| Mindestlohn | $9.91 | 30th | 2026-01-01 | 50/50 | 1.13x |
| Mutterschutz (FRE-Wochen) | 16.0 | 1st | 2025 | 50/50 | 1.6x |
| Elternzeit gesamt (FRE-Wochen) | 16.0 | 1st | 2025 | 50/50 | 1.6x |

9 Kennzahlen auf Rang 1.


### Schweiz

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 83.7 | 1st | 2022 | 50/50 | 1.046x knapp |
| Saeuglingssterblichkeit | 3.3 | 4th | 2023 | 50/50 | 1.12x |
| Adipositas (Erwachsene) | 12.1 | 1st | 2022 | 50/50 | 2.1x |
| Toetungsdelikte | 0.38 | 1st | 2019 | 50/50 | 3.4x |
| Schusswaffentote gesamt | 2.53 | 1st | 2019 | 50/50 | 1.5x |
| Gefaengnisinsassen | 82 | 1st | 2018 | 50/50 | 2.9x |
| Verkehrstote | 2.2 | 1st | 2019 | 50/50 | 2.2x |
| BIP/Kopf nominal | $115,620 | 2nd | 2025 | 50/50 | 1.009x knapp |
| BIP/Kopf kaufkraftbereinigt | $102,096 | 7th | 2025 | 50/50 | 1.027x knapp |
| Mindestlohn | kein_gesetzlicher_mindestlohn_national | n/a | 2026-01-01 | 50/50 | - |
| Mutterschutz (FRE-Wochen) | 8.1 | 5th | 2025 | 50/50 | 1.002x knapp |
| Elternzeit gesamt (FRE-Wochen) | 8.1 | 5th | 2025 | 50/50 | 1.002x knapp |

6 Kennzahlen auf Rang 1.


### Vereinigtes Königreich

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 80.9 | 1st | 2022 | 50/50 | 1.011x knapp |
| Saeuglingssterblichkeit | 4.2 | 8th | 2023 | 50/50 | 1.043x knapp |
| Adipositas (Erwachsene) | 30.0 | 9th | 2024 | 50/50 | 1.033x knapp |
| Toetungsdelikte | 0.46 | 1st | 2019 | 50/50 | 2.8x |
| Schusswaffentote gesamt | 0.15 | 1st | 2019 | 50/50 | 26.0x |
| Gefaengnisinsassen | 139 | 1st | 2018 | 50/50 | 1.7x |
| Verkehrstote | 2.7 | 1st | 2019 | 50/50 | 1.7x |
| BIP/Kopf nominal | $57,608 | 50th | 2025 | 50/50 | 1.031x knapp |
| BIP/Kopf kaufkraftbereinigt | $65,525 | 50th | 2025 | 50/50 | 1.020x knapp |
| Mindestlohn | $16.33 | 4th | 2026-01-01 | 50/50 | 1.021x knapp |
| Mutterschutz (FRE-Wochen) | 11.7 | 1st | 2025 | 50/50 | 1.20x |
| Elternzeit gesamt (FRE-Wochen) | 11.7 | 1st | 2025 | 50/50 | 1.20x |

7 Kennzahlen auf Rang 1.


### Dänemark

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 81.3 | 1st | 2022 | 50/50 | 1.016x knapp |
| Saeuglingssterblichkeit | 2.4 | 1st | 2023 | 50/50 | 1.22x |
| Adipositas (Erwachsene) | 18.7 | 1st | 2023 | 50/50 | 1.34x |
| Toetungsdelikte | 0.62 | 1st | 2019 | 50/50 | 2.1x |
| Schusswaffentote gesamt | 1.01 | 1st | 2019 | 50/50 | 3.9x |
| Gefaengnisinsassen | 65 | 1st | 2018 | 50/50 | 3.7x |
| Verkehrstote | 3.4 | 1st | 2019 | 50/50 | 1.37x |
| BIP/Kopf nominal | $77,046 | 35th | 2025 | 50/50 | 1.023x knapp |
| BIP/Kopf kaufkraftbereinigt | $86,094 | 23rd | 2025 | 50/50 | 1.004x knapp |
| Mindestlohn | kein_gesetzlicher_mindestlohn | n/a | 2026-01-01 | 50/50 | - |
| Mutterschutz (FRE-Wochen) | 10.9 | 1st | 2025 | 50/50 | 1.12x |
| Elternzeit gesamt (FRE-Wochen) | 20.4 | 1st | 2025 | 50/50 | 2.1x |

9 Kennzahlen auf Rang 1.


### Norwegen

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 82.5 | 1st | 2022 | 50/50 | 1.031x knapp |
| Saeuglingssterblichkeit | 2.1 | 1st | 2023 | 50/50 | 1.40x |
| Adipositas (Erwachsene) | 16.0 | 1st | 2025 | 50/50 | 1.6x |
| Toetungsdelikte | 0.50 | 1st | 2019 | 50/50 | 2.6x |
| Schusswaffentote gesamt | 1.50 | 1st | 2019 | 50/50 | 2.6x |
| Gefaengnisinsassen | 65 | 1st | 2018 | 50/50 | 3.7x |
| Verkehrstote | 2.0 | 1st | 2019 | 50/50 | 2.3x |
| BIP/Kopf nominal | $94,468 | 12th | 2025 | 50/50 | 1.017x knapp |
| BIP/Kopf kaufkraftbereinigt | $111,545 | 3rd | 2025 | 50/50 | 1.007x knapp |
| Mindestlohn | kein_gesetzlicher_mindestlohn | n/a | 2026-01-01 | 50/50 | - |
| Mutterschutz (FRE-Wochen) | 17.5 | 1st | 2025 | 50/50 | 1.8x |
| Elternzeit gesamt (FRE-Wochen) | 39.3 | 1st | 2025 | 50/50 | 4.0x |

9 Kennzahlen auf Rang 1.


### Schweden

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 83.1 | 1st | 2022 | 50/50 | 1.039x knapp |
| Saeuglingssterblichkeit | 2.1 | 1st | 2023 | 50/50 | 1.40x |
| Adipositas (Erwachsene) | 17.3 | 1st | 2025 | 50/50 | 1.45x |
| Toetungsdelikte | 1.05 | 1st | 2019 | 50/50 | 1.24x |
| Schusswaffentote gesamt | 1.42 | 1st | 2019 | 50/50 | 2.7x |
| Gefaengnisinsassen | 63 | 1st | 2018 | 50/50 | 3.8x |
| Verkehrstote | 2.1 | 1st | 2019 | 50/50 | 2.2x |
| BIP/Kopf nominal | $62,662 | 49th | 2025 | 50/50 | 1.013x knapp |
| BIP/Kopf kaufkraftbereinigt | $74,081 | 43rd | 2025 | 50/50 | 1.002x knapp |
| Mindestlohn | kein_gesetzlicher_mindestlohn | n/a | 2026-01-01 | 50/50 | - |
| Mutterschutz (FRE-Wochen) | 10.0 | 1st | 2025 | 50/50 | 1.030x knapp |
| Elternzeit gesamt (FRE-Wochen) | 34.4 | 1st | 2025 | 50/50 | 3.5x |

9 Kennzahlen auf Rang 1.


### Finnland

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 81.2 | 1st | 2022 | 50/50 | 1.015x knapp |
| Saeuglingssterblichkeit | 1.8 | 1st | 2023 | 50/50 | 1.6x |
| Adipositas (Erwachsene) | 26.0 | 2nd | 2024 | 50/50 | 1.038x knapp |
| Toetungsdelikte | 1.12 | 1st | 2019 | 50/50 | 1.16x |
| Schusswaffentote gesamt | 2.39 | 1st | 2019 | 50/50 | 1.6x |
| Gefaengnisinsassen | 53 | 1st | 2018 | 50/50 | 4.5x |
| Verkehrstote | 3.8 | 1st | 2019 | 50/50 | 1.23x |
| BIP/Kopf nominal | $56,464 | 50th | 2025 | 50/50 | 1.011x knapp |
| BIP/Kopf kaufkraftbereinigt | $66,297 | 50th | 2025 | 50/50 | 1.032x knapp |
| Mindestlohn | kein_gesetzlicher_mindestlohn | n/a | 2026-01-01 | 50/50 | - |
| Mutterschutz (FRE-Wochen) | 5.7 | 11th | 2025 | 50/50 | 1.018x knapp |
| Elternzeit gesamt (FRE-Wochen) | 39.7 | 1st | 2025 | 50/50 | 4.1x |

7 Kennzahlen auf Rang 1.


### Polen

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 77.2 | 27th | 2022 | 50/50 | 1.001x knapp |
| Saeuglingssterblichkeit | 3.9 | 6th | 2023 | 50/50 | 1.033x knapp |
| Toetungsdelikte | 0.66 | 1st | 2019 | 50/50 | 2.0x |
| Schusswaffentote gesamt | 0.27 | 1st | 2019 | 50/50 | 14.4x |
| Gefaengnisinsassen | 190 | 1st | 2018 | 50/50 | 1.27x |
| Verkehrstote | 7.7 | 6th | 2019 | 50/50 | 1.031x knapp |
| BIP/Kopf nominal | $28,374 | 51st | 2025 | 50/50 | - |
| BIP/Kopf kaufkraftbereinigt | $55,793 | 51st | 2025 | 50/50 | - |
| Mindestlohn | $8.27 | 31st | 2026-01-01 | 50/50 | 1.14x |
| Mutterschutz (FRE-Wochen) | 20.0 | 1st | 2025 | 50/50 | 2.1x |
| Elternzeit gesamt (FRE-Wochen) | 40.3 | 1st | 2025 | 50/50 | 4.2x |

5 Kennzahlen auf Rang 1.

Jahresabstand zu gross: Adipositas (Erwachsene) (2019)


### Russland

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 72.5 | 50th | 2022 | 50/50 | 1.004x knapp |
| Saeuglingssterblichkeit | 3.7 | 5th | 2023 | 50/50 | 1.038x knapp |
| Toetungsdelikte | 4.98 | 22nd | 2019 | 50/50 | 1.044x knapp |
| Gefaengnisinsassen | 416 | 13th | 2018 | 50/50 | 1.041x knapp |
| BIP/Kopf nominal | $17,972 | 51st | 2025 | 50/50 | - |
| BIP/Kopf kaufkraftbereinigt | $50,255 | 51st | 2025 | 50/50 | - |
| Mindestlohn | $1.86 | 51st | 2026-01-01 | 50/50 | - |
| Mutterschutz (FRE-Wochen) | nicht_in_quelle | n/a | 2025 | 50/50 | - |
| Elternzeit gesamt (FRE-Wochen) | nicht_in_quelle | n/a | 2025 | 50/50 | - |

0 Kennzahlen auf Rang 1.

Ohne Wert: Schusswaffentote gesamt, Verkehrstote

Jahresabstand zu gross: Adipositas (Erwachsene) (2019)


### Japan

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 84.1 | 1st | 2022 | 50/50 | 1.051x knapp |
| Saeuglingssterblichkeit | 1.8 | 1st | 2023 | 50/50 | 1.6x |
| Toetungsdelikte | 0.24 | 1st | 2019 | 50/50 | 5.4x |
| Schusswaffentote gesamt | 0.01 | 1st | 2019 | 50/50 | 390.0x |
| Gefaengnisinsassen | 40 | 1st | 2018 | 50/50 | 6.0x |
| Verkehrstote | 3.1 | 1st | 2019 | 50/50 | 1.5x |
| BIP/Kopf nominal | $35,973 | 51st | 2025 | 50/50 | - |
| BIP/Kopf kaufkraftbereinigt | $56,854 | 51st | 2025 | 50/50 | - |
| Mindestlohn | $7.20 | 51st | 2026-01-01 | 50/50 | - |
| Mutterschutz (FRE-Wochen) | 9.4 | 2nd | 2025 | 50/50 | 1.013x knapp |
| Elternzeit gesamt (FRE-Wochen) | 36.3 | 1st | 2025 | 50/50 | 3.7x |

7 Kennzahlen auf Rang 1.

Ohne Wert: Adipositas (Erwachsene)


### Kanada

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 81.3 | 1st | 2022 | 50/50 | 1.016x knapp |
| Saeuglingssterblichkeit | 4.6 | 12th | 2023 | 50/50 | 1.004x knapp |
| Adipositas (Erwachsene) | 24.0 | 1st | 2024 | 50/50 | 1.042x knapp |
| Toetungsdelikte | 1.43 | 2nd | 2019 | 50/50 | 1.26x |
| Schusswaffentote gesamt | 2.33 | 1st | 2019 | 50/50 | 1.7x |
| Gefaengnisinsassen | 108 | 1st | 2018 | 50/50 | 2.2x |
| Verkehrstote | 4.7 | 1st | 2019 | 50/50 | 1.085x knapp |
| BIP/Kopf nominal | $55,765 | 51st | 2025 | 50/50 | - |
| BIP/Kopf kaufkraftbereinigt | $67,013 | 50th | 2025 | 50/50 | 1.043x knapp |
| Mindestlohn | $11.98 | 25th | 2026-01-01 | 50/50 | 1.011x knapp |
| Mutterschutz (FRE-Wochen) | 5.8 | 11th | 2025 | 50/50 | 1.036x knapp |
| Elternzeit gesamt (FRE-Wochen) | 20.1 | 1st | 2025 | 50/50 | 2.1x |

6 Kennzahlen auf Rang 1.


### Australien

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 83.2 | 1st | 2022 | 50/50 | 1.040x knapp |
| Saeuglingssterblichkeit | 3.2 | 3rd | 2023 | 50/50 | 1.025x knapp |
| Adipositas (Erwachsene) | 25.4 | 2nd | 2022 | 50/50 | 1.063x knapp |
| Toetungsdelikte | 0.99 | 1st | 2019 | 50/50 | 1.31x |
| Schusswaffentote gesamt | 0.96 | 1st | 2019 | 50/50 | 4.1x |
| Gefaengnisinsassen | 172 | 1st | 2018 | 50/50 | 1.40x |
| Verkehrstote | 4.7 | 1st | 2019 | 50/50 | 1.085x knapp |
| BIP/Kopf nominal | $66,352 | 47th | 2025 | 50/50 | 1.010x knapp |
| BIP/Kopf kaufkraftbereinigt | $72,132 | 48th | 2025 | 50/50 | 1.031x knapp |
| Mindestlohn | $17.74 | 1st | 2026-01-01 | 50/50 | 1.036x knapp |
| Mutterschutz (FRE-Wochen) | 0.9 | 13th | 2025 | 50/50 | - |
| Elternzeit gesamt (FRE-Wochen) | 9.2 | 3rd | 2025 | 50/50 | 1.021x knapp |

6 Kennzahlen auf Rang 1.


### Suedkorea

| Kennzahl | Wert | Rang | Jahr | Basis | Puffer |
|---|---|---|---|---|---|
| Lebenserwartung | 82.7 | 1st | 2022 | 50/50 | 1.034x knapp |
| Saeuglingssterblichkeit | 2.5 | 1st | 2023 | 50/50 | 1.17x |
| Adipositas (Erwachsene) | 5.3 | 1st | 2025 | 50/50 | 4.7x |
| Toetungsdelikte | 0.79 | 1st | 2019 | 50/50 | 1.6x |
| Schusswaffentote gesamt | 0.02 | 1st | 2019 | 50/50 | 195.0x |
| Gefaengnisinsassen | 108 | 1st | 2018 | 50/50 | 2.2x |
| Verkehrstote | 6.5 | 4th | 2019 | 50/50 | 1.092x knapp |
| BIP/Kopf nominal | $36,227 | 51st | 2025 | 50/50 | - |
| BIP/Kopf kaufkraftbereinigt | $65,405 | 50th | 2025 | 50/50 | 1.018x knapp |
| Mindestlohn | $7.46 | 31st | 2026-01-01 | 50/50 | 1.029x knapp |
| Mutterschutz (FRE-Wochen) | 10.5 | 1st | 2025 | 50/50 | 1.081x knapp |
| Elternzeit gesamt (FRE-Wochen) | 47.6 | 1st | 2025 | 50/50 | 4.9x |

8 Kennzahlen auf Rang 1.
