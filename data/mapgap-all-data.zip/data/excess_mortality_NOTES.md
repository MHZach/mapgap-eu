# Uebersterblichkeit in der Corona-Zeit — Laender und US-Bundesstaaten

Stand: 2026-09-18. Neu angelegt, kein Bestand ueberschrieben.

Dateien:
- `excess_mortality_countries.csv` (284 Zeilen + Kopf)
- `excess_mortality_us_states.csv` (408 Zeilen + Kopf)

**Grundregel eingehalten:** gemessen wird ausschliesslich Uebersterblichkeit
(Todesfaelle ueber dem erwarteten Niveau). Bestaetigte Covid-Todesfaelle kommen in
keiner Zeile vor.

---

## 1. Was in den Dateien steht

### Laender (35 + USA als Pruefanker)

| metric | Quelle | Abdeckung |
|---|---|---|
| `excess_mortality_cumulative_per_100k_2020_2022` | OWID / The Economist Excess Mortality Model | 36/36 |
| `excess_mortality_cumulative_per_100k_2020` / `_2021` / `_2022` | dieselbe | 36/36 |
| `excess_mortality_pscore_2020_2022` | OWID `excess_mortality.csv` (HMD-STMF + WMD) | 35/36 — **Indien fehlt** |
| `excess_mortality_pscore_2020` / `_2021` / `_2022` | dieselbe | 35/36 |

Die USA sind zusaetzlich zu den 35 gefuehrt, weil sie der Pruefanker fuer (c) sind.

**Kennzahl 1 kommt fuer alle 36 Laender aus derselben Quelle** — die Vorgabe
„nicht mischen" ist damit fuer die rankbare Hauptkennzahl erfuellt.

**Kennzahl 2 (P-Score) kommt aus einer anderen Quelle**, weil die Economist-Datei
schlicht keinen P-Score fuehrt (sie fuehrt nur absolute und pro-100k-Werte, kein
erwartetes Niveau als Nenner). Die P-Score-Spalte ist also **nicht** dasselbe
Verfahren wie Kennzahl 1 und darf nicht als „dieselbe Zahl in anderer Einheit"
gelesen werden. Siehe Abschnitt 5 — der Unterschied betraegt bis zu 63 %.

### US-Bundesstaaten (50 + District of Columbia)

Beide metriken (`..._per_100k_...` und `..._pscore_...`) aus derselben Quelle:
CDC NCHS „Excess Deaths Associated with COVID-19", Socrata-Dataset `xkkf-xrst`.

Puerto Rico und die CDC-Zeile „United States" sind **nicht** in der Datei
(Vorgabe: 50 + DC).

---

## 2. (a) BASISLINIE — welches erwartete Niveau?

**Drei verschiedene Verfahren im Spiel. Das ist der groesste einzelne Hebel auf
die Ergebnisse.**

**Laender, Kennzahl 1 (Economist-Modell):**
Ein Gradient-Boosting-Modell (aGTBoost) auf rund 100 Kovariaten. Zielgroesse ist
`daily_excess_deaths_per_100k`. Wo ein Land gemessene Gesamtsterblichkeit meldet,
wird der gemessene Wert in den Export uebernommen statt der Modellvorhersage —
belegt im Exportskript `3_excess_deaths_global_estimates_export.R`, Zeilen um
„If we have a known value, use this where applicable"
(https://github.com/TheEconomist/covid-19-the-economist-global-excess-deaths-model/blob/main/scripts/3_excess_deaths_global_estimates_export.R).
Der dort eingehende gemessene Excess stammt aus dem Economist-eigenen
Excess-Deaths-Tracker, der eine eigene Baseline rechnet.
**Welche Basisjahre und ob Trend oder Mittelwert: NICHT GEPRUEFT.** Weder das
Repo-README noch die OWID-Seite nennen es; die Detailmethodik liegt hinter der
Economist-Paywall (https://www.economist.com/ExcessDeathsModel). Ich habe es nicht
gelesen und ergaenze es nicht aus dem Gedaechtnis.

**Laender, Kennzahl 2 (OWID / WMD-Projektion):**
**Trendfortschreibung, Basisjahre 2015–2019.** Woertlich aus der OWID-README:
die Baseline stammt vom World Mortality Dataset; OWID hat am 20.09.2021 bewusst
vom 5-Jahres-Mittel 2015–2019 auf die WMD-Projektion umgestellt, weil das
Mittel „does not account for year-to-year trends in mortality and thus can
misestimate excess mortality". Seit 18.01.2022 getrennte Projektionen fuer 2020,
2021, 2022, 2023.
Quelle: https://github.com/owid/covid-19-data/blob/master/public/data/excess_mortality/README.md

**US-Bundesstaaten (CDC):**
Feld `average_expected_count` des CDC-Datasets. **Das exakte Modell (Basisjahre,
Trend- und Saisonterme) habe ich in der Socrata-Metadatenbeschreibung nicht
gelesen — NICHT GEPRUEFT.** Was belegt ist: es ist eine wochengenaue
Erwartungsreihe, die auch fuer die Vor-Corona-Jahre ab 2017 ausgewiesen wird,
also trend- und saisonabhaengig, nicht ein flaches Mehrjahresmittel.
Quelle: https://data.cdc.gov/d/xkkf-xrst

**Warum das zaehlt:** fuer Laender mit alternder Bevoelkerung liegt eine
Trendfortschreibung ueber einem Mehrjahresmittel, die ausgewiesene
Uebersterblichkeit faellt also niedriger aus. Deutschland, Japan und Italien sind
die Faelle, bei denen das am staerksten durchschlaegt.

---

## 3. (b) ALTERSSTANDARDISIERUNG

**Keine der drei Quellen standardisiert nach Alter. Alle Werte in beiden Dateien
sind roh.** Das steht so auch in der Spalte `unit`.

- Economist: Zielgroesse ist `daily_excess_deaths_per_100k` auf die
  Gesamtbevoelkerung, keine Altersgewichtung im Modell-Export.
- OWID/WMD: P-Score „all ages" = gemeldete Tote / projizierte Tote. Die Datei
  fuehrt zwar Altersgruppen-P-Scores (0–14, 15–64, 65–74, 75–84, 85+), aber keine
  auf eine Standardbevoelkerung gewichtete Gesamtzahl. Ich habe die
  All-Ages-Reihe genommen.
- CDC: `observed_number` und `average_expected_count` sind rohe Wochenzaehlungen.

**Konsequenz, die man beim Ranking sehen muss:** eine alte Bevoelkerung erzeugt
ohne Alterskorrektur mehr Tote pro 100.000 — sowohl erwartet als auch ueberzaehlig.
Der Vergleich Japan (sehr alt) gegen Utah (sehr jung) ist deshalb kein Vergleich
der Pandemiebewaeltigung, sondern zu einem erheblichen Teil ein Vergleich der
Altersstruktur. Der P-Score daempft das teilweise (das erwartete Niveau steckt im
Nenner), der Per-100k-Wert gar nicht.

---

## 4. Rechenweg und Stichtage

**Laender, Kennzahl 1.** Die Economist-Datei fuehrt
`cumulative_estimated_daily_excess_deaths_per_100k`, kumuliert ab 01.01.2020, im
Wochenraster (Montage). Verwendete Stichtage: **2020-12-28, 2021-12-27,
2022-12-26**.
- `_2020_2022` = Stand 2022-12-26 → *abgelesen*.
- `_2020` = Stand 2020-12-28 → *abgelesen*.
- `_2021` = Stand 2021-12-27 minus Stand 2020-12-28 → *berechnet*.
- `_2022` = Stand 2022-12-26 minus Stand 2021-12-27 → *berechnet*.
Der Zeitraum endet also **5 Tage vor dem 31.12.2022**. Fuer das Ranking
irrelevant (alle Laender gleich behandelt), fuer den Versatzvergleich in (c)
mitzudenken.

**Laender, Kennzahl 2.** Aus `cum_excess_proj_all_ages` und
`cum_proj_deaths_all_ages` der OWID-Datei, jeweils letzter Stichtag im Jahr:
2020-12-27 / 2021-12-26 / 2022-12-25 (woechentliche Melder) bzw. 2020-12-31 /
2021-12-31 / 2022-12-31 (monatliche Melder: **Russland, Japan, Brasilien,
Serbien, Bosnien**).
P-Score Jahr y = (kumExcess[y] − kumExcess[y−1]) / (kumProj[y] − kumProj[y−1]) × 100.
Alle P-Score-Zeilen sind *berechnet*, nicht abgelesen.

**US-Bundesstaaten.** Socrata-Abruf mit `type='Predicted (weighted)'` (also die
um Meldeverzug korrigierte Reihe) und `outcome='All causes'`, Wochen mit
`week_ending_date` von **2020-01-04 bis 2022-12-31** (157 Wochen, 8.478 Zeilen,
keine Luecken).
Uebersterblichkeit = Σ `observed_number` − Σ `average_expected_count`.
**Nicht** das Feld `excess_estimate` verwendet: das ist bei Null abgeschnitten
(ein `$where=excess_estimate < 0`-Abruf liefert 0 Zeilen), was Wochen mit
Untersterblichkeit unterschlaegt und die Summe nach oben verzerrt.
Nenner: US Census Bureau, NST-EST2023-ALLDATA, `POPESTIMATE2020/2021/2022`; fuer
den Dreijahreswert das Mittel der drei Jahresstaende, fuer Jahreswerte der
jeweilige Jahresstand.
Alle Staaten-Zeilen sind *berechnet*.

---

## 5. (c) VERGLEICHBARKEIT DER BEIDEN SEITEN — der Pruefpunkt

Verfahren: USA in beiden Quellen nachschlagen und gegen das Aggregat der
CDC-Staatendaten stellen.

| Weg | Wert 2020–2022 |
|---|---|
| Laenderquelle Kennzahl 1 (Economist), USA | **390,6** je 100.000 |
| CDC, Summe 50 Staaten + DC, Census-Nenner (Mittel 2020–2022) | **384,9** je 100.000 |
| CDC-eigene Zeile „United States" (enthaelt Puerto Rico) | 394,9 je 100.000 |
| Laenderquelle Kennzahl 2 (OWID/WMD), USA | 375,9 je 100.000 |

**Versatz Economist ↔ CDC-Staaten-Aggregat: 384,9 gegen 390,6 = −1,5 %.**
(berechnet: (384,9 − 390,6) / 390,6)

Gegenprobe auf der P-Score-Ebene, wo der Bevoelkerungsnenner herausfaellt:

| Weg | P-Score 2020–2022 |
|---|---|
| OWID/WMD, USA | **14,4 %** |
| CDC, 50 Staaten + DC (1.279.057 ueberzaehlige / 8.897.612 erwartete Tote) | **14,38 %** |

**Versatz: −0,1 %. Praktisch deckungsgleich.**

Der Unterschied Economist-USA (390,6) zu OWID-USA (375,9) von +3,9 % ist
ueberwiegend ein Nennerproblem, kein Methodenproblem: OWID rechnet die USA mit
rund 340 Mio Einwohnern (rueckgerechnet aus
`cum_excess_per_million_proj_all_ages`), der Census-Mittelwert 2020–2022 liegt bei
332,3 Mio — das sind allein 2,4 Prozentpunkte.

**Einordnung gegen das Dezilprojekt:** dort betrug der reine Methodenversatz 16 %.
Hier sind es 1,5 % (Rate) bzw. 0,1 % (P-Score). Der Grund ist einfach: fuer die
USA speist sich die Laenderquelle aus denselben NCHS-Rohzahlen, aus denen auch
das CDC-Staatendataset gebaut ist.

**Die Gegenwarnung, die genauso wichtig ist.** Dass der Versatz fuer die USA klein
ist, beweist nichts fuer die anderen 34 Laender. Der Vergleich der beiden
Laenderquellen untereinander — beide „gemessen", nur mit anderer Baseline — zeigt
je Land (Kennzahl 1 gegen OWID-Per-100k, 2020–2022):

| Land | Economist | OWID/WMD | Abweichung |
|---|---|---|---|
| Daenemark | 109,9 | 67,5 | **+62,8 %** |
| Japan | 123,9 | 86,0 | +44,1 % |
| Finnland | 240,4 | 187,6 | +28,1 % |
| Deutschland | 272,6 | 218,0 | +25,1 % |
| Norwegen | 139,3 | 111,6 | +24,9 % |
| Schweden | 172,8 | 139,0 | +24,3 % |
| … | | | |
| USA | 390,6 | 375,9 | +3,9 % |
| Suedkorea | 124,6 | 124,9 | −0,2 % |
| Suedafrika | 456,1 | 467,2 | −2,4 % |

Spannweite **−2,4 % bis +62,8 %**, systematisch groesser bei den Laendern mit
kleiner Uebersterblichkeit — dort ist die Differenz zweier Baselines ein grosser
Anteil eines kleinen Werts. Danemark rueckt je nach Baseline vom Niveau
„Australien" auf das Niveau „Japan". Der Baselinewahl-Effekt ist also erheblich
groesser als der Laender-gegen-Staaten-Versatz.

---

## 6. Unvollstaendige Sterberegistrierung — geprueft, nicht angenommen

Die Vermutung im Auftrag war: Bosnien, Serbien, Indien, Suedafrika, Brasilien
haben unvollstaendige Registrierung. Befund:

- **Indien:** in der OWID/HMD-Datei **nicht enthalten** (geprueft, Abruf ueber alle
  35 Namen). Es gibt also keinen gemessenen All-Cause-Datenstand. Der
  Economist-Wert von 372,1 je 100.000 (≈ 5,2 Mio Tote) ist **vollstaendig eine
  Modellvorhersage**. Er ist in der CSV mit `belegart` = „abgelesen
  (Modellschaetzung)" gefuehrt und hat in der Economist-Datei ein sehr breites
  95-%-Intervall (Spalten `..._ci_95_top/bot_per_100k` in der Quelldatei — von mir
  **nicht** ausgewertet, NICHT GEPRUEFT). Fuer Indien gibt es keine
  P-Score-Zeile — die Luecke ist gemeldet, nicht geschaetzt.
- **Bosnien, Serbien, Brasilien, Suedafrika, Mexiko, Russland:** in beiden Quellen
  vorhanden, also gemeldete Gesamtsterblichkeit da. Der Economist-Wert liegt fuer
  Brasilien (+0,7 %), Mexiko (+0,5 %) und Suedafrika (−2,4 %) praktisch auf dem
  gemessenen Wert, fuer Bosnien (+11,9 %) und Serbien (+8,7 %) darueber.
  **Ob und wie stark die Registrierung dort unvollstaendig ist, habe ich nicht
  geprueft** — das ist eine Aussage ueber die nationalen Melderegister, die ich
  aus diesen beiden Dateien nicht belegen kann. Die Werte stehen ohne
  Vollstaendigkeitsaufschlag in der CSV.
- **Russland 2022: Werte vorhanden.** Beide Quellen fuehren Russland durchgehend
  bis Ende 2022 (Economist 204,5 je 100.000 fuer 2022; OWID-P-Score 11,1 % fuer
  2022, Monatsraster, Stichtag 2022-12-31). Die im Auftrag vermutete Luecke gibt
  es in diesen Quellen nicht.

**Kennzeichnung modelliert/gemessen:** die Economist-Datei trennt das nicht in
einer Spalte. Ich habe deshalb alle Economist-Zeilen konservativ als
„(Modellschaetzung)" in `belegart` markiert, obwohl fuer die meisten Laender der
gemessene Wert durchgereicht wird. Nur fuer Indien ist zweifelsfrei belegt, dass
gar kein gemessener Wert existiert.

---

## 7. Definitionsfallen

1. **New York City ist im CDC-Dataset eine eigene Meldeeinheit.** Die Zeile
   „New York" enthaelt den Staat **ohne** die Stadt. Ich habe NYC in den Staat
   New York eingerechnet. Wer das vergisst, halbiert New York.
2. **`excess_estimate` ist bei Null abgeschnitten** (Abruf `excess_estimate < 0`
   → 0 Treffer). Wochen mit Untersterblichkeit fallen sonst unter den Tisch.
   Deshalb `observed − average_expected_count` gerechnet.
3. **`type`.** Das Dataset fuehrt jede Woche doppelt: „Predicted (weighted)"
   (meldeverzugskorrigiert) und „Unweighted". Ohne Filter verdoppelt sich alles.
   Genommen: „Predicted (weighted)".
4. **`outcome`.** Ebenfalls doppelt: „All causes" und „All causes, excluding
   COVID-19". Genommen: „All causes".
5. **Das Jahr steht im CDC-Feld `year` nach MMWR-Konvention, nicht nach Kalender.**
   Ich habe das Jahr aus `week_ending_date` abgeleitet, nicht aus `year`.
6. **Vereinigtes Koenigreich** ist in der OWID-Datei die Summe aus England &
   Wales, Schottland und Nordirland (README). In `countries_justice.csv` liegen
   die drei getrennt — die Zahlen sind **nicht** zusammenfuehrbar.
7. **Monats- gegen Wochenraster** in der P-Score-Quelle (siehe Abschnitt 4). Die
   Stichtage der monatlichen Melder liegen 6 Tage spaeter als die der
   woechentlichen.
8. **Die beiden Laender-Kennzahlen sind nicht ineinander umrechenbar** und ihre
   Rangfolgen weichen ab. Beispiel: Daenemark ist bei Kennzahl 1 Rang 2 von 36,
   bei Kennzahl 2 Rang 1. Mexiko ist bei Kennzahl 1 Rang 30, bei Kennzahl 2 Rang
   35 (hoechster P-Score ueberhaupt) — weil Mexiko ein junges, also niedriges
   erwartetes Niveau hat.
9. **Der Zeitraum entscheidet.** Wie erwartet, und hier belegt: Norwegen 2020 =
   +3,6 je 100.000, 2022 = +102,4. Daenemark 2020 = +1,8, 2022 = +69,9. Japan
   2020 = −12,4, 2022 = +111,3. Wer 2020 allein zeigt, erzaehlt eine andere
   Geschichte als wer 2020–2022 zeigt. Deshalb liegen die Jahreswerte bei.

---

## 8. Luecken (gemeldet, nicht geschaetzt)

- **Indien: kein P-Score** (4 Zeilen fehlen: `_2020_2022`, `_2020`, `_2021`,
  `_2022`). Quelle fuehrt das Land nicht.
- **Konfidenzintervalle des Economist-Modells nicht ausgewertet** — sie stehen in
  der Quelldatei, sind aber nicht in die CSV uebernommen. Fuer Indien,
  Suedafrika und Brasilien waeren sie die eigentlich interessante Zahl.
- **Exakte Baseline-Spezifikation** bei Economist und CDC: nicht geprueft
  (Abschnitt 2).
- **Altersstandardisierte Werte:** gibt es in keiner der drei Quellen. Wer sie
  braucht, muss zur HMD-STMF-Rohdatei mit Altersgruppen und einer eigenen
  Standardbevoelkerung — anderes Projekt.
