# Länderwerte "If country XY were a US state" — Definitionsfallen, Lücken, Quellenlage

Stand: 2026-09-18. Datei: `countries_economy.csv`.
Länder (13): Deutschland, Frankreich, Italien, Spanien, Schweiz, Vereinigtes Königreich,
Dänemark, Norwegen, Schweden, Finnland, Polen, Russland, USA.

Belegarten in der CSV-Spalte `belegart`: `abgelesen` (auf der abgerufenen Quellseite
gesehen) · `berechnet` (aus abgelesenen Werten gerechnet, Rechenweg hier dokumentiert) ·
`inferiert` · `angenommen` · `nicht_geprueft`.

---

## 0. Die wichtigste Warnung vorweg: PPP ist nicht RPP

Die US-Staatenbasis enthält **BEA Regional Price Parities (RPP, US-Durchschnitt = 100)**.
Das ist **keine** internationale Kaufkraftparität. Beides ist nicht ohne Weiteres vergleichbar.

**Wie man verketten müsste (zwei Schritte, nicht einer):**

1. **Land → US-Durchschnitt:** Landeswert in Landeswährung durch den PPP-Umrechnungsfaktor
   teilen. Ergebnis = internationale Dollar auf US-Preisniveau-Basis
   (die OECD/IWF-PPPs sind so normiert, dass USA = 1,00).
2. **US-Durchschnitt → Bundesstaat:** diesen Wert durch `RPP_Staat / 100` teilen.
   Erst dann steht ein Landeswert neben einem Staatswert auf demselben Preisniveau.

In der CSV liegen dafür zwei Hilfsgrößen (Jahr 2022, OECD):
- `ppp_umrechnungsfaktor_bip` (PPP_B1GQ, BIP-PPP) — passend zu BIP-Größen.
- `ppp_umrechnungsfaktor_konsum_aic` (PPP_P41, PPP für tatsächlichen Individualkonsum) —
  **das ist die konzeptionell richtige Brücke zur BEA-RPP**, denn die RPP ist ein
  Konsumpreis-Index (Mieten + Waren + Dienstleistungen), kein BIP-Deflator.
  Wer eine Einkommensgröße verkettet, muss PPP_P41 nehmen, nicht PPP_B1GQ.

**Fehlerquellen dieser Verkettung — sie ist bewusst keine saubere Operation:**

1. **Warenkorb-Bruch.** Die internationale PPP wägt einen ICP-Warenkorb über Länder;
   die BEA-RPP wägt einen US-CPI-nahen Warenkorb über US-Regionen. Die beiden Indizes
   messen nicht dasselbe Preisniveau, sie werden nur multiplikativ aneinandergehängt.
2. **Mietgewicht.** Die RPP-Streuung zwischen US-Staaten wird überwiegend von "rents"
   getrieben. Der Mietanteil im ICP-Warenkorb ist anders gewichtet. Die Verkettung
   überträgt das US-Mietgewicht auf einen international normierten Wert.
3. **Fehler multiplizieren sich.** Zwei Indizes mit je eigener Revisionshistorie und
   Unsicherheit werden multipliziert; die Unsicherheiten addieren sich relativ.
4. **Kein Binnenpreisniveau im Land.** München und Mecklenburg-Vorpommern bekommen
   denselben Landes-PPP. Ein Bundesstaat bekommt eine eigene RPP. Die Auflösung ist
   also auf der US-Seite feiner als auf der Länderseite — der Vergleich ist asymmetrisch.
5. **Jahresversatz.** Die PPP-Hilfsgrößen hier sind 2022; BEA-RPP liegen für andere
   Jahre vor. Vor der Verkettung Jahr gegen Jahr prüfen.

**Empfehlung:** Für eine Grafik entweder (a) durchgängig nominal in USD zu
Marktwechselkursen arbeiten und die Kaufkraftfrage offen benennen, oder (b) die
Verkettung ausführen **und** die Zweistufigkeit in der Fußnote zeigen. Was nicht geht:
einen PPP-Landeswert kommentarlos neben einen RPP-adjustierten Staatswert stellen.

---

## 1./2. BIP pro Kopf nominal und kaufkraftbereinigt

- **Quelle (beide, alle 13 Länder, identisch):** IMF World Economic Outlook Database,
  **Ausgabe April 2026**, abgerufen über die offizielle IMF-DataMapper-API.
  Indikatoren `NGDPDPC` (nominal, USD je Kopf) und `PPPPC` (PPP, internationale Dollar je Kopf).
  URLs: `https://www.imf.org/external/datamapper/api/v1/NGDPDPC` bzw. `.../PPPPC`.
  Die API meldet im Metadaten-Endpunkt selbst als Quelle "World Economic Outlook (April 2026)",
  zuletzt geändert 2026-04-08.
- **Jahr:** Primärjahr **2024** für alle 13 Länder, aus derselben Quelle, kein Mischjahrgang.
  Zusätzlich als eigene Metriken `bip_pro_kopf_nominal_2025e` / `bip_pro_kopf_ppp_2025e`
  für 2025, falls ein aktuelleres Jahr gebraucht wird.
- **Warum 2024 als Primärjahr:** 2024 ist in der WEO-Ausgabe April 2026 der zuletzt
  realisierte Jahrgang; 2025 ist für viele Länder noch Schätzung.
  **ABER — abgelesen aus der US-Staatenbasis:** `us_states_economy.csv` führt
  `gdp_per_capita_nominal` für das Jahr **2025**. Für die BIP-Grafik ist deshalb die
  Metrik `bip_pro_kopf_nominal_2025e` bzw. `bip_pro_kopf_ppp_2025e` die **passende**,
  nicht die 2024er-Reihe. Wer 2024 nimmt, vergleicht gegen ein anderes Jahr als die
  US-Seite. Beide Jahrgänge liegen deshalb in der CSV.
- **Vorbehalt zur Jahrgangsbenennung:** Das Suffix `_2025e` ("estimate") impliziert im
  Umkehrschluss, die 2024er-Werte seien realisiert. Das ist **nicht geprüft** (siehe
  nächster Punkt) und soll nicht als Tatsache gelesen werden.
- **LÜCKE / nicht geprüft:** Die DataMapper-API gibt das WEO-Feld
  "estimates start after" **nicht** aus. Ob 2024 für jedes einzelne der 13 Länder ein
  Ist-Wert oder schon eine Schätzung ist, konnte hier **nicht geprüft** werden. Wer das
  braucht, muss die WEO-XLSX ziehen, die diese Spalte je Land führt.
- **Nicht möglich:** Ein Gegencheck gegen die HTML-Oberfläche des DataMapper scheiterte,
  weil die Seite die Zahlen per JavaScript nachlädt. Die Werte stammen also aus dem
  API-Endpunkt der IMF — der offiziellen Maschinenschnittstelle derselben Datenbank —,
  nicht aus der WEO-XLSX. `abgelesen` bezieht sich auf diesen Endpunkt.
- **Definitionsfalle:** `PPPPC` und `NGDPDPC` sind für die USA definitionsgemäß identisch
  (USA = Referenz, PPP-Faktor 1,00). Das ist kein Datenfehler.
- **Definitionsfalle:** Das ist **BIP je Kopf**, nicht Einkommen. Für Irland-artige
  Verzerrungen ist hier keines der 13 Länder ein akuter Fall, aber Norwegen und die
  Schweiz sind durch Öl- bzw. Finanzsektor und Pendler-Effekte nach oben verzerrt
  gegenüber dem, was Haushalte tatsächlich verfügbar haben — siehe Kennzahl 3.

---

## 3. Median-Haushaltseinkommen (äquivalenzgewichtetes verfügbares Einkommen)

- **Quelle:** OECD Income Distribution Database (IDD), SDMX-Dataflow
  `OECD.WISE.INE,DSD_WISE_IDD@DF_IDD,1.0`.
  Measure `INC_DISP`, STATISTICAL_OPERATION `MEDIAN`, AGE `_T` (alle Altersgruppen),
  METHODOLOGY `METH2012`, DEFINITION `D_CUR` (current definition).
  Portal: https://www.oecd.org/en/data/datasets/income-distribution-database.html
- **Jahr: 2022** — das ist das **jüngste Jahr, in dem alle verfügbaren Länder vorliegen**.
  Bewusst kein Mischjahrgang: 2023 läge für 11 Länder vor, aber **Dänemark endet 2022**.
  Deshalb 2022 für alle.
- **Was die Zahl ist, ausdrücklich:**
  - **verfügbar = netto**, also nach Steuern und nach Sozialtransfers.
  - **äquivalenzgewichtet: ja.** Die Einheit in der Quelle lautet wörtlich
    "National currency per equivalised household". Die OECD nutzt die
    Quadratwurzel-Skala (Haushaltseinkommen geteilt durch Wurzel aus der Personenzahl).
  - Das ist damit **NICHT dasselbe** wie das US-"Median Household Income" der
    Census/ACS-Staatenbasis. Das US-Maß ist ein **Brutto**-Haushaltseinkommen
    (money income vor Steuern) und **nicht äquivalenzgewichtet**.
    → **Das ist die größte Definitionsfalle des ganzen Datensatzes.**
      Die beiden Größen dürfen nicht in dieselbe Spalte einer Grafik.
- **Kontrollanker:** Für die USA liefert die OECD-IDD für 2022 einen Median von
  46.410 USD (äquivalenzgewichtet, netto). Der US-Census-Median des
  Haushaltseinkommens 2022 liegt deutlich höher (anderes Konzept). Wer die
  Länderwerte gegen die US-Staatenbasis stellen will, sollte den **OECD-US-Wert als
  Referenzpunkt** verwenden, nicht den Census-US-Wert — sonst misst man den
  Definitionsunterschied statt des Länderunterschieds.
- **Umrechnung in USD (`berechnet`):** Landeswährungswert geteilt durch den
  OECD-Jahresdurchschnittskurs 2022 (Landeswährung je USD).
  Kursquelle: OECD "Annual Purchasing Power Parities and exchange rates",
  Dataflow `OECD.SDD.NAD,DSD_NAMAIN10@DF_TABLE4`, TRANSACTION `EXC_A`
  ("Exchange rates, average"), Einheit `XDC_USD`.
  **Stichtag: Jahresdurchschnitt 2022**, kein Tageskurs.
  Sowohl der Ausgangswert in Landeswährung als auch der verwendete Kurs stehen als
  eigene Zeilen (`median_verfuegbares_einkommen_landeswaehrung`,
  `wechselkurs_landeswaehrung_je_usd`) in der CSV — die Umrechnung ist nachrechenbar.
  Verwendete Kurse 2022: EUR 0,949624 · CHF 0,954832 · GBP 0,811302 · DKK 7,076152 ·
  NOK 9,614167 · SEK 10,114251 · PLN 4,457758 · RUB 68,484942 · USD 1,000000.
- **LÜCKE: Russland.** Russland ist in der OECD-IDD **nicht enthalten** (kein OECD-Mitglied,
  auch nicht als Key Partner in diesem Dataflow). Eingetragen als `nicht_in_quelle`,
  belegart `nicht_geprueft`. **Nicht geschätzt.** Wer Russland hier braucht, muss auf
  Rosstat oder LIS ausweichen — dann ist es aber eine andere Quelle und ein anderes
  Konzept, und das muss in der Grafik stehen.
- **Alle 13 aus derselben Quelle/demselben Jahr?** → **Nein: 12 von 13, alle 2022.**
  Russland fehlt.

---

## 5. Armutsquote (unter 50 % des Medianeinkommens)

- **Quelle:** OECD Income Distribution Database, identischer Dataflow wie Kennzahl 3.
  Measure `PR_INC_DISP` ("Poverty rate based on disposable income"),
  POVERTY_LINE `PL_50` ("50% of the national median disposable income"),
  AGE `_T`, METHODOLOGY `METH2012`, DEFINITION `D_CUR`.
- **Jahr: 2022**, alle verfügbaren Länder, gleiche Begründung wie oben (Dänemark endet 2022).
- **Definitionsfalle — die entscheidende:** Das ist eine **relative** Armutsquote gegen
  den **jeweils nationalen** Median. Sie misst Ungleichheit innerhalb des Landes,
  **nicht** absolute Entbehrung. Ein armes Land kann eine niedrige Quote haben und ein
  reiches eine hohe. Polen (9,1 %) hat nicht "weniger Armut" als die USA (18,1 %) im
  Sinne von Lebensstandard — es hat weniger Streuung um seinen eigenen, niedrigeren Median.
  Wer die Quote neben BIP/Kopf stellt, muss das sagen, sonst entsteht ein falscher Schluss.
- **Zweite Falle:** Die OECD-Quote basiert auf **äquivalenzgewichtetem verfügbarem
  Einkommen** und ist damit **nicht** die offizielle US-"poverty rate" der Census-Bureau-
  Armutsschwelle (absolutes Schwellenwertkonzept). Falls die US-Staatenbasis die
  Census-Armutsquote führt, sind das zwei unterschiedliche Maße. Die OECD liefert für die
  USA 18,08 % (2022) — der Census-Wert liegt bei anderer Definition deutlich niedriger.
  **Entweder alles OECD, oder der Bruch wird ausgewiesen.**
- **Abgelesen aus der US-Staatenbasis** (`us_states_economy.csv`, im selben Verzeichnis):
  sie führt **zwei** Armutsmaße — `poverty_rate_official_acs` (2024) und
  `poverty_rate_spm_3yr_avg` (2022–2024, Supplemental Poverty Measure).
  **Der SPM ist die konzeptionell nähere Brücke zur OECD-Quote**, weil er Steuern und
  Transfers berücksichtigt; die offizielle ACS-Quote tut das nicht. Wer die Länderquote
  gegen US-Staaten stellt, nimmt den SPM — und weist trotzdem aus, dass der SPM ein
  absolutes Schwellenkonzept ist und die OECD-Quote ein relatives.
- **LÜCKE: Russland** — nicht in der OECD-IDD. `nicht_in_quelle` / `nicht_geprueft`.
- **Alle 13 aus derselben Quelle/demselben Jahr?** → **Nein: 12 von 13, alle 2022.**

---

## 6. Human Development Index

- **Quelle:** UNDP, Human Development Report 2025, Statistischer Anhang, Tabelle 1
  ("Human Development Index and its components").
  https://hdr.undp.org/sites/default/files/2025_HDR/HDR25_Statistical_Annex_HDI_Table.pdf
- **Datenjahr: 2023** (Spaltenkopf der Tabelle), Berichtsausgabe 2025.
  Das Datenjahr ist nicht das Berichtsjahr — in der Grafik gehört **2023** hin.
- **Alle 13 aus derselben Quelle/demselben Jahr?** → **Ja, 13 von 13, alle 2023, alle `abgelesen`.**
  Einschließlich Russland (0,832). Dies ist die einzige Kennzahl mit lückenloser Abdeckung.
- **Definitionsfalle:** Der HDI ist für Hocheinkommensländer stark gestaucht — zwischen
  Norwegen (0,970) und Polen (0,906) liegen 0,064 Punkte. Rangunterschiede sehen in
  einer Grafik dramatischer aus, als der Indexabstand rechtfertigt. Zudem wird der
  Einkommensteil des HDI **logarithmiert**, sodass hohe Einkommensunterschiede kaum
  noch durchschlagen. Der HDI eignet sich nicht, um die BIP-Unterschiede zu bestätigen —
  er dämpft sie konstruktionsbedingt.
- **Auf Staatenebene gibt es kein Gegenstück — geprüft:** Der UNDP publiziert keinen HDI
  für US-Bundesstaaten. **Abgelesen:** In den vorliegenden US-Staatendateien im selben
  Verzeichnis kommt HDI **nicht vor** (kein Treffer in `us_states_*.csv`).
  → **Konsequenz: Die HDI-Kennzahl kann keine US-Bundesstaaten zeigen.** Sie taugt für
  einen Länder-gegen-USA-Vergleich, nicht für die Staatengrafik. Ein "subnational HDI"
  aus Drittquellen (z. B. Global Data Lab) hätte eine abweichende Methodik und dürfte
  nicht neben den UNDP-Wert gestellt werden.

---

## 7. Bezahlter Mutterschutz / Elternzeit

- **Quelle:** OECD Family Database, Indikator **PF2.1 "Parental leave systems"**,
  Tabelle PF2.1.A.
  https://webfs.oecd.org/els-com/Family_Database/PF2_1_Parental_leave_systems.pdf
  (Landing Page: https://www.oecd.org/en/data/datasets/oecd-family-database.html)
- **Stand: April 2025** — die Quelle sagt wörtlich, die Tabelle gebe Ansprüche
  "as of April 2025" wieder. Einheitlicher Stichtag für alle abgedeckten Länder.
- **Fünf Metriken je Land in der CSV:**
  1. `mutterschutz_bezahlte_wochen` — Wochen bezahlter Mutterschutz
  2. `mutterschutz_lohnersatzrate` — durchschnittliche Lohnersatzrate über diese Wochen (%)
  3. `mutterschutz_full_rate_equivalent_wochen` — **Wochen × Ersatzrate**
  4. `bezahlte_gesamtfreistellung_mutter_wochen` — Mutterschutz + Eltern- + Betreuungszeit
  5. `bezahlte_gesamtfreistellung_mutter_fre_wochen` — dasselbe als Full-Rate-Equivalent
- **Zur Belegart:** Die Full-Rate-Equivalent-Spalten werden von PF2.1.A **selbst
  publiziert** (Spalten (3) und (9) der Tabelle) und wurden dort abgelesen, nicht
  nachgerechnet. Die Formel "Wochen × Ersatzrate" steht hier als Erläuterung, nicht als
  Rechenweg — deshalb `abgelesen` und nicht `berechnet`.
- **Warum nur (3) und (5) über Länder hinweg vergleichbar sind:** "52 Wochen bei 30 %"
  und "14 Wochen bei 100 %" ergeben denselben Lohnausfall-Ausgleich, sehen aber in einer
  Wochen-Balkengrafik völlig verschieden aus. Das Vereinigte Königreich hat mit 39 Wochen
  formal die zweitlängste Mutterschutzdauer der Gruppe, aber bei 29,9 % Ersatzrate nur
  11,7 Full-Rate-Equivalent-Wochen — weniger als Deutschland mit 14 Wochen bei 100 %.
  **Wer Wochen ohne Ersatzrate plottet, plottet das Gegenteil der Realität.**
- **USA — die Pointe, nicht eine Null:** Die Quelle führt für die USA in den Tabellen
  PF2.1.C/D/E "No statutory entitlement". In der CSV steht deshalb
  `kein_bundesgesetzlicher_anspruch`, nicht 0. Die Quelle merkt zudem an, dass zum
  Februar 2025 dreizehn Bundesstaaten und der District of Columbia eigene bezahlte
  Familienurlaubssysteme hatten — diese sind in PF2.1 **bewusst nicht enthalten**, weil
  PF2.1 nur nationale/föderale Ansprüche abbildet. **Für eine Bundesstaaten-Grafik ist
  das ein echtes Problem:** der Bundeswert ist "kein Anspruch", aber Kalifornien,
  New York und andere haben einen. Wer US-Staaten einzeln zeigt, darf hier nicht den
  Bundeswert einsetzen, sondern muss die bundesstaatlichen Systeme separat erheben.
  Die Aussage "FMLA ist unbezahlt" steht in dieser Quelle **nicht** wörtlich —
  sie wäre `inferiert` und ist hier bewusst nicht als Beleg geführt.
- **UK-Hinweis der Quelle:** Die dreizehn **unbezahlten** Mutterschutzwochen sind nicht
  enthalten — daher 39 statt 52 Wochen.
- **LÜCKE: Russland.** Der String "Russia" kommt im PF2.1-Dokument nicht vor.
  PF2.1 deckt OECD-Mitglieder plus die Nicht-OECD-EU-Staaten ab; Russland ist in keiner
  der beiden Gruppen. `nicht_in_quelle` / `nicht_geprueft`. **Nicht aus dem Gedächtnis
  ergänzt.**
- **Alle 13 aus derselben Quelle/demselben Jahr?** → **Nein: 12 von 13 (inkl. USA als
  ausgewiesener Nicht-Anspruch), alle Stand April 2025.** Russland fehlt.

---

## RUSSLAND — Gesamtvorbehalt

1. **Datenlücken.** Russland fehlt in der OECD-Income-Distribution-Database (Kennzahlen 3
   und 5) und in der OECD Family Database PF2.1 (Kennzahl 7) vollständig. Es ist kein
   OECD-Mitglied und in diesen Dataflows nicht als Partnerland geführt. Diese Lücken
   wurden **nicht** durch Ersatzquellen gefüllt.
2. **Wechselkursvorbehalt ab 2022.** Der Rubel war 2022 extrem volatil (Spanne im
   Jahresverlauf grob von ~55 bis ~120 RUB/USD). Der hier geführte
   OECD-Jahresdurchschnittskurs von 68,48 RUB/USD ist ein arithmetisches Konstrukt über
   ein Jahr, in dem der Kurs durch **Kapitalverkehrskontrollen und Exportpflichten
   administrativ gestützt** war. Ein zu Marktkursen umgerechneter russischer USD-Wert ab
   2022 misst deshalb nur eingeschränkt Kaufkraft oder Wirtschaftsleistung.
   **Konsequenz:** Der PPP-Wert (Kennzahl 2) ist für Russland die belastbarere Größe;
   der Nominalwert (Kennzahl 1) sollte in einer Grafik mit Fußnote stehen.
3. **Datenqualität der Primärstatistik.** Rosstat hat seit 2022 die Veröffentlichung
   mehrerer Reihen (u. a. Außenhandel, Teile der Unternehmensstatistik) eingestellt oder
   eingeschränkt. Die IWF-WEO-Werte für Russland beruhen weiterhin auf nationalen
   Meldungen. Ob und wie stark das die BIP-Reihe beeinflusst, ist hier **nicht geprüft** —
   der Vorbehalt wird benannt, nicht quantifiziert.
4. Der HDI-Wert für Russland (0,832, Datenjahr 2023) stammt aus dem UNDP-Bericht und ist
   die einzige Kennzahl, in der Russland lückenlos und aus derselben Quelle wie alle
   anderen zwölf Länder vorliegt.

---

## 4. Gesetzlicher Mindestlohn

### Die Falle, ausdrücklich: sechs Länder haben keinen

**Dänemark, Schweden, Finnland, Norwegen, Italien** haben **keinen** nationalen
gesetzlichen Mindestlohn; Lohnuntergrenzen entstehen über Tarifverträge.
Die **Schweiz** hat keinen nationalen, aber **kantonale** Mindestlöhne.
In der CSV steht dafür `kein_gesetzlicher_mindestlohn` bzw.
`kein_gesetzlicher_mindestlohn_national` — **nicht 0 und nicht leer.**
Eine Grafik, die hier eine Null balkt, behauptet etwas, das die Daten nicht hergeben.
Die verbreitete Aussage, Dänemark und Norwegen hätten faktisch mit die höchsten
Lohnuntergrenzen Europas, ist in dieser Recherche **nicht belegt worden** — genau dafür
fehlt die Tariflohn-Zahl (siehe nächster Absatz). Sie darf deshalb weder in der Grafik
noch in der Bildunterschrift als Tatsache erscheinen.

**Beleg für die Abwesenheit:** Der WSI-Mindestlohnbericht 2026 führt diese Länder in
seiner Länderliste der gesetzlichen Mindestlöhne nicht auf und schreibt ausdrücklich,
dass "Österreich, Italien und die nordischen EU-Länder" keinen gesetzlichen Mindestlohn
haben, weil Tarifverträge bei über 80 % Tarifbindung umfassenden Schutz bieten.
Für **Norwegen und die Schweiz** (beide keine EU-Mitglieder) ist die Kennzeichnung aus
der Abwesenheit in der Tabelle geschlossen → belegart `inferiert`, nicht `abgelesen`.

### LÜCKE: der tarifliche Einstiegslohn fehlt

Für DK, SE, NO, FI, IT und CH konnte **keine zitierbare, gesourcte Zahl** für den
effektiven tariflich vereinbarten Einstiegs-/Niedrigstlohn gefunden werden.
Die WSI-Datenbank weist diese Länder nicht aus; die Recherche lieferte nur
Sekundär-Blogs ohne Zahlenbeleg. In der CSV steht `luecke_keine_gesourcte_zahl` mit
belegart `nicht_geprueft`. **Bewusst nicht geschätzt.**
Damit fehlt der Grafik das Gegenstück zu den sechs Nicht-Mindestlohn-Ländern.
Wer die Aussage "Dänemark hat keinen Mindestlohn, aber höhere Löhne" belegen will,
braucht diese Zahl — sie ist hier offen.

### Quelle und Stichtag der vorhandenen Werte

- **Primärquelle:** WSI-Mindestlohnbericht 2026 (WSI Report Nr. 111, Lübker/Schulten,
  März 2026), Abb. 1 "Gesetzliche Mindestlöhne, Stand 1. Januar 2026, Euro pro Stunde".
  https://www.wsi.de/fpdf/HBS-009345/p_wsi_report_111_2026.pdf
- **Einheitlicher Stichtag: 1. Januar 2026** für alle Länder mit gesetzlichem Mindestlohn.
- **Unabhängig gegengeprüft:** Die EUR/h-Werte für Deutschland (13,90), Frankreich (12,02),
  Spanien (8,63), Vereinigtes Königreich (14,25) und Polen (7,41) wurden über die
  WSI-Pressemitteilung nachgeprüft und stimmen exakt überein.
  Für Russland und die USA nennt die Pressemitteilung keine Werte; die dort für den
  Vollbericht berichteten EUR-Werte wurden daher **nicht** übernommen.

### Umrechnungskurs und Stichtag — hier liegt eine Methodikfalle

Das WSI rechnet Nicht-Euro-Länder mit dem **Jahresdurchschnittskurs des Vorjahres (2025)**
in Euro um. Wer diese EUR-Werte dann mit einem 2026er-Kurs in USD überträgt, mischt zwei
Kurs-Jahrgänge und erzeugt einen Fehler.
**Deshalb wurde hier anders gerechnet:** USD/Stunde wird **direkt aus der Landeswährung**
mit **einem einzigen Wechselkurs-Stichtag** gebildet.

- **Kursquelle:** EZB-Euro-Referenzkurse (eurofxref-daily), **Stichtag 17.09.2026**.
  https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml
- Verwendete Kurse: 1 EUR = 1,1481 USD · 1 GBP = 1,337644 USD · 1 PLN = 0,263447 USD ·
  1 CHF = 1,212867 USD (die letzten drei als EZB-Kreuzkurse gerechnet, belegart `berechnet`).
- **Russland gesondert:** Die EZB veröffentlicht seit März 2022 **keinen RUB-Referenzkurs**
  mehr. Verwendet wurde der amtliche Kurs der Bank Rossii vom 17.09.2026
  (1 USD = 84,1732 RUB), bezogen über einen Aggregator (AKM.RU); cbr.ru selbst wurde
  nicht abgerufen → belegart der Kursquelle `inferiert`.
- **Wichtig: zwei verschiedene Kurs-Stichtage in dieser CSV.** Der Mindestlohn nutzt den
  EZB-Kurs vom 17.09.2026 (weil der Mindestlohn ein 2026er-Stand ist); das
  Median-Einkommen (Kennzahl 3) nutzt den OECD-Jahresdurchschnitt 2022 (weil die
  Einkommensdaten 2022 sind). Das ist bewusst so und jeweils an der Zeile dokumentiert —
  aber **die beiden USD-Größen sind nicht auf denselben Kursstand gebracht.**

### Russland — die Stundenrechnung beruht auf einer Annahme

Russland kennt nur einen **Monats**-Mindestlohn (МРОТ), keinen Stundensatz:
27.093 RUB/Monat ab 01.01.2026 (FZ Nr. 429-ФЗ v. 28.11.2025, über eine
КонсультантПлюс-Meldung bezogen, Gesetzestext nicht geöffnet → `inferiert`).
Rechenweg: 27.093 / **173,33** Std. = 156,31 RUB/h ÷ 84,1732 = **1,86 USD/h**.
Der Teiler 173,33 (40-Std.-Woche × 52 ÷ 12) ist **angenommen** — der russische
Produktionskalender 2026 wurde **nicht geprüft**. Mit 164,33 Std. ergäben sich 1,96 USD/h.
Die Zeile trägt deshalb belegart `angenommen`, nicht `berechnet`.
Regionale МРОТ liegen deutlich höher (Moskau ca. 39.730 RUB/Monat) — nicht in der CSV.

### USA — der Bundeswert ist für eine Staatengrafik der falsche Wert

7,25 USD/Std., unverändert seit **24.07.2009** (U.S. DOL, Wage and Hour Division).
Das WSI nennt ihn "weitgehend obsolet". **Für eine Bundesstaaten-Grafik ist das ein
echtes Problem:** 20 Bundesstaaten liegen auf Bundesniveau, andere deutlich darüber
(WSI, Stand 01.01.2026, in EUR: Washington DC 15,88 · Bundesstaat Washington 15,16 ·
New York 15,04 · Connecticut 14,99 · Kalifornien 14,96), dazu rund 70 Städte mit eigenen
Sätzen (Tukwila 19,16 · Seattle 18,85). Wer US-Staaten einzeln zeigt, muss die
bundesstaatlichen Sätze verwenden, nicht 7,25 USD.

### Sekundärmetrik: nachträgliche Erhöhungen 2026

Primärreihe ist der Stand **01.01.2026** (ein Stichtag für alle). Zwei Länder haben im
Jahresverlauf erhöht; das steht als eigene Metrik `mindestlohn_usd_pro_stunde_aktuell_in_kraft`:
UK ab April 2026 auf 12,71 GBP/h (17,00 USD, `berechnet`) und Frankreich ab 01.06.2026
auf 12,31 EUR/h (14,13 USD, `inferiert` — nur über einen Aggregator belegt, Urssaf bzw.
service-public.fr wurden nicht abgerufen).

### Kantonale Mindestlöhne Schweiz (Zusatzmetrik, schwacher Beleg)

Genf 29,82 · Basel-Stadt 26,93 · Jura 25,96 · Neuenburg 25,89 USD/h (2026, `inferiert`).
Die CHF-Ausgangswerte (24,59 / 22,20 / 21,40 / 21,35) stehen seit der Überarbeitung als
eigene Zeilen `kantonaler_mindestlohn_ch_*_landeswaehrung` in der CSV, die Umrechnung ist
damit nachrechenbar.
Quelle ist ein **Aggregator** (salairenet.ch); die amtlichen kantonalen Publikationen
(GE: OCIRT, NE: Loi sur l'emploi) wurden **nicht geprüft**. Vor Verwendung verifizieren.

- **Alle 13 aus derselben Quelle/demselben Jahr?** → **Im Prinzip ja, für die
  Klassifikation:** WSI-Bericht, Stand 01.01.2026, deckt alle 13 ab — entweder mit Wert
  oder als Nicht-Mindestlohn-Land. **Aber:** die Landeswährungsbeträge für UK, Polen,
  Russland und die USA stammen aus je eigenen nationalen Quellen (GOV.UK, Dz.U.,
  КонсультантПлюс, DOL), und die USD-Umrechnung ist eine eigene Rechenschicht.
  **Die Zusatzmetrik "tariflicher Einstiegslohn" ist für 6 Länder eine offene Lücke.**

---

## 8. Gesetzlicher Mindesturlaub und gesetzliche Feiertage

### Diese Kennzahl ist die schwächste im Datensatz — bitte lesen, bevor sie geplottet wird

**Die gewünschte Einheitsquelle war nicht verfügbar.** Eurofound
(https://www.eurofound.europa.eu) antwortete auf jeden Abruf mit **HTTP 429 Too Many
Requests** — sowohl beim Rechercheagenten als auch bei meinem eigenen, unabhängigen
Nachversuch auf den Datensatz "Minimum number of days of paid annual leave, EU27 and
Norway, 2024". Das ist eine **bestätigte, nicht eine vermutete** Nichtverfügbarkeit.
Auch die ILO-Working-Time-Datenbank und der OECD-Data-Explorer wurden **nicht** abgefragt.

**Konsequenz: Kennzahl 8 stammt aus 13 heterogenen nationalen Primärquellen mit
unterschiedlichen Ständen.** Jede Zeile trägt dafür einen Warnhinweis im Feld
`source_name`. Das ist der einzige Punkt, an dem der Auftrag "alle 13 aus derselben
Quelle" **nicht erfüllt** ist.

### Die Tage-Definitionen sind nicht dieselben — Addition ohne Normalisierung ist falsch

Drei unterschiedliche Zählweisen stehen nebeneinander, das Feld `unit` sagt jeweils welche:

- **Werktage / 6-Tage-Basis** (Samstag zählt mit): Deutschland 24, Frankreich 30,
  Norwegen 25, Finnland 30. → In Arbeitstagen bei 5-Tage-Woche sind das
  **20, 25, 21, 25**. Frankreich hat nicht "6 Tage mehr Urlaub als Deutschland",
  sondern 5 Arbeitstage mehr.
- **Arbeitstage / 5-Tage-Basis:** UK 28, Dänemark 25, Schweden 25, Polen 20 (bzw. 26 ab
  10 Jahren Dienstzeit).
- **Kalendertage** (Sonn- und Feiertage zählen mit): **Spanien 30**, **Russland 28**.
  Spaniens 30 Kalendertage sind rund 21–22 Arbeitstage, Deutschlands 24 Werktage sind
  20 Arbeitstage. Spanien liegt also nur **ein bis zwei Arbeitstage** über Deutschland —
  nicht sechs Tage, wie die Rohzahlen 30 gegen 24 suggerieren.
- **Wochenangaben ohne Tage:** Italien 4 Wochen, Schweiz 4 Wochen (5 bis zum 20. Lebensjahr).
  Die Umrechnung in Tage ist in beiden Fällen tarifvertraglich bzw. vertraglich.

→ **Ein Balkendiagramm über die Rohzahlen dieser Spalte ist irreführend.**
Deshalb liegt die Normalisierung jetzt als **eigene Datenzeile** vor, nicht nur als
Fließtext: die Metrik **`mindesturlaub_arbeitstage_5tage_basis`** rechnet alle Länder auf
Arbeitstage bei 5-Tage-Woche um (Faktor ×5/6 für Werktage-Basis, ×5/7 für Kalendertage,
×5 für Wochenangaben). Rechenweg und Ausgangswert stehen in jeder Zeile, belegart
`berechnet`. **Für eine Grafik ist diese Spalte zu verwenden, nicht die Rohspalte.**
Ergebnis: Frankreich und Finnland 25 · UK 28 · Dänemark und Schweden 25 · Spanien 21,4 ·
Norwegen 20,8 · Deutschland, Italien, Schweiz, Polen und Russland 20 ·
USA `kein_gesetzlicher_anspruch`.

### Urlaub und Feiertage dürfen im UK nicht addiert werden

Das Vereinigte Königreich gewährt 5,6 Wochen (28 Tage) — **Bank Holidays dürfen darauf
angerechnet werden.** UK hat also nicht 28 + 8 = 36 Tage, sondern 28 Tage, von denen
acht auf Feiertage fallen dürfen. In allen anderen Ländern der Liste kommen die
Feiertage zum Urlaub hinzu. Das ist der Grund, warum die beiden Größen hier
**getrennt** geführt werden und in der Grafik nicht summiert werden dürfen.

### USA — das ist die Pointe, deshalb explizit

Beide Größen stehen als **`kein_gesetzlicher_anspruch`**, nicht als 0.
Beleg (`abgelesen`), U.S. Department of Labor, "Vacation Leave":
der Fair Labor Standards Act verlangt keine Bezahlung für nicht gearbeitete Zeit,
einschließlich Urlaub, Krankheit und Feiertagen.
https://www.dol.gov/general/topic/workhours/vacation_leave
Die elf "federal holidays" gelten nur für **Bundesbedienstete**; private Arbeitgeber
sind zu nichts verpflichtet. Die USA sind das einzige Land der dreizehn ohne beide
Ansprüche — das trägt die ganze Grafik und sollte deshalb als Nicht-Anspruch
beschriftet werden, nicht als Nullbalken neben Zahlen.

### Offene Lücken und ein offener Widerspruch

1. **LÜCKE Feiertage Dänemark, Norwegen, Schweden, Finnland** — `luecke_nicht_geprueft`.
   Für Dänemark gilt zusätzlich: es gibt dort keine gesetzlich garantierten bezahlten
   Feiertage für alle Beschäftigten, die Regelung ist überwiegend tarifvertraglich.
   Das ist ein Hinweis, keine geprüfte Zahl. Vier von dreizehn Ländern fehlen hier.
2. **LÜCKE Polen (war zuerst falsch als Wert geführt):** Die Sekundärquelle nennt
   "13 oder 14" gesetzliche Feiertage; die dort abgedruckte Aufzählung enthält 14
   Positionen (seit 2025 zusätzlich der 24.12.). Eine der beiden Zahlen ohne Begründung
   zu wählen wäre `angenommen`, nicht `inferiert`. In der CSV steht deshalb
   `nicht_geprueft_13_oder_14` mit belegart `nicht_geprueft`. Der ISAP-Volltext wurde
   nicht gelesen. **Polen zählt damit zu den Lücken, nicht zu den belegten Werten.**
3. **Quellenwiderspruch Russland:** Die abgerufene Seite zu Art. 112 TK RF nennt im
   Fließtext "11" Feiertage; die dort gelistete Aufzählung (1.–6.1. und 8.1. = 7 Tage,
   plus 7.1., 23.2., 8.3., 1.5., 9.5., 12.6., 4.11.) ergibt **14**. Die Quelle ist damit
   in sich widersprüchlich, und es handelt sich um eine kommerzielle Sekundärseite;
   der Primärtext wurde nicht geprüft. In der CSV steht 14 mit belegart **`inferiert`**.
   **Zusätzlich ein Ebenenbruch:** Die russischen 14 sind **Kalendertage** (der 1.–6.1.
   zählt als sechs Einzeltage), während Deutschland 9, Frankreich 11 und Italien 12
   **Feiertagsanlässe** zählen. Die Zähleinheit steht seit der Überarbeitung im
   `unit`-Feld jeder Zeile (`ZAEHLEINHEIT_kalendertage` bzw. `ZAEHLEINHEIT_feiertagsanlaesse`).
4. **Primärtexte überwiegend nicht direkt gelesen.** Nur **fünf** Werte sind echt
   `abgelesen`: § 3 BUrlG (Deutschland, Urlaub), GOV.UK Holiday entitlement (UK, Urlaub),
   Art. L3133-1 Code du travail (Frankreich, Feiertage) und DOL (USA, Urlaub und
   Feiertage). Die UK-Feiertagszahl (8) ist eine **eigene Zählung** der GOV.UK-Liste und
   trägt deshalb `berechnet`, nicht `abgelesen`.
   Alle übrigen sind `inferiert` über Suchergebnis-Referate — Légifrance L3141-3,
   BOE Art. 38 und 37.2, Normattiva D.Lgs. 66/2003, OR 329a, Ferieloven DK und NO,
   Semesterlag, Vuosilomalaki, Kodeks pracy Art. 154, TK RF Art. 115, Legge 260/1949,
   SECO-Wegleitung, BMI-Feiertagsseite, ISAP.
5. **Deutschland Feiertage:** 9 bundeseinheitlich, real 9–13 je Bundesland
   (Feiertagsrecht ist Ländersache; bundesrechtlich fixiert ist nur der 3. Oktober).
   Die Länder-Spanne ist **nicht geprüft**. Für eine Grafik, die Deutschland gegen
   US-Bundesstaaten stellt, ist die föderale Streuung auf beiden Seiten relevant.
6. **Kontext aus Eurofound-Suchsnippets** (nur Snippet, nicht gefetcht → `inferiert`,
   nicht in der CSV): tariflich vereinbarter Jahresurlaub EU27 im Schnitt 24,3 Tage;
   Feiertage EU27 im Schnitt 10,2. Als Plausibilitätsanker brauchbar, als Beleg nicht.

- **Alle 13 aus derselben Quelle/demselben Jahr?** → **Nein.** 13 verschiedene Quellen.
  Urlaub: 13/13 Länder belegt, aber nur 4 `abgelesen`.
  Feiertage: 9/13 Länder belegt, 4 Lücken, 1 offener Widerspruch.

---

## Jahresversatz gegen die US-Staatenbasis — vier konkrete Paare

Abgelesen aus `us_states_economy.csv` (gleiches Verzeichnis). Die Länderseite und die
US-Seite stehen **nicht** auf denselben Jahrgängen. Vor jeder Grafik prüfen:

| Kennzahl | Länderwert (diese Datei) | US-Staatenwert | Versatz |
|---|---|---|---|
| BIP/Kopf nominal | 2024 **oder 2025** (beide vorhanden) | **2025** | 0 Jahre, wenn die 2025er-Reihe genommen wird |
| Median-Einkommen | **2022** | **2024** | **2 Jahre** — und zusätzlich netto-äquivalenzgewichtet gegen brutto-nicht-äquivalenzgewichtet |
| Armutsquote | **2022** | 2024 (ACS) bzw. 2022–2024 (SPM) | **2 Jahre** bzw. überlappender Dreijahresschnitt |
| Mindestlohn | Stand **01.01.2026** | Stand **01.07.2026** | **ein halbes Jahr** — im ersten Halbjahr 2026 haben u. a. UK und Frankreich erhöht (siehe Sekundärmetrik) |
| Preisniveau | PPP **2022** | BEA RPP **2024** | **2 Jahre** — die Verkettung aus Abschnitt 0 mischt damit zwei Jahrgänge |

Beim Median-Einkommen addieren sich **zwei** Fehlerquellen: der Zweijahresversatz und
der Definitionsbruch (netto/äquivalenzgewichtet gegen brutto). Diese Kennzahl ist
deshalb die riskanteste für eine direkte Land-gegen-Staat-Grafik.

---

## Abdeckungsübersicht je Kennzahl

| # | Kennzahl | Eine Quelle? | Ein Jahr? | Abdeckung | Fehlend |
|---|---|---|---|---|---|
| 1 | BIP/Kopf nominal | ja (IWF WEO 04/2026) | ja (2024 **und** 2025; für die US-Grafik 2025 nehmen) | 13/13 | Ist/Schätzung je Land nicht geprüft |
| 2 | BIP/Kopf PPP | ja (IWF WEO 04/2026) | ja (2024 **und** 2025; für die US-Grafik 2025 nehmen) | 13/13 | Ist/Schätzung je Land nicht geprüft |
| 3 | Median verfügbares Einkommen | ja (OECD IDD) | ja (2022) | 12/13 | Russland |
| 4 | Mindestlohn | überwiegend (WSI 2026) | ja (Stand 01.01.2026) | 13/13 klassifiziert | tariflicher Einstiegslohn für 6 Länder |
| 5 | Armutsquote 50 % Median | ja (OECD IDD) | ja (2022) | 12/13 | Russland |
| 6 | HDI | ja (UNDP HDR 2025) | ja (Datenjahr 2023) | 13/13 | **kein US-Staaten-Gegenstück — nicht als Staatengrafik möglich** |
| 7 | Elternzeit / FRE-Wochen | ja (OECD FDB PF2.1) | ja (Stand 04/2025) | 12/13 | Russland |
| 8 | Urlaub / Feiertage | **NEIN — 13 Einzelquellen** | nein (Stände 2026, gemischt) | Urlaub 13/13, Feiertage **8/13** | Feiertage DK/NO/SE/FI **und Polen**; Eurofound HTTP 429 |

**Belegarten-Bilanz über alle 293 Zeilen** (Stand nach adversarialem Review):
210 `abgelesen` · 33 `berechnet` · 29 `inferiert` · 20 `nicht_geprueft`
(= ausgewiesene Lücken) · 1 `angenommen` (russischer Stundenteiler).

**Im Review korrigiert:** Norwegens `kein_gesetzlicher_mindestlohn` von `abgelesen` auf
`inferiert` (Norwegen ist kein EU-Land und vom WSI-Satz über die nordischen EU-Länder
nicht gedeckt) · Russlands Feiertage von `berechnet` auf `inferiert` · Polens Feiertage
von einem Wert (13) auf eine ausgewiesene Lücke · vier Feiertags-Lückenzeilen von einem
irreführenden Quellen-Textbaustein befreit · Zähleinheit (Kalendertage vs.
Feiertagsanlässe) in jede Feiertagszeile geschrieben · normalisierte Urlaubsspalte
ergänzt · CHF-Ausgangswerte und EZB-Kurse als eigene, nachrechenbare Zeilen ergänzt.

**Wenn nur eine Grafik gebaut wird:** Kennzahlen 1, 2 und 6 sind lückenlos (13/13) und
je aus einer Quelle und einem Jahr. Kennzahlen 3 und 5 sind sauber, aber ohne Russland.
Kennzahl 7 ist sauber, aber ohne Russland und mit der FRE-Falle. Kennzahl 4 ist sauber
klassifiziert, hat aber eine echte Lücke beim Tariflohn. **Kennzahl 8 sollte nicht ohne
den Abschnitt-8-Vorbehalt veröffentlicht werden.**
**Kennzahl 6 (HDI) kann keine Bundesstaaten zeigen** — auf der US-Seite existiert sie nicht.
