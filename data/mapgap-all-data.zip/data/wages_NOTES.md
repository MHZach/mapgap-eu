# Loehne statt Wirtschaftsleistung — Datenbasis und Definitionsfallen

Erstellt 2026-09-18. Dateien: `wages_countries.csv` (130 Zeilen), `wages_us_states.csv` (306 Zeilen).
Belegarten je Zeile in der Spalte `belegart`: `abgelesen` / `berechnet` / `nicht geprueft` (= Luecke).
Kein Wert stammt aus dem Gedaechtnis; jede Zahl wurde am 2026-09-18 aus der genannten API/Datei gezogen.

---

## 1. Was in den Dateien steht

### Laender (`wages_countries.csv`, 13 Laender x 10 Kennzahlen)

| metric | Jahr | Inhalt | belegart |
|---|---|---|---|
| `average_annual_wage_ppp` | 2025 | OECD AV_AN_WAGE, USD zu KKP, konstante Preise Basis 2025 | abgelesen |
| `average_annual_wage_ppp_pro_kopf` | 2025 | derselbe Lohn, FTE-Umrechnung herausgerechnet | berechnet |
| `fte_faktor_stunden_vollzeit_zu_allen` | 2025 | Stunden Vollzeit / Stunden alle Arbeitnehmer | berechnet |
| `part_time_rate_arbeitnehmer` | 2025 | Teilzeitquote, OECD-harmonisiert (<30 Std.), Arbeitnehmer | abgelesen |
| `usual_weekly_hours_arbeitnehmer_alle` / `_vollzeit` | 2025 | uebliche Wochenstunden im Hauptjob | abgelesen |
| `annual_hours_worked_je_arbeitnehmer` | 2025 | tatsaechlich geleistete Jahresstunden je Arbeitnehmer | abgelesen |
| `median_disposable_income_ncu` | 2022 | OECD IDD, Median aequivalenzgewichtetes verfuegbares Einkommen, Landeswaehrung | abgelesen |
| `ppp_privater_konsum` | 2022 | KKP fuer den privaten Konsum aus demselben Datensatz | abgelesen |
| `median_disposable_income_ppp` | 2022 | Median / KKP privater Konsum | berechnet |

### US-Bundesstaaten (`wages_us_states.csv`, 51 Einheiten x 6 Kennzahlen)

| metric | Jahr | Inhalt | belegart |
|---|---|---|---|
| `average_annual_wage_nominal` | 2025 | BLS QCEW `avg_annual_pay`, Total Covered, alle Branchen | abgelesen |
| `qcew_annual_avg_employment` | 2025 | Nenner dazu (Jahresdurchschnitt gefuellter Stellen) | abgelesen |
| `median_earnings_nominal_alle_erwerbstaetigen` | 2024 | ACS B20002_E001 | abgelesen |
| `median_earnings_vollzeit_ganzjahr_maenner_nominal` | 2024 | ACS B20017_E003 | abgelesen |
| `median_earnings_vollzeit_ganzjahr_frauen_nominal` | 2024 | ACS B20017_E006 | abgelesen |
| `median_earnings_vollzeit_ganzjahr_gesamt_nominal` | — | **LUECKE**, siehe Abschnitt 5 | nicht geprueft |

---

## 2. Die OECD-Groesse — was sie genau misst

Wortlaut der OECD-Metadaten zum Datensatz (abgelesen, SDMX-Strukturabruf
`OECD.ELS.SAE:DSD_EARNINGS@AV_AN_WAGE(1.0)`):

> "Average annual wages per full-time equivalent dependent employee are obtained by dividing the
> national-accounts-based total wage bill by the average number of employees in the total economy,
> which is then converted in full-time equivalent unit by applying the ratio of average usual weekly
> hours per full-time employee to that of all employees."

Daraus folgt dreierlei, jeweils **abgelesen**:

1. **Vollzeitaequivalent: ja.** Die FTE-Umrechnung ist kein Nebenaspekt, sondern der letzte Rechenschritt.
2. **Brutto: ja.** Zaehler ist die VGR-Position "wages and salaries" (D.11). Die enthaelt laut ESA-2010-Definition
   die vom Arbeitgeber einbehaltene Lohnsteuer und die Arbeitnehmer-Sozialbeitraege (also vor Abzug),
   **nicht** aber die Arbeitgeberbeitraege. Quelle: Eurostat/ESA 2010, Kapitel 4 —
   https://ec.europa.eu/eurostat/esa2010/chapter/view/4/
3. **Kaufkraftbereinigt mit Konsum-KKP, nicht BIP-KKP.** Die OECD-Methodendatei sagt ausdruecklich:
   "US $ Purchasing Power Parities (PPPs) for private consumption expenditures as conversion factors"
   (https://www.oecd.org/els/emp/AVERAGE_WAGES.pdf). Preisbasis: konstante Preise, Basisjahr 2025.

Weitere Abgrenzungen aus derselben Methodendatei (abgelesen): die VGR-Loehne decken **alle** abhaengig
Beschaeftigten ab, rechnen Teilzeit zum Vollzeitsatz hoch, beziehen Nebenjobs ein und schliessen im Prinzip
auch nicht deklarierte Einkommen ("non-observed economy"), Ausbildungsverguetungen und die Gehaelter von
Eigentuemern inkorporierter Unternehmen ein.

**Jahreswahl:** 2025 ist das neueste Jahr, in dem alle zwoelf OECD-Laender der Serie vorliegen
(2023, 2024 und 2025 sind jeweils vollstaendig; 2025 ist das aktuellste). Russland fehlt in allen Jahren.

---

## 3. Die QCEW-Groesse — was sie genau misst

QCEW `avg_annual_pay` = gesamte gemeldete Jahreslohnsumme / durchschnittliche Beschaeftigtenzahl.
Die Formel wurde an den Rohdaten nachgerechnet (Kalifornien 2025:
`total_annual_wages / annual_avg_emplvl` = 96.962,8 gegen ausgewiesene 96.963 — **berechnet**, Abweichung
nur Rundung). Beschaeftigung sind "only filled jobs, whether full or part-time"; es gibt **keine**
Stundenbereinigung und **keine** Vollzeitaequivalente.

Das BLS benennt die Folge selbst im technischen Anhang (abgelesen,
https://www.bls.gov/news.release/cewqtr.tn.htm):

> "Average weekly wages are affected by the ratio of full-time to part-time workers as well as the
> number of individuals in high-paying and low-paying occupations."

Loehne umfassen Boni, ausgeuebte Aktienoptionen, Abfindungen, Gewinnausschuettungen und Trinkgelder.
Abdeckung rund 95 % der zivilen abhaengigen Beschaeftigung; nicht erfasst sind Selbstaendige,
Streitkraefte, Eisenbahner, kleine Landwirtschaft, Teile der Hauswirtschaft und des Nonprofit-Sektors
(https://www.bls.gov/cew/questions-and-answers.htm).

**Jahreswahl:** 2025 ist das neueste vollstaendige Jahr in der QCEW-Open-Data-API (2026 gibt HTTP 404,
am 2026-09-18 geprueft).

---

## 4. AUFGABE 3 — der Definitionsbruch, quantifiziert

### (a) Richtung und Groessenordnung

**Richtung:** Die OECD-Zahl rechnet Teilzeit auf Vollzeit hoch, die QCEW-Zahl nicht. Wer beide
nebeneinanderstellt, **ueberschaetzt die Laender gegenueber den Bundesstaaten** — und zwar umso staerker,
je hoeher der Teilzeitanteil im Land ist.

**Groesse, direkt messbar.** Der FTE-Schritt ist exakt der Faktor
"uebliche Wochenstunden Vollzeit-Arbeitnehmer / uebliche Wochenstunden aller Arbeitnehmer".
Er steht als eigene Kennzahl in der CSV. 2025, Arbeitnehmer, beide Geschlechter, alle Altersgruppen
(Teilzeitquote: OECD-harmonisiert, <30 Wochenstunden im Hauptjob):

| Land | Teilzeitquote % | FTE-Faktor | Verzerrung relativ zu den USA |
|---|---|---|---|
| Schweiz | 24,1 | 1,1526 | **+7,5 %** |
| Daenemark | 19,3 | 1,1456 | **+6,8 %** |
| Deutschland | 22,7 | 1,1425 | **+6,5 %** |
| Norwegen | 19,3 | 1,1366 | **+6,0 %** |
| Vereinigtes Koenigreich | 20,1 | 1,1183 | **+4,3 %** |
| Finnland | 14,4 | 1,0912 | +1,8 % |
| Italien | 16,6 | 1,0840 | +1,1 % |
| Schweden | 10,8 | 1,0837 | +1,1 % |
| Spanien | 12,4 | 1,0739 | +0,1 % |
| **USA** | **12,5** | **1,0723** | 0,0 % |
| Frankreich | 12,9 | 1,0701 | −0,2 % |
| Polen | 4,9 | 1,0259 | −4,3 % |

Lesart der letzten Spalte: Allein aus dem Definitionsunterschied erscheint Deutschland in einer
OECD-gegen-QCEW-Grafik rund **6,5 %** besser, als es bei gleicher Messvorschrift stuende; die Schweiz
rund 7,5 %; Polen dagegen rund 4,3 % schlechter. Alle Werte **berechnet** aus
OECD `DSD_HW@DF_AVG_USL_WK_WKD` (2025).

**Gegenprobe im selben Land — die USA gegen sich selbst.** Beide Messvorschriften existieren fuer die USA,
2025, in derselben Waehrung (fuer die USA ist die KKP definitionsgemaess 1):

- OECD, vollzeitaequivalent: **86.977 USD**
- QCEW, je Kopf, USA gesamt (area `US000`, 155,7 Mio. Beschaeftigte): **78.720 USD**
- Verhaeltnis: **+10,5 %** — und das ohne jeden realen Lohnunterschied, allein aus der Definition.

Davon entfallen +7,2 % auf die FTE-Umrechnung. Der Rest, **+3,0 %**, ist Erfassungsunterschied:
Die aus der OECD-Zahl zurueckgerechnete Groesse "Lohn je Kopf" liegt bei 81.116 USD, also 3,0 % ueber
QCEW. Das passt zur Erwartung, denn die VGR-Lohnsumme umfasst Nebenjobs, nicht deklarierte Einkommen
und die vollen 100 % der Arbeitnehmer statt der 95 % UI-pflichtigen. **berechnet.**

Der Rest-Erfassungsunterschied ist klein und in der Richtung stabil; der FTE-Unterschied ist gross und
laenderweise **unterschiedlich gross** — er ist deshalb das eigentliche Problem.

Zusaetzlich, als Kontext und nicht als Korrektur: Die tatsaechlich geleisteten Jahresstunden je Arbeitnehmer
(2025, abgelesen) liegen in den USA bei 1.814, in Deutschland bei 1.298, Frankreich 1.393, Schweiz 1.336,
Polen 1.682. Selbst eine perfekt definitionsgleiche Lohnzahl vergleicht also weiterhin sehr ungleiche
Arbeitsmengen; wer "Einkommen je geleisteter Stunde" meint, braucht wieder eine andere Groesse.

### (b) Gibt es eine besser vergleichbare Paarung?

Drei Kandidaten wurden geprueft:

**B1 — beide Seiten als Median der Vollzeit-Ganzjahres-Erwerbseinkommen.**
Konzeptionell die sauberste Paarung, **aber auf der Laenderseite nicht beschaffbar.** Die OECD
veroeffentlicht zu Vollzeitverdiensten nur *Verhaeltniszahlen*: geprueft wurden `DSD_EARNINGS@DEC_I`
(nur D9/D5, D5/D1, D9/D1) und `DSD_EARNINGS@DATASET` (nur Lohnluecken, Niedrig-/Hochlohnanteile,
Mindestloehne). Ein **Niveau** eines Medians der Vollzeitverdienste existiert in keiner der beiden Serien
(am 2026-09-18 im Rohabruf geprueft). Damit faellt B1 aus — nicht aus Bequemlichkeit, sondern aus Mangel.

**B2 — beide Seiten als Lohn je Kopf ("per head"), Teilzeit in beiden eingerechnet.**
Beschaffbar, und zwar exakt: Der FTE-Schritt der OECD ist ein bekannter, publizierter Faktor; man kann ihn
herausdividieren. Genau das ist die Spalte `average_annual_wage_ppp_pro_kopf`. Die Gegenprobe an den USA
(81.116 gegen 78.720 QCEW, 3,0 % Abstand) zeigt, dass die beiden Seiten danach dasselbe messen — bis auf
den kleinen, gleichgerichteten Erfassungsunterschied.

**B3 — beide Seiten als Median des verfuegbaren Aequivalenzeinkommens.**
Auf der Laenderseite vorhanden (`median_disposable_income_ppp`, 2022). Auf der Bundesstaatenseite
**nicht** in vergleichbarer Form: Die OECD-IDD kennt keine US-Binnengliederung, und die ACS liefert
Haushaltseinkommen ohne Aequivalenzgewichtung und ohne die IDD-Einkommensdefinition. Eine Paarung
"IDD-Land gegen ACS-Bundesstaat" waere ein zweiter, groesserer Definitionsbruch als der hier behandelte.

### (c) Empfehlung

**Tragfaehig fuer eine Grafik:**

1. **`average_annual_wage_ppp_pro_kopf` (Laender, 2025) gegen `average_annual_wage_nominal` (Staaten, 2025).**
   Gleiche Messvorschrift (Lohnsumme je Kopf, Teilzeit drin), gleiches Jahr, gleiche Waehrungsbasis
   (KKP-bereinigte US-Dollar; fuer die USA ist die KKP 1, die Bundesstaatenwerte bleiben also unveraendert).
   Rest-Unschaerfe rund 3 % zulasten der Laender-Seite — das gehoert in die Bildunterschrift, entwertet die
   Grafik aber nicht.
2. **Innerhalb der Laenderseite** bleibt `average_annual_wage_ppp` (FTE) die richtige Groesse, wenn Laender
   nur untereinander verglichen werden. Nur die Mischung mit den Bundesstaaten ist das Problem.
3. **Median-Erwerbseinkommen der Bundesstaaten getrennt nach Geschlecht** (ACS B20017) taugt fuer eine
   eigene Grafik *innerhalb* der USA — nicht fuer den Laendervergleich.

**Nicht tragfaehig:**

- `average_annual_wage_ppp` (FTE) direkt gegen QCEW. Das ist die Paarung, die sich am ehesten aufdraengt,
  und sie misst zwei verschiedene Dinge: +10,5 % Niveauversatz, und laenderweise zwischen −4,3 % (Polen)
  und +7,5 % (Schweiz) unterschiedlich. Eine solche Grafik wuerde genau die Aussage stuetzen, die man
  pruefen wollte, ohne sie zu belegen.
- `median_disposable_income_ppp` (Laender) gegen irgendeine ACS-Groesse (Staaten). Verfuegbares
  aequivalenzgewichtetes Haushaltseinkommen nach Steuern und Transfers gegen Brutto-Erwerbseinkommen
  einzelner Personen — das kreuzt Einkommensbegriff, Einheit (Haushalt gegen Person) und Umverteilungsstufe
  zugleich.
- Jede Mischung der Jahre. Die Laender-Loehne sind 2025, die Laender-Mediane 2022, die ACS-Mediane 2024,
  QCEW 2025. In einer Grafik darf nur ein Jahrespaar stehen, und es muss dranstehen.

**Eine Nebenbemerkung, die zum Anlass der Serie passt:** Die Frage war, ob der BIP-pro-Kopf-Vorsprung der
USA beim Lohn schrumpft. Er tut es, aber weniger als erwartet, und die Reihenfolge aendert sich.
Bei `average_annual_wage_ppp` (FTE) liegen die USA hinter der Schweiz auf Platz 2 von 12. Beim Median des
verfuegbaren Einkommens liegen sie hinter Norwegen auf Platz 2 — aber der Abstand zu Deutschland faellt von
+14 % (Durchschnittslohn FTE) auf +16 % (Median verfuegbares Einkommen), schrumpft also nicht. Das ist
ein Befund aus zwei verschiedenen Jahren (2025 gegen 2022) und ersetzt keine saubere Zerlegung; es zeigt
nur, dass "Lohn statt BIP" die Geschichte nicht automatisch dreht.

---

## 5. Luecken — gemeldet, nicht geschaetzt

**L1 — Russland, alle Kennzahlen.** Russland ist nicht OECD-Mitglied. `REF_AREA=RUS` kommt in keiner der
vier verwendeten OECD-Serien vor (AV_AN_WAGE, IDD, FTPT_COMMON_INC, HW). Die Abwesenheit wurde am
2026-09-18 im Rohabruf geprueft, nicht unterstellt. In beiden CSV stehen leere Werte mit
`belegart = nicht geprueft` und einem Luecken-Hinweis in `source_name`. **Kein Ersatzwert, keine Schaetzung
aus Rosstat oder ILO** — das waere eine dritte Messvorschrift im selben Bild.

**L2 — geschlechtsuebergreifender Median der Vollzeit-Ganzjahres-Erwerbseinkommen je Bundesstaat.**
Die Census-API verlangt seit 2026 zwingend einen Schluessel (Abruf ohne Schluessel: HTTP 302 auf eine Seite
"Missing Key", am 2026-09-18 geprueft). Der schluessellose Weg ueber die Table-Based Summary File
funktioniert, enthaelt aber nur *detailed tables* (`acsdt…`), keine *subject tables* (`acsst…`); die Datei
`acsst1y2024-s2001.dat` gibt 404. In B20017 steht Vollzeit/ganzjaehrig nur nach Geschlecht getrennt, und
Mediane lassen sich nicht zu einem Gesamtmedian verrechnen. Beschaffbar waere der Wert ueber einen
Census-API-Schluessel (kostenlos, aber Registrierung) oder ueber den Download aus data.census.gov.
Ausgeliefert sind stattdessen die beiden geschlechtsspezifischen Mediane und der Median ueber alle
Erwerbstaetigen (B20002).

**L3 — ACS-Jahr 2025.** Die ACS-1-Jahres-Daten 2025 waren am 2026-09-18 nicht veroeffentlicht
(Verzeichnis `.../summary_file/2025/` gibt 404). Neuestes Jahr: 2024. Die Bundesstaaten-Mediane sind
deshalb ein Jahr aelter als die QCEW-Durchschnitte.

**L4 — Median verfuegbares Einkommen, Jahr.** 2022 ist das letzte Jahr mit allen zwoelf OECD-Laendern.
Fuer 2023 liegen elf vor (**Daenemark fehlt**), fuer 2024 nur zwei (Finnland, Schweden). Die 2023er-Werte
wurden bewusst nicht genommen, um kein Land aus der Reihe zu verlieren. Wer 2023 braucht: die Werte sind
im Rohabruf vorhanden, Daenemark bleibt eine Luecke.

**L5 — Keine Teilzeitquote je Bundesstaat.** QCEW erhebt keine Arbeitszeitform. Die Verzerrungsrechnung in
Abschnitt 4 arbeitet deshalb mit dem US-Landeswert (12,5 %) und unterstellt implizit, dass sich die
Bundesstaaten darin aehneln. Diese Annahme ist **nicht geprueft**. Sie betrifft die Rangfolge innerhalb der
USA, nicht den Laender-gegen-USA-Vergleich.

---

## 6. Weitere Definitionsfallen, kurz

1. **KKP-Wahl.** Fuer Loehne und Einkommen ist die KKP des privaten Konsums richtig, nicht die BIP-KKP.
   Beide Laender-Reihen erfuellen das: AV_AN_WAGE nutzt laut OECD-Methodendatei Konsum-KKP; beim Median
   wurde ausdruecklich `PPP_PRC` aus demselben IDD-Datensatz verwendet. Die BIP-KKP haette die Laender
   systematisch anders eingeordnet — das ist genau die Verwechslung, die der Serie bisher unterlief.
2. **Preisbasis.** `average_annual_wage_ppp` steht in *konstanten Preisen von 2025*. Da 2025 auch das
   Datenjahr ist, ist der Wert praktisch ein Wert in laufenden Preisen — aber bei einem spaeteren
   OECD-Update wandert das Basisjahr mit, und aeltere Abzuege sind dann nicht mehr vergleichbar.
   Basisjahr also immer mitfuehren.
3. **Brutto gegen netto.** Die OECD-Lohnzahl ist brutto (vor Lohnsteuer und Arbeitnehmerbeitraegen),
   QCEW ebenfalls brutto. Die Paarung ist insoweit sauber. Der Median des verfuegbaren Einkommens ist
   dagegen **nach** Steuern und Transfers — er darf nicht in derselben Achse stehen wie die Loehne.
4. **Personen gegen Haushalte.** Loehne sind je Beschaeftigtem, das verfuegbare Einkommen je
   aequivalenzgewichteter Person im Haushalt. Zwei verschiedene Einheiten.
5. **Aktienoptionen.** QCEW zaehlt ausgeuebte Aktienoptionen als Lohn. In Staaten mit grossen
   Technologie- oder Finanzsektoren (Kalifornien, Washington, New York) hebt das den Durchschnitt in
   Jahren mit starken Kursanstiegen. Die VGR-Lohnsumme behandelt dies grundsaetzlich ebenso; die
   Konjunkturabhaengigkeit bleibt in beiden Reihen.
6. **Mittelwert gegen Median.** `average_annual_wage_*` sind Mittelwerte und damit von der Spitze
   gezogen; die ACS-Werte sind Mediane. Nie in einer Achse mischen.
7. **District of Columbia** ist eine Stadt, kein Flaechenstaat: 128.901 USD, weit ueber jedem Staat, und
   der Nenner enthaelt keine Pendler-Wohnbevoelkerung, sondern Arbeitsplaetze. In Ranglisten separat
   ausweisen (so auch in `wages_us_states.csv` gefuehrt).

---

## 7. Quellen (Abruf durchgehend 2026-09-18)

- OECD Average annual wages — https://sdmx.oecd.org/public/rest/data/OECD.ELS.SAE,DSD_EARNINGS@AV_AN_WAGE,1.0/all?format=csvfilewithlabels
- OECD Methodendatei "Comparable estimates of average wages per full-time equivalent employee" — https://www.oecd.org/els/emp/AVERAGE_WAGES.pdf
- OECD Income Distribution Database — https://sdmx.oecd.org/public/rest/data/OECD.WISE.INE,DSD_WISE_IDD@DF_IDD,/all?format=csvfilewithlabels
- OECD Incidence of part-time employment (harmonisiert) — https://sdmx.oecd.org/public/rest/data/OECD.ELS.SAE,DSD_FTPT@DF_FTPT_COMMON_INC,/all?format=csvfilewithlabels
- OECD Average usual weekly hours worked on the main job — https://sdmx.oecd.org/public/rest/data/OECD.ELS.SAE,DSD_HW@DF_AVG_USL_WK_WKD,/all?format=csvfilewithlabels
- OECD Average annual hours actually worked per worker — https://sdmx.oecd.org/public/rest/data/OECD.ELS.SAE,DSD_HW@DF_AVG_ANN_HRS_WKD,/all?format=csvfilewithlabels
- BLS QCEW Open Data API, Jahresdaten 2025 — https://data.bls.gov/cew/data/api/2025/a/area/06000.csv (Muster) · https://www.bls.gov/cew/
- BLS QCEW Technical Note (Teilzeit-Caveat) — https://www.bls.gov/news.release/cewqtr.tn.htm
- BLS QCEW Questions and Answers (Abdeckung, Lohnbestandteile) — https://www.bls.gov/cew/questions-and-answers.htm
- Census ACS 2024 1-Jahr, Table-Based Summary File B20002 — https://www2.census.gov/programs-surveys/acs/summary_file/2024/table-based-SF/data/1YRData/acsdt1y2024-b20002.dat
- Census ACS 2024 1-Jahr, Table-Based Summary File B20017 — https://www2.census.gov/programs-surveys/acs/summary_file/2024/table-based-SF/data/1YRData/acsdt1y2024-b20017.dat
- Eurostat/ESA 2010 Kapitel 4, Definition D.11 "wages and salaries" — https://ec.europa.eu/eurostat/esa2010/chapter/view/4/
