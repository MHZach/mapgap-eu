# countries_economy_add14 — Notizen, Luecken, Definitionsfallen

Erstellt: 2026-09-18. Ergaenzt den Bestand (`countries_economy.csv`, 16 Laender) um **14 weitere Laender**
in **neuen Dateien**; der Bestand wurde **nicht** angefasst.

- `countries_economy_add14.csv` (143 Datenzeilen)
- `fiscal_debt_deficit_add14.csv` (28 Datenzeilen)

Laender (ASCII, Schreibweise wie beauftragt): Portugal, Niederlande, Belgien, Oesterreich, Ungarn,
Irland, Tschechien, Lettland, Litauen, Estland, Kroatien, Griechenland, Bosnien, Israel.

Spalten identisch zum jeweiligen Bestand:
`metric,country,value,unit,year,source_name,source_url,belegart` bzw. `…,entity,…`.

---

## 1. Vintage-Kontrolle: gleiche Quellstaende wie der Bestand

Vor der Ergaenzung wurde geprueft, ob die Quellen heute noch denselben Stand liefern wie beim
Aufbau des Bestands. **Kontrollwerte stimmen exakt** (belegart: abgelesen):

| Kontrolle | Bestand | heute abgerufen |
|---|---|---|
| IMF NGDPDPC Deutschland 2025 | 60438,8 | 60438,79 |
| IMF NGDPDPC Italien 2025 | 43270,4 | 43270,357 |
| IMF PPPPC Deutschland 2025 | 74004,0 | 74003,998 |
| IMF GGXWDG_NGDP Deutschland 2025 | 62,9 | 62,9 |
| IMF GGXCNL_NGDP USA 2025 | -6,8 | -6,8 |
| UNDP hdi_2023 Deutschland | 0,959 | 0,959 |
| OECD IDD Armut 2022 Deutschland | 11,62 | 11,56/11,62 (AGE=_T: 11,62) |
| OECD PF2.1.A Deutschland Mutterschutz-FRE / gesamt | 14,0 / 38,2 | 14,0 / 38,2 |
| WSI Mindestlohn Deutschland -> USD | 15,96 | 13,90 EUR x 1,1481 = 15,96 |

Damit ist die WEO-Vintage (**April 2026**) und der HDR-/PF2.1-/IDD-Stand identisch. Die
Ergaenzungswerte sind mit dem Bestand vergleichbar.

---

## 2. IRLAND — Sonderfall Gewinnverlagerung (Pflichtabschnitt)

**Das Problem.** Irlands nominales BIP je Kopf 2025 betraegt nach IWF WEO April 2026
**130.652,4 USD** — hoeher als jedes andere Land dieser Liste und hoeher als jedes Land im Bestand
(zum Vergleich: USA 89.991, Niederlande 73.833, Deutschland 60.439). Diese Zahl misst nicht den
Wohlstand der in Irland lebenden Menschen. Sie misst zu einem grossen Teil Buchungsvorgaenge
multinationaler Konzerne: in Irland domizilierte geistige Eigentumsrechte, Flugzeug-Leasingkapital
und einbehaltene Gewinne redomizilierter Unternehmen. Diese Groessen erhoehen das in Irland
gemessene BIP, ohne dass ihnen irisches Einkommen gegenuebersteht.

**Die irische Antwort.** Das Central Statistics Office (CSO) publiziert deshalb seit der Empfehlung
der Economic Statistics Review Group das **modifizierte Bruttonationaleinkommen, GNI\*
("modified GNI")**, das genau diese Effekte herausrechnet.

**Abgelesene Werte** (CSO, Annual National Accounts 2025, Abschnitt "GNI\* and De-Globalised Results",
abgerufen 2026-09-18):

| Groesse | 2024 | 2025 |
|---|---|---|
| GNI\* zu laufenden Marktpreisen | 321.636 Mio EUR | **333.971 Mio EUR** |
| BIP zu laufenden Marktpreisen | 561.940 Mio EUR | **602.441 Mio EUR** |
| GNI\* als Anteil am BIP | 57,2 % | **55,4 %** |

**Der Faktor.** GNI\*/BIP 2025 = 333.971 / 602.441 = **0,55436**. BIP und GNI\* liegen damit um den
**Faktor 1,80** auseinander. Anders gesagt: **rund 45 Prozent der irischen Wirtschaftsleistung, wie
sie das BIP ausweist, verschwinden, sobald man die Globalisierungseffekte herausrechnet.**

**Abgeleitete Kennzahl im Datensatz** (`gni_star_pro_kopf_irland`, belegart: berechnet):
130.652,4 USD x 0,55436 = **72.428,8 USD** je Kopf 2025.
Damit faellt Irland von Rang 1 dieser 14 Laender auf ein Niveau zwischen Oesterreich (63.161 USD)
und den Niederlanden (73.833 USD) zurueck.

*Rechenweg-Vorbehalt (offen ausgewiesen):* Die Direktrechnung aus dem CSO-Absolutwert ergibt
333.971 Mio EUR / 5,497 Mio Einwohner (IWF-LP 2025) = **60.755 EUR je Kopf**. Die Umrechnung dieser
EUR-Groesse in USD haengt vom gewaehlten Jahresdurchschnittskurs ab; der aus IWF-Angaben implizierte
Kurs (0,8388 EUR/USD) weicht von den gaengigen 2025er Jahresmitteln ab, was auf leicht abweichende
BIP-Niveaus zwischen IWF und CSO hindeutet. Deshalb wird die **verhaeltnisbasierte** Variante
gefuehrt: sie haelt die Nenner-Konvention aller uebrigen Pro-Kopf-Werte konstant und ist gegen
Wechselkurswahl unempfindlich. Die EUR-Direktzahl ist hier dokumentiert, damit der Unterschied
sichtbar bleibt.

### Luxemburg-artige Verzerrung bei anderen Laendern — geprueft, nicht angenommen

Gemessen wurde Weltbank GNI je Kopf (Atlas-Methode, `NY.GNP.PCAP.CD`) gegen BIP je Kopf
(laufende USD, `NY.GDP.PCAP.CD`), abgerufen 2026-09-18. **Methodenbruch offen ausgewiesen:** die
Atlas-Methode glaettet den Wechselkurs ueber drei Jahre, das BIP je Kopf nicht — die Verhaeltnisse
taugen daher fuer die Groessenordnung, nicht fuer Nachkommastellen.

| Land | GNI/BIP 2023 | GNI/BIP 2024 | Befund |
|---|---|---|---|
| Luxemburg (Referenz) | 0,664 | 0,614 | staerkster Keil der Vergleichsgruppe |
| **Irland** | **0,742** | **0,714** | starker Keil; GNI\* (0,554) noch deutlich staerker |
| **Niederlande** | **0,985** | **0,926** | **kein** Irland-artiger Keil |
| **Belgien** | **1,005** | **0,977** | **kein** Irland-artiger Keil |
| Oesterreich | 0,988 | 0,940 | kein Keil |
| Deutschland | 1,012 | 0,982 | kein Keil (Kontrollgruppe) |

**Antwort auf die gestellte Frage:** Niederlande und Belgien haben zwar hohe Konzernpraesenz, aber
**keinen vergleichbaren Keil**. Ihr GNI liegt 2023 bei 98,5 % bzw. 100,5 % des BIP — im selben Band
wie Deutschland (101,2 %). Der Rueckgang beider Laender 2024 (0,926 / 0,977) liegt in derselben
Groessenordnung wie bei Deutschland (0,982) und Oesterreich (0,940) und ist damit eher ein Effekt
der Atlas-Glaettung als ein Verlagerungssignal. Bei Irland sind es 74,2 % (GNI) bzw. **55,4 %
(GNI\*)** — eine andere Groessenordnung. **Luxemburg ist auf der GNI/BIP-Achse sogar staerker
verzerrt als Irland**; Luxemburg gehoert nicht zur beauftragten Liste und wurde nur als Referenz
gemessen.

*Nicht geprueft:* ob fuer Niederlande oder Belgien eine CSO-analoge amtliche "modified"-Reihe
existiert. Es wurde keine gefunden, es wurde aber auch nicht systematisch danach gesucht.

---

## 3. BOSNIEN — ausdruecklich geprueft, nicht angenommen

Auftragsgemaess wurde jede Reihe fuer Bosnien **einzeln abgefragt**, nicht unterstellt.

| Reihe | Befund | Beleg |
|---|---|---|
| IWF WEO (BIP nom., BIP KKP, Schulden, Defizit) | **vorhanden** | BIH 2025: 9.567,7 USD / 22.886,9 Int$ / 29,9 % / -2,4 % |
| UNDP HDR 2025 | **vorhanden** | hdi_2023 = 0,804 (Rang 74) |
| OECD Family Database PF2.1.A | **fehlt** | BIH ist weder OECD- noch EU-Mitglied; Tabelle PF2.1.A fuehrt OECD-Laender plus BGR/HRV/CYP/MLT/ROU. BIH nicht enthalten. |
| OECD Income Distribution Database | **fehlt** | SDMX-Abfrage mit `REF_AREA` inkl. BIH liefert BIH nicht in der Ergebnisliste zurueck (zurueckgegeben: AUT, BEL, CZE, DEU, EST, GRC, HRV, HUN, IRL, ISR, LTU, LVA, NLD, PRT). |
| WSI-Mindestlohnreihe | **fehlt** | WSI Report Nr. 111, Abb. 1 fuehrt im Block "Sonstiges Europa" Serbien, Nordmazedonien, Tuerkei, Albanien, Moldawien, Russland, Ukraine — **Bosnien nicht**. |
| Mindesturlaub | **vorhanden, aber Entitaetsrecht** | 20 Arbeitstage; Art. 47 Zakon o radu FBiH bzw. entsprechende Norm Republika Srpska |

**Die Erwartung der Aufgabenstellung hat sich bestaetigt**, mit einer Praezisierung: Bosnien fehlt
nicht nur in den OECD-Reihen, sondern auch in der WSI-Mindestlohnreihe. IWF und UNDP fuehren
Bosnien wie erwartet.

**Mindestlohn Bosnien — warum keine Zahl eingetragen wurde.** Bosnien-Herzegowina hat **keinen
staatsweiten Mindestlohn**. Er wird getrennt in den beiden Entitaeten festgesetzt: die Foederation
BiH fuehrt einen einheitlichen **Netto-Monatsbetrag**, die Republika Srpska seit 2025 ein nach
Qualifikationsstufen **gestaffeltes** System. Beide sind Nettogroessen je Monat und lassen sich ohne
Annahmen ueber Abgabenquote und Monatsstunden nicht in die Brutto-Stundenlohn-Systematik der
WSI-Reihe ueberfuehren. Die aufgefundenen Betraege stammen ausserdem ausschliesslich aus
Aggregator-Blogs, nicht aus den Amtsblaettern. **Deshalb: `keine_vergleichbare_quelle`,
belegart `nicht geprüft` — nicht geschaetzt.**

---

## 4. Definitionsfallen

### 4.1 Mindestlohn: Laender ohne gesetzlichen Mindestlohn

**Oesterreich hat keinen gesetzlichen Mindestlohn** und traegt deshalb — wie Italien im Bestand —
`kein_gesetzlicher_mindestlohn`, **nicht** `null` und **nicht** `0`.

Doppelt belegt:
1. **Negativ:** Oesterreich fehlt in der Laenderliste der gesetzlichen Mindestloehne (WSI Report
   Nr. 111, Abb. 1). Die EU-Liste dort umfasst 22 Mitgliedstaaten; die fuenf fehlenden sind
   Daenemark, Italien, Oesterreich, Finnland, Schweden.
2. **Positiv:** Bundesministerium fuer Arbeit (sozialministerium.gv.at), Wortlaut:
   *"In contrast to other EU member states, there is no statutory minimum wage in Austria."*
   Lohnuntergrenzen laufen ueber Kollektivvertraege (ueber 800 KV, ca. 95 % der Beschaeftigten
   erfasst).

Von den 14 neuen Laendern ist **Oesterreich der einzige** Fall dieser Art. Die uebrigen zwoelf
EU-Laender der Liste haben gesetzliche Mindestloehne; Israel ebenfalls; Bosnien siehe oben.

### 4.2 Mindestlohn: Umrechnungskurs und Stichtag

- **Wertstichtag: 1. Januar 2026** (Spalte `year` = `2026-01-01`, wie im Bestand).
- **Umrechnungsstichtag: 17. September 2026** — identisch zum Bestand, damit die Reihe
  einheitlich bleibt.
- **Kurs:** EZB Euro-Referenzkurse, 2026-09-17: **1 EUR = 1,1481 USD**, **1 EUR = 3,4825 ILS**,
  daraus **1 ILS = 0,329678 USD**.
- Gegenprobe gegen den Bestand: Deutschland 13,90 EUR x 1,1481 = 15,96 USD — Bestandswert ist
  15,96. Spanien 8,63 x 1,1481 = 9,91 — Bestandswert ist 9,91. Kurs bestaetigt.
- Die EUR-Originalwerte sind zusaetzlich als `mindestlohn_eur_pro_stunde_stand_2026_01_01`
  gefuehrt (wie im Bestand fuer einige Laender).

**Griechenland-Falle:** WSI weist 5,93 EUR zum 1.1.2026 aus, **6,20 EUR ab 1.4.2026**. Eingetragen
ist der am Stichtag geltende Wert (5,93 EUR = 6,81 USD). Analog im Bestand fuer Rumaenien.

**Israel-Falle (gleiche Bauart):** Zum 1.1.2026 gilt 6.248 ILS/Monat; die Erhoehung auf
6.443,85 ILS wirkt **erst zum 1.4.2026** und wurde **nicht** verwendet. Stundensatz = 6.248 / 186
(Teiler 186 Monatsstunden, Privatsektor, 42-Stunden-Woche) = 33,59 ILS = **11,07 USD**.
*Quellenguete-Vorbehalt:* ueber cwsisrael.com und Jerusalem Post referiert; die amtliche
gov.il-Seite war nicht erreichbar, kolzchut.org.il lieferte HTTP 403. Rechtsgrundlage:
Minimum Wage Law 5747-1987.

**14-Gehaelter-Falle:** WSI beruecksichtigt bei der Monats-zu-Stunden-Umrechnung, dass
Beschaeftigte in **Griechenland und Portugal** (sowie Spanien im Bestand) Anspruch auf 14
Gehaelter pro Jahr haben. Wer selbst aus Monatsbetraegen rechnet, kommt fuer diese Laender auf
zu niedrige Stundensaetze.

### 4.3 Elternzeit: Full-Rate-Equivalent ist nicht Dauer

`mutterschutz_full_rate_equivalent_wochen` und `bezahlte_gesamtfreistellung_mutter_fre_wochen`
sind **Full-Rate-Equivalent**-Wochen: Dauer x Lohnersatzrate. Sie sind **nicht** die Zahl der
Freistellungswochen.

Der Unterschied ist gross und kehrt Rangfolgen um:

- **Irland:** 26 Wochen Mutterschutz, aber nur 23,4 % Lohnersatz -> **6,1 FRE-Wochen**. Nach
  Kalenderdauer liegt Irland vorn, nach FRE am Ende dieser 14 Laender.
- **Griechenland:** 56 Wochen bei 59,5 % -> 33,3 FRE-Wochen.
- **Portugal:** nur 6 Wochen bei 100 % -> 6,0 FRE-Wochen (Portugals uebrige Freistellung laeuft
  ueber "parental leave", daher gesamt 22,3).
- **Estland:** 14,3 Mutterschutz-FRE, aber **82,1** Gesamt-FRE — hoechster Wert der 14.
- **Israel:** 15,0 / 15,0; die **elf unbezahlten** Mutterschutzwochen sind in der OECD-Zahl
  **nicht** enthalten (OECD-Anmerkung explizit). Israel hat nach dieser Tabelle **0,0** Wochen
  vaterspezifische Freistellung.

Beide Spalten stammen aus **Tabelle PF2.1.A, Spalte (3) und Spalte (9)**, Stand **April 2025**
(`year` = 2025, wie im Bestand).

### 4.4 Mindesturlaub: drei verschiedene Einheiten im Gesetzestext

Die nationalen Normen zaehlen in **Arbeitstagen**, **Werktagen (6-Tage-Basis)** oder
**Kalendertagen**. Der Bestand normalisiert auf eine 5-Tage-Woche; das wurde uebernommen:

| Land | Gesetzliche Einheit | Rechenweg | Wert (5-Tage-Basis) |
|---|---|---|---|
| Portugal | 22 dias uteis (Arbeitstage) | bereits Arbeitstage | **22,0** |
| Oesterreich | 30 Werktage (6-Tage-Basis) | 30 x 5/6 | **25,0** |
| Belgien | 24 Tage (6-Tage-Regime) | 24 x 5/6 | **20,0** |
| Estland | **28 Kalendertage** | 28 x 5/7 | **20,0** |
| Niederlande | 4 x Wochenarbeitstage | 4 x 5 | **20,0** |
| Irland, Tschechien, Lettland, Kroatien | 4 Wochen | 4 x 5 | **20,0** |
| Ungarn, Litauen, Griechenland, Bosnien | Arbeitstage | bereits Arbeitstage | **20,0** |
| Israel | 16 Tage Gesamtanspruch | davon 12 Arbeitstage bei 5-Tage-Woche | **12,0** |

**Fallen in dieser Spalte:**
- **Estland** sieht mit "28 Tagen" grosszuegig aus, liegt nach Normalisierung aber auf dem
  EU-Mindestniveau von 20 Arbeitstagen. Wer Kalendertage gegen Arbeitstage stellt, ueberschaetzt
  Estland um 40 Prozent.
- **Oesterreich** ist mit 25 Tagen das einzige Land der 14 ueber dem EU-Mindestniveau ausser
  Portugal (22).
- **Israel** liegt mit 12 Arbeitstagen als einziges Land **unter** dem EU-Mindestniveau — Israel
  ist nicht an die EU-Arbeitszeitrichtlinie gebunden.
- **Gesetzlicher Mindestanspruch, nicht tatsaechlicher Urlaub.** In Ungarn steigt der Anspruch mit
  dem Lebensalter auf bis zu 30 Tage, in Griechenland mit den Dienstjahren auf 25, in Litauen gibt
  es 26 Tage nach laengerer Dienstzeit. Der Datensatz fuehrt den **Grundanspruch**.
- **Feiertage sind nicht enthalten.**

**QUELLENGUETE DIESER SPALTE — schwaechste Spalte des Datensatzes.**
Eurofound, die vom Bestand bevorzugte Einheitsquelle, war auch am 2026-09-18 nicht abrufbar
(**HTTP 429**, erneut geprueft — dasselbe Problem, das der Bestand dokumentiert). Die nationalen
Gesetzesportale blockierten ebenfalls (irishstatutebook.ie HTTP 403; riigiteataja.ee laedt den
Paragraphentext per JavaScript nach und liefert nur den Seitenrahmen). Die Werte stammen deshalb
aus einer **tertiaeren Vergleichstabelle** (Wikipedia, "List of minimum annual leave by country",
dort mit Primaernorm belegt), quergelesen gegen die Recherchetreffer zu den einzelnen
Primaernormen. **Die Primaernorm ist je Land in `source_name` benannt, ihr Volltext wurde in
keinem Fall geoeffnet.** Dieselbe Einschraenkung gilt bereits im Bestand fuer Polen, Italien und
Spanien. belegart = `berechnet` (Normalisierung), die Quellenschwaeche steht im Klartext in
`source_name`.
Portugal fehlt in der tertiaeren Tabelle; die 22 dias uteis stammen aus den Recherchetreffern zu
Art. 238 Codigo do Trabalho (informador.pt, sabiasque.pt), ebenfalls ohne Volltext.

### 4.5 Armut und Median-Einkommen: abweichende Erhebungsjahre

Der Bestand fuehrt **2022**. Das gilt auch hier fuer elf Laender. **Zwei Ausnahmen:**

- **Ungarn: 2023.** In der Definition `D_CUR` (die der Bestand nutzt) liegt fuer Ungarn ueberhaupt
  nur 2023 vor.
- **Israel: 2023.** Israel hat 2022 nur unter der Definition `D_INC`, nicht `D_CUR`. Ein Wechsel auf
  `D_INC` haette das Erhebungsjahr gerettet, aber die **Definition gebrochen** — das waere der
  groessere Fehler. Deshalb 2023 mit `D_CUR`.

Beide Faelle sind in `source_name` der betroffenen Zeilen ausgewiesen und die Spalte `year` traegt
2023, nicht 2022. **Beim Querschnittsvergleich duerfen diese beiden Laender nicht stillschweigend
als 2022-Werte gelesen werden.**

**Median-Umrechnung.** Wie im Bestand: Median in Landeswaehrung geteilt durch den OECD-Jahresmittel-
kurs (`DSD_NAMAIN10@DF_TABLE4`, `TRANSACTION=EXC_A`, Landeswaehrung je USD). Verwendete Kurse:
EUR-Laender 2022 = 0,949624; CZE 2022 = 23,357; **HRV 2022 = 0,950261**; HUN 2023 = 353,088333;
ISR 2023 = 3,667375.

**Kroatien-Falle:** Kroatien hat den Euro erst zum 1.1.2023 eingefuehrt, die OECD fuehrt die
IDD-Reihe aber auch fuer 2022 bereits in **Euro** (Median 2022 = 11.531,72) und weist einen
EUR-nahen Kurs 0,950261 aus. Wer hier mit einem HRK-Kurs (rund 7,5 HRK/USD) rechnet, erhaelt einen
um den Faktor acht zu niedrigen Wert.

**Definitionsfalle Armutsquote:** `armutsquote_50pct_median` ist die **relative** Armutsquote —
Anteil unterhalb 50 % des jeweils **nationalen** Medians. Sie misst Ungleichheit im Land, nicht
Lebensstandard. Lettland (16,86 %) und Estland (16,17 %) liegen ueber Griechenland (11,16 %),
obwohl ihr Median-Einkommen hoeher ist. Israel hat mit **17,17 %** die hoechste Quote der 14 bei
einem BIP je Kopf ueber 60.000 USD.

### 4.6 Nominal gegen KKP

Bei den ost- und suedosteuropaeischen Laendern der Liste liegen die beiden BIP-Reihen weit
auseinander — Ungarn 25.826 USD nominal gegen 48.239 Int\$ KKP (Faktor 1,87), Kroatien 27.376
gegen 51.593 (1,88), Tschechien 35.678 gegen 60.247 (1,69). Bei Irland und Israel ist es
umgekehrt eng bzw. invertiert: **Israel 60.335 nominal gegen 56.528 KKP — das einzige Land der 14,
dessen KKP-Wert UNTER dem nominalen liegt** (hohes Preisniveau). Nominal- und KKP-Rangfolgen
duerfen nicht gemischt werden.

---

## 5. Luecken — vollstaendige Liste

| Land | Reihe | Grund | Eingetragener Wert / belegart |
|---|---|---|---|
| Bosnien | `mindestlohn_usd_pro_stunde` | kein staatsweiter Mindestlohn; Entitaetsrecht, Netto-Monatsbetraege, RS gestaffelt; in WSI-Reihe nicht gefuehrt | `keine_vergleichbare_quelle` / nicht geprüft |
| Bosnien | `mutterschutz_full_rate_equivalent_wochen` | nicht in OECD PF2.1.A (weder OECD- noch EU-Mitglied) | `nicht_in_quellreihe_enthalten` / nicht geprüft |
| Bosnien | `bezahlte_gesamtfreistellung_mutter_fre_wochen` | dito | `nicht_in_quellreihe_enthalten` / nicht geprüft |
| Bosnien | `armutsquote_50pct_median` | nicht in OECD IDD (SDMX-Abfrage geprueft) | `nicht_in_quellreihe_enthalten` / nicht geprüft |
| Bosnien | `median_verfuegbares_einkommen_aequiv_netto` | dito | `nicht_in_quellreihe_enthalten` / nicht geprüft |
| Oesterreich | `mindestlohn_usd_pro_stunde` | **keine Luecke, sondern Sachverhalt:** kein gesetzlicher Mindestlohn | `kein_gesetzlicher_mindestlohn` / abgelesen |

Weitere **Einschraenkungen ohne Luecke** (Wert vorhanden, Guete gemindert):

1. **Mindesturlaub, alle 14 Laender** — tertiaere Quelle, Primaernorm benannt aber nicht geoeffnet
   (Abschnitt 4.4). Schwaechste Spalte.
2. **Israel Mindestlohn** — ueber Sekundaerpresse referiert, amtliche Quelle nicht erreichbar.
3. **Ungarn und Israel Armut/Median** — Erhebungsjahr 2023 statt 2022.
4. **Irland GNI\* je Kopf** — verhaeltnisbasiert gerechnet; Direktrechnung weicht ab (Abschnitt 2).
5. **GNI/BIP-Kontrolle NLD/BEL/IRL/AUT** — Atlas-Methode gegen laufende USD, Methodenbruch.

---

## 6. Belegart-Verteilung

- `abgelesen` — IWF WEO (BIP nom., BIP KKP, Schulden, Defizit), UNDP HDI, OECD PF2.1-FRE-Wochen,
  OECD-IDD-Armutsquoten, WSI-EUR-Originalwerte, Oesterreich-Mindestlohnstatus, CSO GNI\*/BIP-Quote.
- `berechnet` — Mindestlohn in USD (Kursumrechnung), Median-Einkommen in USD (Kursumrechnung),
  Mindesturlaub (Normalisierung auf 5-Tage-Woche), Irland GNI\* je Kopf, GNI/BIP-Kontrollen.
- `nicht geprüft` — die fuenf Bosnien-Luecken (Abwesenheit aus der Quellreihe wurde geprueft; der
  **Wert** ist nicht ermittelt und wurde nicht geschaetzt).
- `inferiert` / `angenommen` — **kommen im Datensatz nicht vor.** Es wurde kein Wert geschaetzt.

**Keine einzige Zahl stammt aus dem Gedaechtnis.** Jeder Wert wurde in dieser Sitzung aus der in
`source_url` genannten Quelle abgerufen.

---

## 7. Abrufprotokoll (alle 2026-09-18)

| Quelle | Zugriff | Ergebnis |
|---|---|---|
| IMF DataMapper API (NGDPDPC, PPPPC, GGXWDG_NGDP, GGXCNL_NGDP, LP) | curl, JSON | OK, alle 14 Laender inkl. BIH |
| UNDP HDR 2025 Composite Indices CSV | curl | OK (Encoding latin-1, nicht UTF-8) |
| OECD IDD, SDMX-CSV | curl | OK; Schluessel hat **9** Dimensionen |
| OECD PPP/Wechselkurse, DSD_NAMAIN10@DF_TABLE4 | curl | OK |
| OECD Family Database PF2.1 PDF | curl + pdftotext -layout | OK, Tabelle PF2.1.A gelesen |
| WSI Report Nr. 111 PDF | WebFetch + pdftotext -layout | OK, Abbildung 1 gelesen |
| EZB eurofxref-hist-90d.xml | curl | OK, 2026-09-17: USD 1,1481 / ILS 3,4825 |
| CSO Ireland, Annual National Accounts 2025 | WebFetch | OK |
| Weltbank API (NY.GNP.PCAP.CD, NY.GDP.PCAP.CD) | curl | OK |
| sozialministerium.gv.at, Minimum Wage in Austria | WebFetch | OK |
| **Eurofound** | curl HEAD | **HTTP 429** (wie im Bestand) |
| **irishstatutebook.ie** | WebFetch | **HTTP 403** |
| **riigiteataja.ee** | WebFetch | nur Seitenrahmen, Text per JS |
| **kolzchut.org.il** | WebFetch | **HTTP 403** |
