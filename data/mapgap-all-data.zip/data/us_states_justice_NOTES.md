# US-Bundesstaaten — Vergleichsbasis Gewalt / Justiz / Verkehr

Datei: `us_states_justice.csv` (356 Zeilen = 51 Gebietseinheiten x 7 Kennzahlen, minus 1 fehlender DC-Wert bei `imprisonment_rate_state_prison_only`).
Erstellt am 2026-09-18. Alle Werte maschinell aus den Primaerquellen gezogen (kein Wert aus dem Gedaechtnis ergaenzt, keine Schaetzung).

Spalte `belegart`: durchgaengig **abgelesen** — jeder Wert steht so in der Quelldatei/Quelltabelle.
Ein Eingriff (Georgia) ist unten unter „Eingriffe" dokumentiert; die Min/Median/Max-Zeile ist berechnet.

## Min / Median / Max ueber die 50 Bundesstaaten (DC separat)

| Kennzahl | n/50 | Min | Median | Max | DC (nicht in den 50) |
|---|---|---|---|---|---|
| 1. Toetungsdelikte gesamt (alle Tatmittel), CDC 2024 | 50/50 | 1.3 (New Hampshire) | 5.35 | 18.6 (Mississippi) | 25.3 |
| 2a. Schusswaffentote gesamt (alle Intentionen), CDC 2024 | 50/50 | 3.9 (Hawaii) | 14.6 | 27.6 (Mississippi) | 21.8 |
| 2b. davon Suizid, CDC 2024 | 50/50 | 2.2 (Hawaii) | 10.0 | 21.1 (Wyoming) | 1.9 |
| 2c. davon Toetung, CDC 2024 | 50/50 | 0.8 (New Hampshire) | 3.9 | 16.0 (Mississippi) | 19.7 |
| 3a. Inhaftierte gesamt (prison + jail + federal + uebrige), PPI 2024 | 50/50 | 241 (Massachusetts) | 608.0 | 1067 (Louisiana) | 816 |
| 3b. nur state prison (verurteilte Gefangene), BJS 2023 | 50/50 | 96 (Massachusetts) | 299.5 | 652 (Mississippi) | keine Angabe |
| 4. Verkehrstote, IIHS/FARS 2024 | 50/50 | 4.7 (Rhode Island) | 11.95 | 25.6 (Mississippi) | 6.7 |

Median: Median der 50 Staaten, DC ausgeschlossen. Belegart der Zeile: **berechnet** (aus den abgelesenen 50 Werten).

## Quellen je Kennzahl

| Kennzahl(en) im CSV | Quelle | Jahr | URL |
|---|---|---|---|
| `homicide_rate_all_methods`, `firearm_deaths_total`, `firearm_deaths_suicide`, `firearm_deaths_homicide` | CDC NCIPC/NCHS, NVSS — Datensatz „Mapping Injury, Overdose, and Violence - State" (fpsi-y8tj), Socrata-API, `period=2024` | 2024 | https://data.cdc.gov/d/fpsi-y8tj |
| `incarceration_rate_prison_jail_total` | Prison Policy Initiative, „States of Incarceration: The Global Context 2024", Appendix 1 (Emily Widra, Juni 2024) | Publikation 2024, Datenvintage 2019–2024 | https://www.prisonpolicy.org/global/appendix_states_2024.html |
| `imprisonment_rate_state_prison_only` | BJS, „Prisoners in 2023 – Statistical Tables" (NCJ 310197), Tabelle 7, Spalte „Total" 2023 | 2023 | https://bjs.ojp.gov/document/p23st.zip |
| `traffic_deaths_rate` | IIHS/HLDI, „Fatality Facts: State by state" (Basis NHTSA FARS 2024) | 2024 | https://www.iihs.org/topics/fatality-statistics/detail/state-by-state |

## Definitionsfallen

**F1 — FBI-Mordrate ist NICHT die CDC-Mordrate.**
Im CSV steht die CDC-Groesse: Toetungsdelikte laut Totenschein (NVSS, ICD-10 X85–Y09), gezaehlt nach **Wohnsitz** des Opfers, Vollerhebung.
Die FBI-Groesse (UCR/NIBRS, „murder and nonnegligent manslaughter") zaehlt nach **Tatort**, stammt aus **freiwilligen** Meldungen der Polizeibehoerden und haengt damit von der Meldebeteiligung im jeweiligen Staat ab. Die FBI-Zahl liegt fuer die USA insgesamt regelmaessig unter der CDC-Zahl. Beide Reihen duerfen nicht gemischt oder gegeneinander verrechnet werden. Fuer einen Laendervergleich (andere Laender melden i.d.R. Todesursachenstatistik an WHO/UNODC) ist die CDC-Groesse die besser passende.

**F2 — CDC-Raten sind Rohraten, nicht altersstandardisiert.**
Nachgerechnet (belegart: berechnet): Arizona `FA_Deaths` 1.331 Tote / 7.431.344 Einwohner = 17,91 → veroeffentlicht 17,9. California 2.853 / 39.128.162 = 7,29 → 7,3. Wyoming 143 / 584.057 = 24,48 → 24,5.
Das ist wichtig, weil die bekannte CDC-Seite „Stats of the States" **altersstandardisierte** Raten zeigt — die Zahlen dort weichen leicht ab und sind mit den hier gelieferten nicht identisch. Fuer den Laendervergleich ist die Rohrate die richtige Groesse.

**F3 — Schusswaffentote mit/ohne Suizid.**
`firearm_deaths_total` enthaelt ALLE Intentionen: Suizid, Toetung, Unfall, polizeiliche Gewaltanwendung, unbestimmt. Suizid + Toetung ergeben deshalb NICHT die Gesamtzahl (geprueft: in keinem Staat uebersteigt die Summe den Gesamtwert). Die Differenz betraegt ueber die 50 Staaten 0,0 bis 1,9 je 100.000 (Median 0,5) — belegart: berechnet aus den abgelesenen Werten.
Groessenordnung: Der Median der Suizidrate (10,0) ist rund 2,5-mal so hoch wie der Median der Toetungsrate mit Schusswaffe (3,9). Wer „Schusswaffentote" ohne Zusatz zeigt, zeigt ueberwiegend Suizide. DC ist der Umkehrfall: Suizid 1,9, Toetung 19,7.

**F4 — prison-only vs. prison+jail.**
`imprisonment_rate_state_prison_only` (BJS) = **verurteilte** Gefangene unter Zustaendigkeit der **einzelstaatlichen** Gefaengnisbehoerde, je 100.000 Einwohner aller Altersgruppen. Nicht enthalten: Untersuchungshaft/local jails, Bundesgefaengnisse, Jugendhaft, Einwanderungshaft, zivile Unterbringung.
`incarceration_rate_prison_jail_total` (PPI) = state prison + local jails + Jugendhaft + Indian Country jails + civil commitment + forensische Psychiatrie + Bundesgefaengnisse + Einwanderungshaft + Militaerhaft.
Der Unterschied ist gross: Median 299,5 (prison-only) gegen 608 (Gesamt) — Faktor ~2. **Fuer den Laendervergleich ist die PPI-Gesamtrate die richtige Groesse**, weil internationale Inhaftierungsraten (World Prison Brief) ebenfalls Untersuchungshaft einschliessen.

**F5 — Sechs Staaten haben kein getrenntes Jail-System.**
Alaska, Connecticut, Delaware, Hawaii, Rhode Island, Vermont fuehren prison und jail als ein System (BJS-Fussnote /b). Ihr BJS-„prison"-Wert enthaelt daher bereits Teile der Jail-Population und ist mit den anderen 44 Staaten nicht sauber vergleichbar. Betrifft nur `imprisonment_rate_state_prison_only`, nicht die PPI-Gesamtrate. Weitere BJS-Fussnoten (/c bis /g) betreffen Idaho, Missouri, Illinois, Massachusetts, New Jersey, South Dakota, Utah, Maryland, Oklahoma, Nevada; sie sind im CSV nicht mitgefuehrt, im Quell-CSV `p23stt07.csv` aber dokumentiert.

**F6 — PPI rechnet Bundesgefangene den Staaten zu, BJS nicht.**
PPI verteilt die BOP- und U.S.-Marshals-Population per FOIA-Wohnsitzschluessel auf die Staaten. BJS laesst Bundesgefangene in den Staatenraten komplett weg. Die beiden Zeilen im CSV sind deshalb keine „Teilmenge/Obermenge" derselben Erhebung, sondern zwei Methodiken.

**F7 — PPI ist ein Mischvintage, kein Stichjahr.**
State prison: BJS „Prisoners in 2022" (Jahresende 2022). Local jails: Census of Jails 2019, bereinigt um Landesgefangene in Jails aus Tabelle 14 von „Prisoners in 2022". Bundesgefaengnis: BOP-Stand 31.05.2024. U.S. Marshals: Schaetzung Fiskaljahr 2023. Bevoelkerung: 2022. Publiziert Juni 2024. Im CSV steht deshalb `2024 (Publ.; Mischvintage 2019-2024)` — nicht als Erhebungsjahr 2024 lesen.

**F8 — Verkehrstote je Einwohner vs. je Fahrleistung.**
Im CSV steht die Rate je 100.000 **Einwohner** (fuer den Laendervergleich die passende Groesse). Die IIHS-Tabelle enthaelt zusaetzlich die Rate je 100 Mio. Fahrzeugmeilen; die Rangfolge der Staaten ist dort eine andere (z.B. Staaten mit sehr hoher Fahrleistung pro Kopf rutschen nach oben). Nicht mischen.

**F9 — Die Jahre sind nicht einheitlich.**
CDC 2024, IIHS 2024, BJS 2023, PPI Mischvintage. Eine Grafik darf nicht „Stand 2024" ueber alle vier Kennzahlen schreiben.

**F10 — DC ist kein Bundesstaat.**
DC ist in allen Auswertungen separat ausgewiesen und in keinem Min/Median/Max enthalten. DC ist eine reine Stadt ohne laendliches Umland — die Werte sind mit Bundesstaaten strukturell nicht vergleichbar (Toetungsrate 25,3 = hoeher als jeder Bundesstaat; Verkehrstote 6,7 = niedriger als 47 Bundesstaaten, nur 3 liegen darunter).

**F11 — Kleine Fallzahlen.**
Acht CDC-Zellen beruhen auf weniger als 20 Todesfaellen und schwanken von Jahr zu Jahr stark: DC (Schusswaffen-Suizid, n=13), Maine (Schusswaffen-Toetung, 16), New Hampshire (Toetung gesamt 18; Schusswaffen-Toetung 11), North Dakota (11), Rhode Island (12), Vermont (12), Wyoming (11). Diese Werte nicht als Ranking-Aussage („sicherster Staat") verwenden.

## Eingriffe / Abweichungen vom Quelltext

**E1 — Georgia, PPI-Gesamtrate: 881 statt 887.**
Die PPI-Appendix-Tabelle druckt 887. Zaehler und Nenner derselben Zeile (96.171 Inhaftierte / 10.913.150 Einwohner) ergeben 881,2, und PPIs eigener Chart-Datensatz (`2024_chart.js`) fuehrt Georgia mit 881. Uebernommen wurde 881; die Quellenspalte im CSV dokumentiert den Widerspruch. Alle 49 uebrigen Staaten + DC wurden auf Rate = Summe/Bevoelkerung geprueft und sind konsistent (Abweichung < 1,5).

**E2 — DC fehlt bei `imprisonment_rate_state_prison_only`.**
Kein Datenfehler: DC hat seit 2001 kein eigenes Gefaengnissystem; verurteilte DC-Straftaeter sind Bundesgefangene. BJS Tabelle 7 fuehrt DC deshalb nicht. 50/50 Bundesstaaten sind vollstaendig.

## Luecken (nicht geschaetzt, nicht ersetzt)

**L1 — FBI-Mordrate je Bundesstaat: NICHT beschafft.**
Die FBI-CDE-API (`api.usa.gov/crime/fbi/cde/summarized/state/<ST>/homicide`) liefert die Daten, der oeffentliche `DEMO_KEY` ist aber auf ~30 Abrufe/Stunde begrenzt; nur 9 von 51 Staaten kamen durch, deshalb wurde nichts davon uebernommen (Teilmenge waere fuer eine 50-Staaten-Grafik unbrauchbar). Der frueher genutzte Bulk-Download `estimated_crimes_1979_*.csv` liegt in einem abgeschalteten S3-Bucket (HTTP 404, „NoSuchBucket"). Nachholbar mit einem kostenlosen api.data.gov-Schluessel (51 Abrufe). Belegart der Aussage: abgelesen (HTTP-Antworten).

**L2 — BJS „Prisoners in 2024" liegt nicht vor.**
`bjs.ojp.gov/document/p24st.zip` und `p24st.pdf` antworten mit HTTP 404 (geprueft 2026-09-18). Juengster verfuegbarer Jahrgang fuer prison-only ist 2023.

**L3 — Aktuellere PPI-Gesamtrate existiert nicht.**
Der juengste allgemeine PPI-Bericht dieser Reihe ist „The Global Context 2024"; 2025 erschien nur die Frauen-Ausgabe. Kein neuerer prison+jail-Stand je Staat verfuegbar.

**L4 — CDC-Aufteilung nur nach Suizid und Toetung.**
Der Datensatz enthaelt keine getrennten Raten fuer Unfall, polizeiliche Gewaltanwendung und unbestimmte Intention. Diese Restkategorie ist nur als Differenz `total - suicide - homicide` zugaenglich (waere belegart: berechnet) und im CSV bewusst nicht ausgewiesen.

**L5 — Keine Konfidenzintervalle.**
Weder CDC noch BJS/PPI/IIHS liefern in diesen Tabellen Intervalle. Fuer die kleinen Staaten (F11) ist damit keine Unsicherheitsangabe moeglich.
