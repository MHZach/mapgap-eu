# Ergaenzung 3 Laender — Suedafrika · Brasilien · Mexiko

Erstellt am 2026-09-18. **Der Bestand (`countries_*.csv`, `*_add14.csv`) wurde nicht
angefasst.** Neue Dateien:

| Datei | Datenzeilen | + Kopfzeile |
|---|---|---|
| `countries_health_add3.csv` | 25 | 26 |
| `countries_justice_add3.csv` | 22 | 23 |
| `countries_economy_add3.csv` | 22 | 23 |
| `fiscal_debt_deficit_add3.csv` | 6 | 7 |

Spalten, Metriknamen, Einheiten, Quellen und Jahrgaenge sind aus dem Bestand uebernommen.
Die Einheit je Kennzahl wurde maschinell gegen `countries_*.csv` **und** `*_add14.csv`
geprueft — keine Abweichung, keine neue Metrik. Baustein: `ergaenze_add3.py`.

Laenderschreibweise wie beauftragt: **Suedafrika · Brasilien · Mexiko.**

---

## 0. Gegenprobe: dieselbe Reihe wie der Bestand?

Vor jeder Extraktion wurde ein Bestandsland aus demselben Rohabruf mitgezogen und gegen
die vorhandene Zeile verglichen. **Alle Kontrollwerte treffen exakt:**

| Reihe | Kontrolle | Bestand | Nachgezogen |
|---|---|---|---|
| OECD `DF_LE` LFEXP/Y0 2022 | Deutschland | 80.7 / 78.3 / 83 | 80.7 / 78.3 / 83 |
| OECD `DF_LE` | Portugal | 81.8 / 78.9 / 84.5 | 81.8 / 78.9 / 84.5 |
| OECD `DF_MIM` INM NONE 2023 | Portugal | 2.5 | 2.5 |
| WHO GHO `NCD_BMI_30C` 2024 | Deutschland / Portugal | 24.5 / 23.0 | 24.5 / 23.0 |
| World Bank `SH.STA.MMRT` 2022 | Deutschland / Portugal | 4 / 16 | 4 / 16 |
| IMF `NGDPDPC` / `PPPPC` 2025 | Portugal | 32165.9 / 50269.0 | 32165.93 / 50269.01 |
| IMF `GGXWDG_NGDP` / `GGXCNL_NGDP` 2025 | Portugal | 89.9 / 0.3 | 89.9 / 0.3 |
| WHO Mortality, Toetungsdelikte 2019 | Portugal | 90 Faelle, 0.87 | **90 Faelle, 0.87** |
| WHO Mortality, Schusswaffen gesamt/Suizid/Toetung | Portugal | 100 / 71 / 23 | **100 / 71 / 23** |
| UNODC CTS 2019 | Portugal | 0.71 | 0.7058 |
| World Prison Brief 2018 / latest | Portugal | 125 / 120 (1.9.2026) | 125 / 120 (1.9.2026) |
| ITF `DF_SAFETY` FATALITIES 10P5HB 2019 | Portugal | 6.7 | 6.698 |
| Small Arms Survey 2017 | Portugal | 21.3 | 21.3 |
| UNDP HDR 2025 `hdi_2023` | Portugal | 0.89 | 0.89 |
| OECD IDD PL_50 / MEDIAN 2022 | Portugal | 11.2417 / 14372 | 11.2417 / 13647.96 EUR ÷ 0.949624 = 14372 |
| OECD PF2.1.A | Portugal | 6.0 / 22.3 | 6.0 / 22.3 |

Die WHO-Mortalitaets-Gegenprobe ist die wichtigste: Zaehler **und** Rate treffen auf die
Stelle. Damit ist belegt, dass die Codeabgrenzung (CDC-Definition) und die Nennerregel
identisch zum Bestand gesetzt sind.

**Fallstrick beim Nachbau:** die WHO-Laendercodes sind nicht die, die man vermutet.
Portugal ist **4240** (4300 ist die Schweiz), Griechenland ist **4140** (4276 ist
Slowenien). Suedafrika 1430 · Brasilien 2070 · Mexiko 2310 (aus `mort_country_codes`
abgelesen). Die Morticd10-Teildateien sind nach **Jahr** geschnitten, nicht nach Land:
Teil 1 = 1988–2002 · Teil 2 = 2003–2007 · Teil 3 = 2008–2012 · Teil 4 = 2013–2016 ·
**Teil 5 = 2017–2020**. Alle drei Laender melden 2019.

---

## 1. Die OECD-Erwartung — geprueft, nicht vermutet

Die Auftragserwartung lautete: Mexiko ist OECD-Mitglied und steht in den OECD-Reihen,
Brasilien und Suedafrika fehlen dort wahrscheinlich. **Das ist nur zur Haelfte richtig.**

Ausgezaehlt wurde die Dimension `REF_AREA` in jedem heruntergeladenen Rohabruf:

| OECD-Dataflow | Zeilen | REF_AREA-Codes | ZAF | BRA | MEX |
|---|---|---|---|---|---|
| `DSD_HEALTH_STAT@DF_LE` (Lebenserwartung) | 52.241 | 51 | **ja** | **ja** | ja |
| `DSD_HEALTH_STAT@DF_MIM` (Saeuglings-/Muettersterblichkeit) | 11.829 | 51 | **ja** | **ja** | ja |
| `DSD_HEALTH_LVNG@DF_HEALTH_LVNG_BW` (Koerpergewicht) | 6.970 | 50 | **ja** | **ja** | ja |
| `DSD_HEALTH_PROT@DF_HEALTH_PROT` (Versicherung) | 11.803 | 46 | **ja** (Achse) | **ja** (Achse) | ja |
| `DSD_WISE_IDD@DF_IDD` (Einkommensverteilung) | — | 45 | **ja** (Achse) | **ja** | ja |
| `OECD.ITF DSD_INDICATORS@DF_SAFETY` (Verkehrstote) | — | 55 | **nein** | **nein** | **nein** |
| OECD Family Database PF2.1.A (PDF-Tabelle) | — | 38 OECD + 5 EU | **nein** | **nein** | ja |

Zwei Ueberraschungen, beide belegt:

- **Brasilien und Suedafrika stehen in den OECD-Gesundheitsreihen** — als Key Partner bzw.
  Beitrittskandidat. Die erwartete Abwesenheit tritt dort **nicht** ein.
- **Mexiko fehlt in der ITF-Verkehrsreihe**, obwohl es OECD-Mitglied ist. ITF-Meldung ist
  nicht an OECD-Mitgliedschaft gekoppelt (derselbe Befund in umgekehrter Richtung wie bei
  Bosnien im `add14`-Dokument, das in der ITF-Reihe steht, ohne OECD-Mitglied zu sein).

---

## 2. Erfassungsanalyse Todesursachen (WHO Mortality Database 2019) — Kernpunkt

Rohabruf: `morticd10_part5` (Dateistand 22.02.2026), gezogen am 2026-09-18. Gezaehlt wird
`Deaths1` (alle Altersgruppen) ueber Sex 1+2+9, ohne `Admin1`/`SubDiv`.

**Definition der Spalten:** „extern" = ICD-10 **V01–Y34** (Unfaelle, Suizid, Toetung,
unbestimmte Absicht — ohne Y35 legale Intervention, ohne Y36 Krieg, ohne Y40–Y84
medizinische Zwischenfaelle, ohne Y85–Y89 Spaetfolgen). „Y10–Y34" ist der Anteil
**unbestimmter Absicht** daran.

### 2.1 R00–R99 („unzureichend bestimmte Ursache")

| Land | Sterbefaelle | R00–R99 | Anteil | davon R99 | Anteil R99 |
|---|---:|---:|---:|---:|---:|
| **Bosnien** (Vergleichsfall aus `add14`) | 38.829 | 6.299 | **16,22 %** | 4.966 | 12,79 % |
| **Suedafrika** | 461.006 | **72.938** | **15,82 %** | 69.330 | 15,04 % |
| Japan | 1.381.093 | 148.725 | 10,77 % | 15.333 | 1,11 % |
| Portugal | 112.334 | 6.694 | 5,96 % | 4.041 | 3,60 % |
| **Brasilien** | 1.349.801 | **74.978** | **5,55 %** | 48.517 | 3,59 % |
| Deutschland | 939.520 | 37.412 | 3,98 % | 24.066 | 2,56 % |
| USA | 2.854.838 | 47.707 | 1,67 % | 27.184 | 0,95 % |
| **Mexiko** | 729.057 | **9.412** | **1,29 %** | 2.121 | 0,29 % |

Die im Auftrag erwaehnte Bosnien-Zahl (4.966 von 38.829) ist die **R99**-Zahl; ueber das
volle Feld R00–R99 sind es 6.299 (16,22 %). Beide Lesarten stehen oben, damit die
Vergleichsbasis eindeutig ist.

**Suedafrika liegt in der Groessenordnung von Bosnien** und damit unter allen 2019 an die
WHO meldenden Laendern mit ueber 5.000 Sterbefaellen auf Rang 8 (vor Suedafrika nur Oman
42,9 % · VAE 25,1 % · Thailand 22,7 % · Montenegro 21,2 % · Nordmazedonien 20,6 % ·
Sri Lanka 17,7 % · Bosnien 16,2 %). **Mexiko ist das Gegenteil:** 1,29 % ist einer der
niedrigsten Werte des gesamten Datensatzes. Brasilien liegt im Mittelfeld.

### 2.2 Y10–Y34 („unbestimmte Absicht") an den externen Todesfaellen

| Land | extern (V01–Y34) | Y10–Y34 | **Anteil** |
|---|---:|---:|---:|
| Bosnien | 927 | 919 | 99,1 % |
| **Brasilien** | 139.058 | **16.648** | **12,0 %** |
| Polen | 19.350 | 1.916 | 9,9 % |
| **Mexiko** | 80.614 | **6.145** | **7,6 %** |
| Deutschland | 38.922 | 2.232 | 5,7 % |
| **Suedafrika** | 55.924 | **3.028** | **5,4 %** |
| USA | 243.221 | 5.633 | 2,3 % |

Zum Gesamtsterbegeschehen: Brasilien 1,23 % aller Sterbefaelle · Mexiko 0,84 % ·
Suedafrika 0,66 %.

**Brasilien und Mexiko haben also tatsaechlich ein Problem mit unbestimmter Absicht** —
in Brasilien ist rund jeder achte externe Todesfall so kodiert, in Mexiko rund jeder
dreizehnte. Bei Mexiko kommt hinzu, dass dieser Wert die im Auftrag genannten
**Verschwundenen gar nicht enthaelt**: wer nie als Toter registriert wird, taucht in
keiner Sterbeurkundenreihe auf, auch nicht unter Y10–Y34. Die Groesse dieses Effekts ist
hier **nicht geprueft** (das waere das RNPDNO-Register, eine Fremdquelle ausserhalb des
Datensatzes).

### 2.3 Suedafrika: der eigentliche Defekt sitzt nicht in R00–R99

Suedafrika meldet in der WHO-**Liste 103** (3-stellige ICD-Codes), Brasilien und Mexiko in
Liste 104 (4-stellig). Das allein waere handhabbar. Der Befund ist ein anderer — alles
abgelesen, Auszaehlung 2026-09-18:

- **V01–V99 (Transportunfaelle): 6.435 Faelle.** Anders als bei Bosnien (dort 0) ist der
  Verkehrsbereich also besetzt. Rohrate 10,88 je 100.000 — nicht im CSV, weil die
  beauftragte Kennzahl `traffic_deaths_rate` die ITF-Reihe ist (s. L1).
- **Toetungsdelikte X85–Y09 = 7.596 Faelle.** Davon entfallen **6.800 (89,5 %) auf X99
  „Angriff durch scharfen Gegenstand"** und 676 auf Y09 „Angriff durch nicht naeher
  bezeichnete Mittel". Auf die drei Schusswaffen-Codes X93–X95 entfallen **11 Faelle.**
- **Schusswaffen gesamt (CDC-Abgrenzung) = 8.369 Faelle.** Davon stehen **8.340 unter W34
  „Entladung aus sonstiger und nicht naeher bezeichneter Schusswaffe"**, also unter
  *Unfall*. Suizid mit Schusswaffe (X72–X74): 13 Faelle. Toetung mit Schusswaffe
  (X93–X95): 11 Faelle.

Das ist kein Kriminalitaetsbild, das ist ein Kodierungsmuster: **die Waffe wird erfasst,
die Absicht nicht.** Ein Land mit 21.325 polizeilich registrierten Morden weist in der
Sterbeurkundenstatistik 11 Schusswaffentoetungen aus. Die Mechanik ist damit belegt, die
*Ursache* (Standardzuweisung bei fehlender gerichtsmedizinischer Klaerung) ist
**inferiert, nicht belegt**.

**Konsequenz im CSV:** `firearm_deaths_suicide` und `firearm_deaths_homicide` stehen fuer
Suedafrika **nicht** im CSV (Luecke L2) — dieselbe Behandlung wie bei Bosnien im
`add14`-Dokument. Die ausgezaehlten Werte sind hier genannt, damit nichts verschwiegen ist:
13 bzw. 11 Faelle, das waeren 0,02 je 100.000. `homicide_rate_who_mortality` und
`firearm_deaths_total` stehen im CSV, weil sie Groessenordnungen haben, die einen Vergleich
zulassen — aber siehe D-A.

---

## 3. Vollstaendigkeit je Kennzahl

### Gesundheit (11 Bestandskennzahlen)

| Kennzahl | Quelle | Jahr | ZAF | BRA | MEX |
|---|---|---|---|---|---|
| `life_expectancy_at_birth` (+`_male`,`_female`) | OECD `DF_LE` | 2022 | 65.5 / 61.8 / 69 | 74.9 / 71.7 / 78.1 | 75.2 / 72.1 / 78.5 |
| `infant_mortality` | OECD `DF_MIM`, THRESHOLD=NONE | 2023 | 24.4 | 12.5 | 13.4 |
| `adult_obesity` | WHO GHO `NCD_BMI_30C` | 2024 | 31.3 | 30.9 | 37.4 |
| `maternal_mortality` | World Bank `SH.STA.MMRT` | 2022 | 129 | 104 | 45 |
| `adult_obesity_self_reported` | OECD, METHODOLOGY=SR | Jahresmix | 26.5 (**2014**) | 22.4 (2021) | **LUECKE L3** |
| `adult_obesity_measured` | OECD, METHODOLOGY=MSRD | Jahresmix | 30 (2022) | 28.8 (2022) | 36.4 (2024) |
| `health_insurance_coverage` | OECD `DF_HEALTH_PROT`, TPRIBASI | 2020 | **LUECKE L4** | **LUECKE L4** | 72.4 |
| `maternal_mortality_registered` | OECD `DF_MIM`, MATM | 2022 | **LUECKE L5** | **LUECKE L5** | 38.2 |
| `infant_mortality_min22weeks` | OECD, THRESHOLD=WK22 | 2023 | — | — | — |

`infant_mortality_min22weeks` fuehrt fuer keines der drei Laender einen Wert — diese
Zusatzreihe ist auch im Bestand nur duenn besetzt (6 von 14 bei `add14`).

### Gewalt / Justiz / Verkehr (9 Kennzahlen)

| Kennzahl | Quelle | Jahr | ZAF | BRA | MEX |
|---|---|---|---|---|---|
| `homicide_rate_who_mortality` | WHO Mortality | 2019 | 12.85 ⚠ | 20.97 | 28.23 |
| `homicide_rate_unodc` | UNODC CTS | 2019 | 35.79 | 21.24 | 29.15 |
| `firearm_deaths_total` | WHO Mortality | 2019 | 14.15 ⚠ | 16.83 | 21.68 |
| `firearm_deaths_suicide` | WHO Mortality | 2019 | **LUECKE L2** | 0.46 | 0.38 |
| `firearm_deaths_homicide` | WHO Mortality | 2019 | **LUECKE L2** | 14.67 | 20.11 |
| `incarceration_rate_prison_jail_total` | World Prison Brief | 2018 | 286 | 354 | 156 |
| `incarceration_rate_prison_jail_latest` | World Prison Brief | Stichtag je Land | 273 | 439 | 200 |
| `traffic_deaths_rate` | ITF/OECD | 2019 | **LUECKE L1** | **LUECKE L1** | **LUECKE L1** |
| `civilian_firearms_per_100` | Small Arms Survey | 2017 | 9.7 | 8.3 | 12.9 |

### Wirtschaft (10 Kennzahlen)

| Kennzahl | ZAF | BRA | MEX |
|---|---|---|---|
| `bip_pro_kopf_nominal_2025e` | 6769.2 | 10685.7 | 13741.3 |
| `bip_pro_kopf_ppp_2025e` | 16326.3 | 23381.0 | 25681.6 |
| `mindestlohn_usd_pro_stunde` | 1.77 | 1.34 | 2.29 |
| `mindestlohn_eur_pro_stunde_stand_2026_01_01` | **LUECKE L6** | 1.17 | **LUECKE L6** |
| `mutterschutz_full_rate_equivalent_wochen` | **LUECKE L7** | **LUECKE L7** | 12.0 |
| `bezahlte_gesamtfreistellung_mutter_fre_wochen` | **LUECKE L7** | **LUECKE L7** | 12.0 |
| `mindesturlaub_arbeitstage_5tage_basis` | 15.0 | 21.4 | 12.0 |
| `hdi` | 0.741 | 0.786 | 0.789 |
| `armutsquote_50pct_median` | **LUECKE L8** | 19.2313 | 14.9979 |
| `median_verfuegbares_einkommen_aequiv_netto` | **LUECKE L8** | 4315 | 4585 |

### Fiskus

`general_government_gross_debt_pct_gdp` 2025: ZAF 78.6 · BRA 93.3 · MEX 61.8.
`general_government_net_lending_borrowing_pct_gdp` 2025: ZAF −5.8 · BRA −8.1 · MEX −4.9.
Vollstaendig, IWF WEO April 2026.

---

## 4. Luecken

### L1 — ITF-Verkehrstote: alle drei Laender fehlen
`OECD.ITF:DSD_INDICATORS@DF_SAFETY` fuehrt 55 `REF_AREA`-Codes; **ZAF, BRA und MEX sind in
keinem davon** (ausgezaehlt am 2026-09-18, kein fehlender Jahrgang, sondern eine fehlende
Laenderachse). Bei Mexiko ist das entgegen der Erwartung — OECD-Mitgliedschaft traegt hier
nicht. Kein Ersatz eingesetzt.

*Zur Information, nicht im CSV* (andere Quelle, andere Definition — waere ein
Methodenbruch): WHO-Mortalitaet V01–V99 2019, Rohraten auf denselben Nennern wie oben:
Suedafrika 10,88 · Brasilien 15,65 · Mexiko 11,87 je 100.000. Der Bestand fuehrt dafuer
eine eigene Reihe `transport_deaths_rate_who_mortality`, die nicht Teil dieses Auftrags war.

### L2 — Suedafrika, Schusswaffen-Absichtsaufteilung
`firearm_deaths_suicide` (13 Faelle) und `firearm_deaths_homicide` (11 Faelle) sind nicht
im CSV. Begruendung in Abschnitt 2.3. Behandlung analog Bosnien im `add14`-Dokument:
Werte im NOTES genannt, nicht im CSV.

### L3 — Mexiko, `adult_obesity_self_reported`
Die OECD fuehrt fuer Mexiko in `DF_HEALTH_LVNG_BW` **keinen einzigen** SR-Wert
(METHODOLOGY=SR, SEX=_T, MEASURE=SP_OBS: 0 Zeilen, ueber alle Jahre). Nur die
Messreihe MSRD existiert (11 Werte, 2000–2024). Kein Ersatz eingesetzt.

### L4 — Suedafrika und Brasilien, `health_insurance_coverage`
Beide stehen in `DSD_HEALTH_PROT@DF_HEALTH_PROT` auf der Laenderachse, fuehren dort aber
**ausschliesslich `INSURANCE_TYPE=PHINTPHI`** (private Krankenversicherung). Die im
Bestand verwendete Reihe `TPRIBASI` („public and primary voluntary health insurance")
existiert fuer beide **in keinem Jahr**. Das ist keine niedrige Abdeckung, sondern eine
fehlende Reihe — derselbe Fall wie Kroatien im `add14`-Dokument. `PHINTPHI` einzusetzen
waere ein Definitionsbruch und wuerde beide Laender faelschlich ans untere Ende stellen.

### L5 — Suedafrika und Brasilien, `maternal_mortality_registered`
`MEASURE=MATM` in `DF_MIM`: fuer ZAF und BRA **keine Zeile in keinem Jahr**. Die
modellierte MMEIG-Reihe (`maternal_mortality`) ist fuer beide vorhanden und im CSV.

### L6 — `mindestlohn_eur_pro_stunde_stand_2026_01_01` fuer ZAF und MEX
Diese Reihe traegt im Bestand ausdruecklich den WSI-Originalwert vor Umrechnung. Der
**WSI-Mindestlohnbericht 2026 fuehrt Suedafrika und Mexiko nicht** (PDF-Volltext geprueft:
6 Treffer auf „Brasil…", null auf „Mexik…"/„Suedafrik…"/„Südafrik…"). Fuer diese beiden
gibt es also keinen WSI-Euro-Originalwert; die Zeile fehlt, statt einen selbst gerechneten
Euro-Wert als Ablesung auszugeben. Der USD-Wert steht aus der nationalen Primaerquelle im
CSV (s. D-D).

### L7 — Suedafrika und Brasilien, OECD Family Database PF2.1
Tabelle PF2.1.A (Stand April 2025) umfasst die 38 OECD-Mitglieder plus fuenf
EU-Nichtmitglieder (Bulgarien, Kroatien, Zypern, Malta, Rumaenien). **Suedafrika und
Brasilien kommen nicht vor** (Tabelle vollstaendig gelesen). Hier trifft die
Auftragserwartung zu. Nationale Ersatzwerte (ZAF: 4 Monate UIF-Leistung; BRA: 120 Tage
licenca-maternidade) waeren **nicht** full-rate-equivalent gerechnet und damit nicht
vergleichbar — deshalb Luecke statt Fremdwert.

### L8 — Suedafrika, OECD IDD
Suedafrika steht auf der IDD-Laenderachse, die Reihen `PR_INC_DISP`/`PL_50` und
`INC_DISP`/`MEDIAN` (AGE=_T, METH2012, D_CUR) enden aber **2017**; ein Jahrgang 2022
existiert nicht. Kein Nachbarjahr eingesetzt — die Bestandsregel „kein Jahrgang wird
ersetzt" gilt.

---

## 5. Definitionsfallen

### D-A — Welche Mordraten-Quelle traegt? (der wichtigste Punkt)

| Land | WHO Sterbeurkunden | UNODC | Verhaeltnis | UNODC-Quelle laut Datei |
|---|---:|---:|---:|---|
| **Suedafrika** | **12,85** (7.596 Faelle) | **35,79** (21.325) | **2,8-fach** | NP/CTS/NP Adjusted = **SAPS-Polizeistatistik** |
| **Brasilien** | 20,97 (44.073) | 21,24 (44.073) | 1,01-fach | **DATASUS** = dieselbe Sterberegisterbasis |
| **Mexiko** | 28,23 (35.506) | 29,15 (36.661) | 1,03-fach | NSO/CTS = **INEGI**, dasselbe Statistikamt |

Das ist die entscheidende Tabelle:

- Bei **Brasilien** sind die Fallzahlen **identisch** (44.073 hier wie dort). UNODC
  uebernimmt fuer Brasilien die Gesundheitsministeriums-Sterbedaten. Die Ratendifferenz
  (20,97 gegen 21,24) ist **ausschliesslich der Nenner** — WHO-Populationsdatei
  210.147.125 gegen UNODCs Bevoelkerungsbasis. Es sind keine zwei unabhaengigen Messungen.
- Bei **Mexiko** liegen die Zahlen 3 % auseinander, weil INEGI und WHO dieselbe
  Vitalstatistik mit leicht unterschiedlicher Codeabgrenzung auswerten.
- Bei **Suedafrika** klafft es um den Faktor 2,8, und zwar nicht zufaellig: die
  WHO-Zahl ist der Rest, der nach der R00–R99-Ausduennung (15,8 %) und der
  Absichts-Fehlkodierung (Abschnitt 2.3) uebrigbleibt.

**Empfehlung:** In einer Grafik ueber diese drei Laender ist **UNODC** die tragfaehige
Reihe — nicht, weil sie „besser" ist, sondern weil sie fuer Brasilien und Mexiko ohnehin
dieselbe Datenbasis wiedergibt und fuer Suedafrika die Polizeistatistik (SAPS) einbringt,
die dort die einzige Reihe mit plausibler Groessenordnung ist. **Die WHO-Reihe darf fuer
Suedafrika nicht als Mordrate dargestellt werden.**

Das kollidiert mit **D1 des Bestandsdokuments** („WHO- und UNODC-Rate nicht in derselben
Grafik mischen"). Der Konflikt ist echt und muss entschieden werden: entweder die Grafik
laeuft **durchgaengig** auf UNODC (dann fallen die Bestandslaender ohne UNODC-Jahrgang
2019 heraus — z. B. Belgien, s. L3 im `add14`-Dokument), oder sie laeuft auf WHO (dann
darf Suedafrika nicht mit). **Beides gemischt geht nicht.**

### D-B — Suedafrikas `firearm_deaths_total` misst etwas anderes als bei den uebrigen Laendern
Der Wert 14,15 je 100.000 ist rechnerisch korrekt und in der Groessenordnung plausibel,
aber **99,7 % davon (8.340 von 8.369) stehen unter dem Unfallcode W34**. Bei allen anderen
Laendern des Datensatzes verteilt sich dieselbe Kennzahl ueber Suizid, Toetung und Unfall.
Fuer eine Grafik „Schusswaffentote gesamt" ist der Wert verwendbar; fuer jede Aussage
darueber, **wodurch** Menschen mit Schusswaffen sterben, ist er es nicht.

### D-C — Suedafrikas `adult_obesity_self_reported` ist zwoelf Jahre alt
Der letzte SR-Wert der OECD fuer Suedafrika ist **2014** (26.5). Die Reihe hat insgesamt
nur vier Punkte (1998, 2003, 2008, 2014). Der Bestand fuehrt diese Kennzahl bereits als
Jahresmix 2019–2025 — mit Suedafrika reicht die Spanne jetzt **2014–2025, elf Jahre**.
Wird die im `add14`-Dokument diskutierte Jahresregel („nicht aelter als 2022") angelegt,
faellt Suedafrika zusaetzlich zu Oesterreich, Tschechien und Kroatien heraus.

### D-D — `adult_obesity_measured` ist fuer ZAF und BRA modelliert, fuer MEX gemessen
Ein Blick in die Rohreihe zeigt den Unterschied sofort (alles abgelesen):
- **Suedafrika**: 33 Jahreswerte, 1990–2022, monoton steigend von 14,1 auf 30,0 — eine
  glatte Modellreihe, keine Erhebungspunkte.
- **Brasilien**: ebenso 33 Jahreswerte 1990–2022, 7,7 → 28,8.
- **Mexiko**: 11 Werte auf **Erhebungsjahren** (2000, 2005, 2006, 2012, 2016, 2018, 2020–2024)
  mit Spruengen und einem Rueckgang 2018→2020 — das sind ENSANUT-Wellen.

Der OECD-Flag `METHODOLOGY=MSRD` steht bei allen dreien, aber er bedeutet fuer ZAF/BRA
„aus gemessenen Erhebungen modelliert" und fuer MEX „gemessen". **Eine Rangliste ueber
diese Kennzahl vergleicht damit zwei verschiedene Dinge.** Der Bestand fuehrt die Reihe
ohnehin nur als Zusatz und mit Jahresspanne 2010–2024.

### D-E — Mindestlohn: drei verschiedene Wege, drei Stichtagsfallen
- **Brasilien**: WSI fuehrt das Land (1,17 EUR/Std., Stand 01.01.2026) — also derselbe Weg
  wie bei den Bestandslaendern. Die **Gegenprobe an der Primaernorm** ist im `source_name`
  vermerkt: Decreto 12.797/2025 nennt selbst einen Stundenwert von **7,37 BRL**
  (Monatswert 1.621,00 BRL, Tageswert 54,04 BRL). Bei EZB-Kurs 2026-09-17 sind das
  **1,44 USD** statt 1,34 USD. Die Luecke von 0,10 USD ist der von WSI verwendete
  Referenzkurs, nicht der Mindestlohn. Im CSV steht der WSI-Weg, weil er zum Bestand passt.
- **Suedafrika**: am Stichtag 01.01.2026 galt **28,79 ZAR/Std.** (Government Notice 52053,
  in Kraft seit 01.03.2025). Die vielzitierten 30,23 ZAR gelten erst ab **01.03.2026** und
  waeren am Stichtag falsch — dieselbe Falle wie bei Australien im Bestand.
- **Mexiko**: CONASAMI setzt einen **Tages**satz (315,04 MXN ab 01.01.2026). Die
  Umrechnung auf die Stunde erfolgt mit der gesetzlichen Tageshoechstarbeitszeit von
  8 Stunden (Art. 61 LFT). **Das ist eine gesetzte Annahme, keine Ablesung** — ein
  Beschaeftigter mit kuerzerer Schicht hat einen hoeheren Stundenwert. Zweite Falle:
  in der **Zona Libre de la Frontera Norte** gilt 440,87 MXN/Tag (= 3,21 USD/Std.), also
  40 % mehr. Im CSV steht der allgemeine Satz.

Alle drei Werte sind mit demselben EZB-Referenzkurs-Stichtag **2026-09-17** umgerechnet
wie der Bestand (1 EUR = 1,1481 USD; ZAR 18,6595 · BRL 5,8905 · MXN 19,7337).
**Definitionsfalle dahinter:** ein Lohn zum Stand 01.01.2026 wird mit einem Kurs vom
17.09.2026 umgerechnet. Das ist die Bestandsregel und wurde uebernommen, aber es mischt
zwei Stichtage.

### D-F — `median_verfuegbares_einkommen_aequiv_netto` ist ein Marktkurs, keine Kaufkraft
Brasilien 4.315 USD und Mexiko 4.585 USD entstehen durch Division durch den
OECD-Jahresdurchschnittskurs (5,16397 BRL/USD bzw. 20,12735 MXN/USD). Das ist dieselbe
Methode wie im Bestand — aber bei Schwellenlaendern verzerrt der Marktkurs staerker als
innerhalb der Eurozone. Der PPP-Vergleich derselben Laender (`bip_pro_kopf_ppp_2025e`:
BRA 23.381, MEX 25.682) liegt um Faktor 2,2 bzw. 1,9 ueber dem nominalen BIP je Kopf.
**Eine Grafik, die Medianeinkommen in USD nebeneinanderstellt, zeigt Wechselkurse mit.**

### D-G — Mexikos `health_insurance_coverage` von 72,4 % ist der niedrigste Wert im Datensatz
Niedriger als jeder Bestandswert (bisher Ungarn 95,0 und Polen 93,3). Der Wert ist
abgelesen (OECD `TPRIBASI`, 2020). **Nicht geprueft** ist, ob der Bruch 2019→2020
(Aufloesung des Seguro Popular und Uebergang zu INSABI) einen Reihenbruch darstellt. Vor
einer Grafik mit diesem Wert sollte das geklaert werden.

### D-H — Die Jahrgaenge bleiben uneinheitlich
WHO 2019 · UNODC 2019 · WPB 2018 · Small Arms Survey 2017 · OECD LE 2022 ·
OECD Saeuglingssterblichkeit 2023 · WHO-Adipositas 2024 · OECD Versicherung 2020 ·
MMEIG 2022 · HDI 2023 · IDD 2022 · IWF 2025 · Mindestlohn 01.01.2026 · WPB-`latest`
2025-12 bis 2026-08. Eine Grafik ueber mehrere Kennzahlen darf keinen einheitlichen Stand
behaupten. `incarceration_rate_prison_jail_latest` hat bei diesen drei Laendern Stichtage
vom 31.12.2025 bis 09.08.2026 — zusammen mit dem Bestand reicht die Spanne bis 2023 zurueck.

### D-I — Suedafrikas Lebenserwartung ist die niedrigste im gesamten Datensatz
65,5 Jahre (Maenner 61,8) liegt weit unter allem, was Bestand und `add14` enthalten.
Der Wert ist abgelesen aus derselben OECD-Reihe wie alle uebrigen. **Nicht geprueft** ist,
ob die OECD fuer Suedafrika eine eigene nationale Sterbetafel uebernimmt oder eine
UN-Schaetzung — bei einem Land mit 15,8 % unbestimmten Todesursachen ist diese Frage
nicht nebensaechlich.

---

## 6. Nicht geprueft

- Ob die OECD-Lebenserwartungs- und Saeuglingssterblichkeitswerte fuer ZAF und BRA
  nationale Register oder UN-/Modellschaetzungen sind (`CALC_METHODOLOGY` ist in beiden
  Faellen `_Z`, also unbesetzt).
- `OBS_STATUS`-Flags ausserhalb der geprueften Reihen.
- Die Unsicherheitsintervalle zu `adult_obesity` (WHO liefert Low/High: ZAF 28,1–34,5 ·
  BRA 28,1–33,7 · MEX 35,2–39,7) und zu `maternal_mortality` (MMEIG-Spanne) — wie im
  Bestand nicht uebernommen.
- Der Umfang der mexikanischen Verschwundenen-Problematik (RNPDNO) und ihre Wirkung auf
  die Mordrate.
- Ob die SAPS-Jahreszaehlung (April–Maerz) und das UNODC-Kalenderjahr fuer Suedafrika
  deckungsgleich sind. UNODC weist die Reihe als „NP Adjusted" aus, was auf eine Anpassung
  hindeutet; welche, steht nicht in der Datei.
- Ob Brasiliens `armutsquote_50pct_median` (19,23 %) auf derselben Haushaltserhebung
  beruht wie die europaeischen Werte (dort EU-SILC).
