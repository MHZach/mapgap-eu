mapgap.eu - Fifty States, Thirty-Five Countries
Full dataset, as of 19 September 2026.

Every row carries the value, its reference year, the exact source (name and URL),
and an evidence class - read off / calculated / inferred / assumed / not verified.
Nothing was estimated to fill a gap. Where a country does not report a figure the
row is absent or marked; it is never a zero.
